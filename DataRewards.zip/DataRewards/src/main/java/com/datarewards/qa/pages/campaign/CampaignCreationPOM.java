package com.datarewards.qa.pages.campaign;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.datarewards.qa.pages.util.TestBase;

public class CampaignCreationPOM extends TestBase {

	// Registration Page Elements
	@FindBy(xpath = "//input[@name='campaignName']")
	WebElement campaignNameFeild;

	@FindBy(xpath = "//input[@name='reportingEmail']")
	WebElement reportingEmailFeild;

	@FindBy(xpath = "//button[contains(text(),'Continue')]")
	WebElement registrationContinueButton;

	@FindBy(xpath = "//button[contains(text(),'cancel')]")
	WebElement registrationCancelButton;

	// Creative Page Elements

	@FindBy(xpath = "//button[contains(text(),'Save & Draft')]")
	WebElement creativeSaveAndDraftButton;

	@FindBy(xpath = "(//button[contains(text(),'Drag & Drop')])[1]")
	WebElement videoUploadDragAndDropTab;

	@FindBy(xpath = "(//p[contains(text(),'drag & drop files here')])[1]")
	WebElement videoUploadDragAndDropFilesHere;

	@FindBy(xpath = "(//button[contains(text(),'URL')])[1]")
	WebElement videoUploadURLTab;

	@FindBy(xpath = "(//input[@name='urlname'])[1]")
	WebElement videoUploadURLFeild;

	@FindBy(xpath = "(//button[contains(text(),'Choose Existing Assets')])[1]")
	WebElement videoUploadChooseExistingAssetsTab;

	@FindBy(xpath = "(//input[@placeholder='Search'])[1]")
	WebElement videoUploadChooseExistingAssetSearchFeild;

	@FindBy(xpath = "(//button[contains(text(),'Drag & Drop')])[2]")
	WebElement addPreviewImageDragAndDropTab;

	@FindBy(xpath = "(//p[contains(text(),'drag & drop files here')])[2]")
	WebElement addPreviewImageDragAndDropFilesHere;

	@FindBy(xpath = "(//button[contains(text(),'URL')])[2]")
	WebElement addPreviewImageURLTab;

	@FindBy(xpath = "(//input[@name='urlname'])[2]")
	WebElement addPreviewImageURLFeild;

	@FindBy(xpath = "//button[contains(text(),'Continue')]")
	WebElement creativeContinueButton;

	@FindBy(xpath = "//button[contains(text(),'Back')]")
	WebElement creativeBackButton;

	// Settings Page

	@FindBy(xpath = "//button[contains(text(),'Save & Draft')]")
	WebElement settingsSaveAndDraftButton;

	@FindBy(xpath = "//input[@name='value']")
	WebElement currencyValueFeild;

	@FindBy(xpath = "//button[contains(text(),'Finish')]")
	WebElement finishButton;

	@FindBy(xpath = "//button[contains(text(),'Back')]")
	WebElement settingsBackButton;

	@FindBy(xpath = "//button[contains(text(),'Reject')]")
	WebElement rejectButton;

	@FindBy(xpath = "//button[contains(text(),'Approve and send')]")
	WebElement approveAndSendButton;

	public CampaignCreationPOM() {
		PageFactory.initElements(driver, this);
		elementMap.put("campaignNameFeild", campaignNameFeild);
		elementMap.put("reportingEmailFeild", reportingEmailFeild);

	}

	public CampaignCreationPOM createNewCampaign(String CampaignNameFeild, String ReportingEmailFeild, String CurrencyValueFeild)
			throws InterruptedException {

		logger.info("Start create new campaign");

		logger.info("Enter cmpaign name feild");
		campaignNameFeild.sendKeys(CampaignNameFeild);
		Thread.sleep(3000);

		logger.info("Select a agency");
		SelectAgency();

		logger.info("Select a Category");
		selectCategory();

		logger.info("Select a Advertiser");
		selectAdvertiser();

		logger.info("Enter Reporting Email");
		reportingEmailFeild.sendKeys(ReportingEmailFeild);

		logger.info("Select a Campaign Objective");
		selectCampaignObjective();

		logger.info("Click On Continue Button");
		registrationContinueButton.click();
		
		logger.info("Click On Drag and Drop tab");
		videoUploadDragAndDropTab.click();
		
		logger.info("Click On Drag and Drop Files Here");
		videoUploadDragAndDropFilesHere.click();		
		
		logger.info("Click On Drag and Drop tab");
		addPreviewImageDragAndDropTab.click();
		
		logger.info("Click On Drag and Drop Files Here");
		addPreviewImageDragAndDropFilesHere.click();
		
		logger.info("Click On continue button");
		creativeContinueButton.click();
		
		logger.info("Enter Currency Value");
		currencyValueFeild.sendKeys(CurrencyValueFeild);
		
		logger.info("Select Currency Type");
		selectCurrency();
		
		logger.info("Click On Finish Button");
		finishButton.click();
		
		logger.info("Click On Approve and send Button");
		approveAndSendButton.click();

		logger.info("End create new campaign");
		return new CampaignCreationPOM();

	}

	public void SelectAgency() {
		driver.findElement(By.xpath("//*[@name='agency']")).click();
		List<WebElement> listbox = driver.findElements(By.xpath(
				"//ul[@Class='MuiList-root MuiList-padding MuiMenu-list css-6hp17o-MuiList-root-MuiMenu-list']//li"));
		System.out.println(listbox);

		for (int i = 0; i < listbox.size(); i++) {

			WebElement Element = listbox.get(i);

			if (listbox.get(i).getText().contains("Eventare")) {

				Element.click();
				break;

			}
		}
	}

	public void selectCategory() throws InterruptedException {
		driver.findElement(By.xpath("//input[@name='category']")).click();
		Thread.sleep(3000);
		List<WebElement> listbox = driver.findElements(By.xpath(
				"//ul[@Class='MuiList-root MuiList-padding MuiMenu-list css-6hp17o-MuiList-root-MuiMenu-list']//li"));
		System.out.println(listbox);

		for (int i = 0; i < listbox.size(); i++) {

			WebElement Element = listbox.get(i);

			if (listbox.get(i).getText().contains("Finance - Insurance")) {

				Element.click();
				break;
			}
		}

	}

	public void selectAdvertiser() throws InterruptedException {
		driver.findElement(By.xpath("//input[@name='advertiser']")).click();
		Thread.sleep(3000);
		List<WebElement> listbox = driver.findElements(By.xpath(
				"//ul[@Class='MuiList-root MuiList-padding MuiMenu-list css-6hp17o-MuiList-root-MuiMenu-list']//li"));
		System.out.println(listbox);

		for (int i = 0; i < listbox.size(); i++) {

			WebElement Element = listbox.get(i);

			if (listbox.get(i).getText().contains("Tenda")) {

				Element.click();
				break;
			}
		}

	}

	public void selectCampaignObjective() throws InterruptedException {
		driver.findElement(By.xpath("//input[@name='campaignObjective']")).click();
		Thread.sleep(3000);
		List<WebElement> listbox = driver.findElements(By.xpath(
				"//ul[@Class='MuiList-root MuiList-padding MuiMenu-list css-6hp17o-MuiList-root-MuiMenu-list']//li"));
		System.out.println(listbox);

		for (int i = 0; i < listbox.size(); i++) {

			WebElement Element = listbox.get(i);

			if (listbox.get(i).getText().contains("Display ad and provide rewards")) {

				Element.click();
				break;
			}
		}

	}

	public void selectCurrency() throws InterruptedException {
		driver.findElement(By.xpath("//input[@name='currency']")).click();
		Thread.sleep(3000);
		List<WebElement> listbox = driver
				.findElements(By.xpath("//ul[@Class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		System.out.println(listbox);

		for (int i = 0; i < listbox.size(); i++) {

			WebElement Element = listbox.get(i);

			if (listbox.get(i).getText().contains("USD-US Dollar")) {

				Element.click();
				break;
			}
		}

	}

	public void Agency() {
		driver.findElement(By.xpath("//*[@name='agency']")).click();
		List<WebElement> AgencyList = driver.findElements(By.xpath(
				"//ul[@Class='MuiList-root MuiList-padding MuiMenu-list css-6hp17o-MuiList-root-MuiMenu-list']//li"));
		// //ul[@role='listbox']

		System.out.println(AgencyList);

		for (int i = 0; i < AgencyList.size(); i++) {

			System.out.println(AgencyList.get(i).getText());

			if (AgencyList.get(i).getText().contains("Eventare"))
				;

			AgencyList.get(i).click();

			break;

		}
	}

}
package com.datarewards.qa.pages.campaign;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.datarewards.qa.pages.util.TestBase;

public class DataRewardsListPOM extends TestBase {

	@FindBy(xpath = "//input[@placeholder='Search Campaign Name...']")
	WebElement searchCampaignFeild;

	@FindBy(xpath = "//input[@placeholder='Search Campaign Name...']")
	WebElement dataRewardsTitle;
	
	

	public String DataRewardsTitle() {

		return dataRewardsTitle.getText();

	}

}

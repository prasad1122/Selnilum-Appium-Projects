package com.datarewards.qa.testcases;

import org.testng.annotations.Test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.datarewards.qa.pages.campaign.CampaignCreationPOM;
import com.datarewards.qa.pages.campaign.DataRewardsListPOM;
import com.datarewards.qa.pages.util.TestBase;
import com.datarewards.qa.pages.util.TestUtils;
import junit.framework.Assert;

public class CampaignCreationTest extends TestBase {

	private String CampaignCreationTestdata = "campaignCreationTestdata";

	private CampaignCreationPOM campaignCreationPOM;
	private DataRewardsListPOM dataRewardsListPOM;
	public ExtentReports extent;
	public ExtentTest extentTest;

	public CampaignCreationTest() {
		super();
		System.out.println("inside Constructor...");
	}

	@BeforeTest
	public void setExtent() {
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/IntellictaExtentReport-"
				+ new SimpleDateFormat("ddMMyyyy-HHmm").format(new Date()) + ".html", true);
		extent.addSystemInfo("Host Name", "Intellicta");
		extent.addSystemInfo("User Name", "Varaprasadrao");
		extent.addSystemInfo("Environment", "QA");
		extent.addSystemInfo("Selenium Version", "3.2");

	}

	@AfterTest
	public void endReport() {
		extent.flush();
		extent.close();
	}

	@BeforeMethod
	public void setup() {
		logger = Logger.getLogger("loginPageTest");
		PropertyConfigurator.configure("log4j.properties");
		intialization();
		logger.debug("Intialization of Browser");
		// loginPage = new LoginPage();
		System.out.println("Before Method Calls...");
		// loginPOM = new LoginPOM();

	}

	@DataProvider()
	public Object[][] getCampaignCreationTestdata() {
		Object[][] data = TestUtils.getTestData(CampaignCreationTestdata);
		return data;

	}

	@Test(enabled = true, priority = 1, dataProvider = "getCampaignCreationTestdata", description = "testnewCampaignCreation")
	public void testnewCampaignCreation(String CampaignNameFeild, String ReportingEmailFeild, String CurrencyValueFeild)
			throws InterruptedException {

		extentTest = extent.startTest("testCreateNewCampaign");
		campaignCreationPOM = campaignCreationPOM.createNewCampaign(CampaignNameFeild, ReportingEmailFeild,
				CurrencyValueFeild);

		String actual = dataRewardsListPOM.DataRewardsTitle();
		Assert.assertEquals(actual, "dataRewardsTitle");

	}

	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {

		if (result.getStatus() == ITestResult.FAILURE) {
			extentTest.log(LogStatus.FAIL, "TEST CASE FAILED IS " + result.getName()); // to add name in extent report
			extentTest.log(LogStatus.FAIL, "TEST CASE FAILED IS " + result.getThrowable()); // to add error/exception in
																							// extent report
			String screenshotPath = TestUtils.getScreenshot(driver, result.getName());
			extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(screenshotPath)); // to add screenshot in extent
																							// report
		} else if (result.getStatus() == ITestResult.SKIP) {
			extentTest.log(LogStatus.SKIP, "Test Case SKIPPED IS " + result.getName());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.log(LogStatus.PASS, "Test Case PASSED IS " + result.getName());

		}

		extent.endTest(extentTest); // ending test and ends the current test and prepare to create html report
		driver.quit();

	}
}

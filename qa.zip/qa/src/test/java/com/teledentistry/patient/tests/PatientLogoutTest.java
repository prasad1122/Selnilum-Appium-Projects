package com.teledentistry.patient.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientLogoutPage;
import com.teledentistry.util.ConstantValues;

public class PatientLogoutTest extends PatientTestBase {

	PatientLogoutPage patientLogoutPage;

	@Test(enabled = true)
	public void verifyLogoutButton() throws InterruptedException {
		patientLogoutPage = new PatientLogoutPage(driver);
		patientHomePG.clickOnLogoutButton();
		String actualHeader = patientLogoutPage.getLoginPageHedaer();
		String expectedHeader = ConstantValues.PATIENT_LOGIN_FORM_HEADER;
		testReport.info("Verify The Logout Button");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Not Working Logout Button");
	}

}

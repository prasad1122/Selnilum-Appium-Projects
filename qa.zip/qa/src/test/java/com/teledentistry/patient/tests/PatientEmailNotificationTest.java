package com.teledentistry.patient.tests;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientEmailNotificationPage;
import com.teledentistry.util.ConstantValues;

public class PatientEmailNotificationTest extends PatientTestBase {
	
	PatientEmailNotificationPage patientEmailNotificationPage;
	
	@Test(priority=1, enabled=true)
	public void verifyEmailNotification() throws InterruptedException {

		patientEmailNotificationPage = new PatientEmailNotificationPage(driver);

		Map<String, String> map=patientEmailNotificationPage.handleAppointmentBookedEmailNotification();
		
		testReport.info("Validate the Join Session Link");
		Assert.assertEquals("true", map.get("status"));
		testReport.info("Validate the User Name");
		Assert.assertTrue(map.get("name").contains(ConstantValues.USERNAME));
	}

}

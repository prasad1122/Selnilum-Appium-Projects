package com.teledentistry.patient.tests;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientImageUploadViaCameraPage;
import com.teledentistry.util.ConstantValues;

public class PatientImageUploadViaCameraTest extends PatientTestBase {

	PatientImageUploadViaCameraPage patientImgUploadViaCamera;

	@Test(priority=1, enabled=true)
	public void verifyImageUploadViaCamera() throws InterruptedException, AWTException {
		patientImgUploadViaCamera = new PatientImageUploadViaCameraPage(driver);

		int imagesSizeBefore = patientImgUploadViaCamera.getImageCountOnGallery();

		imagesSizeBefore++;

		patientHomePG.clickOnTakeAPictureLink();

		String actualHeader = patientImgUploadViaCamera.getHeader();
		String expectedHeader = ConstantValues.PATIENT_IMG_UPLOAD_CAMERA_HEADER;
		testReport.info("Validate the Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Header is NOT Correct");

		patientImgUploadViaCamera.clickOnCameraLink();

		patientImgUploadViaCamera.clickOnCapture();

		int imagesSizeAfter = patientImgUploadViaCamera.getImageCountOnGallery();

		Assert.assertEquals(imagesSizeBefore++, imagesSizeAfter, "ERROR: Image Not Uploaded");

	}

}

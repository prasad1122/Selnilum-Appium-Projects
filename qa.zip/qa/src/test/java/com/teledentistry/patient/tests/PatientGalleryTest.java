package com.teledentistry.patient.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientGalleryPage;
import com.teledentistry.util.ConstantValues;

public class PatientGalleryTest extends PatientTestBase {

	PatientGalleryPage patientGalleryPage;

	@Test(priority=1, enabled=true)
	public void verifyImages() throws InterruptedException {

		patientGalleryPage = new PatientGalleryPage(driver);

		patientHomePG.clickOnGalleryLink();

		String actualHeader = patientGalleryPage.getHeader();
		String expectedHeader = ConstantValues.GALLERY_HEADER;
		testReport.info("Validate the Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is NOT Correct");

		int imagesSize = patientGalleryPage.getImageCountOnGallery();
		testReport.info("Validate the Visible Images");
		Assert.assertNotEquals(imagesSize, 0);
	}

	@Test(priority=2, enabled=true)
	public void verifyImageDelete() throws InterruptedException {
		patientGalleryPage = new PatientGalleryPage(driver);

		patientHomePG.clickOnGalleryLink();
		int imagesSizeBefore = patientGalleryPage.getImageCountOnGallery();
		imagesSizeBefore--;
		patientGalleryPage.clickOnDeleteIcon();

		int imagesSizeAfter = patientGalleryPage.getImageCountOnGallery();

		Assert.assertEquals(imagesSizeBefore, imagesSizeAfter, "ERROR: Image Not Deleted");

	}

}

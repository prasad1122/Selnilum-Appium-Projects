package com.teledentistry.patient.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientChangePasswordPage;
import com.teledentistry.util.ConstantValues;

public class PatientChangePasswordTest extends PatientTestBase {

	PatientChangePasswordPage patientChangePasswordPage;

	@Test(priority = 1, dataProvider = "dataProvider")
	public void verifyChangePasswordFormWithBelow8Characters(String oldPassword, String newPassword,
			String confirmPassword) throws InterruptedException {
		patientChangePasswordPage = new PatientChangePasswordPage(driver);

		patientHomePG.clickOnChangePasswordModule();

		patientChangePasswordPage.patientChangePasswordWithInvalidData(oldPassword, newPassword, confirmPassword);
		String actualAlertMessage = patientChangePasswordPage.getAlert();
		String alertConent = patientChangePasswordPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate The Change Password Form with Below 8 Characters");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Patient Password not Updated");
	}

	@Test(priority = 2, dataProvider = "dataProvider")
	public void verifyChangePasswordFormWithWrongOldPassword(String oldPassword, String newPassword,
			String confirmPassword) throws InterruptedException {
		patientChangePasswordPage = new PatientChangePasswordPage(driver);

		patientHomePG.clickOnChangePasswordModule();

		patientChangePasswordPage.patientChangePasswordWithInvalidData(oldPassword, newPassword, confirmPassword);
		String actualAlertMessage = patientChangePasswordPage.getAlert();
		String alertConent = patientChangePasswordPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate The Change Password Form with Same Password");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Patient Password not Updated");
	}

	@Test(priority = 3, dataProvider = "dataProvider")
	public void verifyChangePasswordForm(String oldPassword, String newPassword, String confirmPassword)
			throws InterruptedException {
		patientChangePasswordPage = new PatientChangePasswordPage(driver);

		patientHomePG.clickOnChangePasswordModule();

		String actualHeader = patientChangePasswordPage.getFormHeader();
		String expectedHeader = ConstantValues.CHANGEPASSWORD_FORM_HEADER;
		testReport.info("Validate the Change Password Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		patientChangePasswordPage.patientChangePassword(oldPassword, newPassword, confirmPassword);

		String actualRedirectHeader = patientChangePasswordPage.getOfficeDetilsHeader();
		String expectedRedirectHeader = ConstantValues.OFFICE_DETAILS_HEADER;
		testReport.info("Validate The Change Password Form");
		Assert.assertEquals(actualRedirectHeader, expectedRedirectHeader, "ERROR: Patient Password not Updated");
	}

}

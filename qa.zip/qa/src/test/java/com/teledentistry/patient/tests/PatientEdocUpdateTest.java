package com.teledentistry.patient.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientEdocUpdatePage;
import com.teledentistry.util.ConstantValues;

public class PatientEdocUpdateTest extends PatientTestBase {

	PatientEdocUpdatePage patientEdocUpdatePage;

	@Test(dataProvider = "dataProvider")
	public void verifyEdocuments(String feet, String inches, String weight, String city, String zipCode, String painExp,
			String opinion, String drugAllergie) throws InterruptedException {

		patientEdocUpdatePage = new PatientEdocUpdatePage(driver);

		patientHomePG.clickOnEdocumentsLink();
		String actualHeader = patientEdocUpdatePage.getEdocumentsHeader();
		String expectedHeader = ConstantValues.PATIENT_EDOCUMENT;
		testReport.info("Validate the Edocuments Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is NOT Correct");

		patientEdocUpdatePage.clickOnDetailsLink();

		patientEdocUpdatePage.updatePersonalInformation(feet, inches, weight, city, zipCode);
		
		patientEdocUpdatePage.clickOnNextButton();

		String dentalHistoryFormActualHeader = patientEdocUpdatePage.getDentalHistoryFormHeader();
		String dentalHistoryFormExpectedHeader = ConstantValues.DENTAL_HISTORY_FORM_HEADER;
		testReport.info("Validate Contact and Personal Information Edocuments");
		Assert.assertEquals(dentalHistoryFormActualHeader, dentalHistoryFormExpectedHeader,
				"ERROR: Contact and Personal Information Edocument Not Updated");

		patientEdocUpdatePage.updateDentalHistoryInformation(painExp, opinion);
		
		patientEdocUpdatePage.clickOnNextButton();

		String medicalHistoryFormActualHeader = patientEdocUpdatePage.getMedicalHistoryFormHeader();
		String medicalHistoryFormExpectedHeader = ConstantValues.MEDICAL_HISTORY_FORM_HEADER;
		testReport.info("Validate Contact and Personal Information Edocuments");
		Assert.assertEquals(medicalHistoryFormActualHeader, medicalHistoryFormExpectedHeader,
				"ERROR: Dental History Not Updated");

		patientEdocUpdatePage.updateMedicalHistoryInformation(drugAllergie);
		patientEdocUpdatePage.clickOnNextButton();

		String targetPageFormActualHeader = patientEdocUpdatePage.getTargetPageFormHeader();
		String partgetPageFormExpectedHeader = ConstantValues.TARGET_PAGE_FORM_HEADER;
		testReport.info("Validate Contact and Personal Information Edocuments");
		Assert.assertEquals(targetPageFormActualHeader, partgetPageFormExpectedHeader,
				"ERROR: Dental History Not Updated");

	}

}

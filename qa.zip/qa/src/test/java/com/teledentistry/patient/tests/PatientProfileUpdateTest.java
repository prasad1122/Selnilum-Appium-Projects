package com.teledentistry.patient.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientProfileUpdatePage;
import com.teledentistry.util.ConstantValues;

public class PatientProfileUpdateTest extends PatientTestBase {

	PatientProfileUpdatePage patientProfileUpdatePage;

	@Test(dataProvider = "dataProvider")
	public void verifyPatientProfileUpdateForm(String feet, String inches, String address, String state, String city, String zipCode)
			throws InterruptedException {
		patientProfileUpdatePage = new PatientProfileUpdatePage(driver);
		patientHomePG.clickOnPatientProfileLink();
		String actualFormHeader = patientProfileUpdatePage.getPatientUpdateProfileFormHeader();
		String expectedFormHeader = ConstantValues.UPDATE_PATIENT_PROFILE_HEADER;
		testReport.info("Validate doctor Update Profile Header");
		Assert.assertEquals(actualFormHeader, expectedFormHeader, "ERROR: Form Title is NOT Correct");
		patientProfileUpdatePage.patientProfileUpdate(feet, inches, address, state, city, zipCode);
		String actualStatusMesaage = patientProfileUpdatePage.getAlert();
		String alertContent = patientProfileUpdatePage.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATE_PATIENT_PROFILE;
		testReport.info("Validate the Patient Profile Update");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Patient Details are not Updated");
	}

}

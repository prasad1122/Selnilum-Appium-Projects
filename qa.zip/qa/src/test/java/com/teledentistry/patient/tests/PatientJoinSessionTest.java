package com.teledentistry.patient.tests;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientJoinSessionPage;
import com.teledentistry.util.ConstantValues;

public class PatientJoinSessionTest extends PatientTestBase {
	
	PatientJoinSessionPage patientJoinSessionPage;
	
	@Test()
	public void verifyPatientJoinSession() throws InterruptedException, AWTException
	{
		patientJoinSessionPage=new PatientJoinSessionPage(driver);
		
		patientHomePG.clickOnJoinaConsultLink();
		
		String actualHeader = patientJoinSessionPage.getHeader();
		String expectedHeader = ConstantValues.JOIN_CONSULT;
	    testReport.info("Validate the Patient Join Consult");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is NOT Correct");

		patientJoinSessionPage.clickOnJoinSessionLink();
		
		patientJoinSessionPage.switchToNewTab();
		
		patientJoinSessionPage.clickOnMeetingContinueLink();
		
		patientJoinSessionPage.clickToJoinSession();
				
		patientJoinSessionPage.clickToDisconnect();
		

	} 

}

package com.teledentistry.patient.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.patient.pages.PatientImageUploadViaBrowserPage;
import com.teledentistry.util.ConstantValues;

public class PatientImageUploadViaBrowserTest extends PatientTestBase{
	
	PatientImageUploadViaBrowserPage patientImageUploadViaBrowserPage;
	

	@Test(priority=1, enabled=true)
	public void verifyImageUploadViaBrowser() throws InterruptedException, AWTException, IOException {
		
		patientImageUploadViaBrowserPage = new PatientImageUploadViaBrowserPage(driver);
		
		int imagesSizeBefore = patientImageUploadViaBrowserPage.getImageCountOnGallery();

		imagesSizeBefore++;

		patientHomePG.clickOnTakeAPictureLink();

		String actualHeader = patientImageUploadViaBrowserPage.getHeader();
		String expectedHeader = ConstantValues.PATIENT_IMG_UPLOAD_BROWSER_HEADER;
		testReport.info("Validate the Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is Not Correct");
		
		patientImageUploadViaBrowserPage.uploadImageViaBrowser();
		
		int imagesSizeAfter = patientImageUploadViaBrowserPage.getImageCountOnGallery();
		testReport.info("Validate the Uploadded Image");
		Assert.assertEquals(imagesSizeBefore, imagesSizeAfter, "ERROR: Image Not Uploaded");

	}


}

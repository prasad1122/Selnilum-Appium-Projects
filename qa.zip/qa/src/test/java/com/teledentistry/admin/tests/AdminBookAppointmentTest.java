package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminBookAppointmentPage;
import com.teledentistry.util.ConstantValues;

public class AdminBookAppointmentTest extends AdminTestBase {

	AdminBookAppointmentPage bookApointmentPage;

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentForm(String clinic, String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {
		bookApointmentPage = new AdminBookAppointmentPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		bookApointmentPage.clickOnAddNewBookAppointmentLink();

		String actualHeader = bookApointmentPage.getBookAppointmentFormHeader();
		String expectedHedaer = ConstantValues.BOOK_APPOINTMENT;
		testReport.info("Validate the Book Appointment Form Title");
		Assert.assertEquals(actualHeader, expectedHedaer, "ERROR: Form Title is NOT Correct");

		bookApointmentPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = bookApointmentPage.getAlert();
		String alertContent = bookApointmentPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAdminBookAppointmentWithInvalidDate(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {
		bookApointmentPage = new AdminBookAppointmentPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		bookApointmentPage.clickOnAddNewBookAppointmentLink();
		bookApointmentPage.createBookAppointmentWithInvalidDate(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = bookApointmentPage.getAlert();
		String alertContent = bookApointmentPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate Book Appointment Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Book Appointment Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAdminBookAppointmentWithPastTime(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {
		bookApointmentPage = new AdminBookAppointmentPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		bookApointmentPage.clickOnAddNewBookAppointmentLink();
		bookApointmentPage.createBookAppointmentWithPastTime(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = bookApointmentPage.getAlert();
		String alertContent = bookApointmentPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate Book Appointment Form with Past Time");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Book Appointment Details are Added");
	}

}

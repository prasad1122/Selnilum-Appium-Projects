package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminAddPatientPage;
import com.teledentistry.util.ConstantValues;

public class AdminAddPatientTest extends AdminTestBase {

	AdminAddPatientPage adminAddPatientPage;

	@Test(dataProvider = "dataProvider")
	public void verifyAddPatientForm(String clinicName, String firstname, String lastname, String phone, String dob,
			String email, String password, String feet, String inches, String gender, String weight, String SSNCode,
			String address, String city, String zipCode, String state) throws InterruptedException {
		adminAddPatientPage = new AdminAddPatientPage(driver);

		adminHomePG.clickOnPatientsLink();
		adminAddPatientPage.clickOnAddNewpatientLink();

		String actualHeader = adminAddPatientPage.getAddPatientFormHeader();
		String expectedHeader = ConstantValues.ADD_PATIENT;
		testReport.info("Validate the Add Patient Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		commonForms.createPatient(clinicName, firstname, lastname, phone, dob, email, password, feet, inches, gender,
				weight, SSNCode, address, city, zipCode, state);
		String actualStatus = adminAddPatientPage.getAlert();
		String alertContent = adminAddPatientPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Add Patient Form");
		logger.info("################# From Validation Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Patient Details are not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyWithInvalidPatientEmail(String clinicName, String firstname, String lastname, String phone,
			String dob, String email, String password, String feet, String inches, String gender, String weight,
			String SSNCode, String address, String city, String zipCode, String state) throws InterruptedException {

		adminAddPatientPage = new AdminAddPatientPage(driver);

		adminHomePG.clickOnPatientsLink();
		adminAddPatientPage.clickOnAddNewpatientLink();
		commonForms.createPatientWithInvalidEmail(clinicName, firstname, lastname, phone, dob, email, password, feet,
				inches, gender, weight, SSNCode, address, city, zipCode, state);
		String actualStatus = adminAddPatientPage.getAlert();
		String alertContent = adminAddPatientPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate Add Patient Form With Invalid Email");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Patient Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyWithInvalidPatientBirthDate(String clinicName, String firstname, String lastname, String phone,
			String dob, String email, String password, String feet, String inches, String gender, String weight,
			String SSNCode, String address, String city, String zipCode, String state) throws InterruptedException {

		adminAddPatientPage = new AdminAddPatientPage(driver);

		adminHomePG.clickOnPatientsLink();
		adminAddPatientPage.clickOnAddNewpatientLink();
		commonForms.createPatientWithInvalidDateofBirth(clinicName, firstname, lastname, phone, dob, email, password,
				feet, inches, gender, weight, SSNCode, address, city, zipCode, state);
		String actualStatus = adminAddPatientPage.getAlert();
		String alertContent = adminAddPatientPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate Add Patient Form With Invalid DOB");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ALERT: Patient Details are Not Added");
	}

}

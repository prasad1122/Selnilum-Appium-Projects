package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminUpdatePatientPage;
import com.teledentistry.util.ConstantValues;

public class AdminUpdatePatientTest extends AdminTestBase {

	AdminUpdatePatientPage adminUpdatePatientPage;

	@Test(dataProvider = "dataProvider")
	public void verifyUpdatePatientForm(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String ssn, String address,
			String city, String zipcode, String state) throws InterruptedException {
		adminUpdatePatientPage = new AdminUpdatePatientPage(driver);

		adminHomePG.clickOnPatientsLink();
		adminUpdatePatientPage.clickOnUpdatePatientLink();

		String actualHeader = adminUpdatePatientPage.getUpdatePatientFormHeader();
		String expectedHeader = "Update Patient";
		testReport.info("Validate the Update Patient Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		commonForms.UpdatePatientDetails(firstname, lastname, phone, dob, email, password, feet, inches, gender, weight,
				ssn, address, city, zipcode, state);
		String actualAlertMessage = adminUpdatePatientPage.getAlert();
		String alertConent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Patient Form");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Patient Details are not Updated");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyUpdatePatientFormWithDiffCity(String firstname, String lastname, String phone, String dob,
			String email, String password, String feet, String inches, String gender, String weight, String ssn,
			String address, String city, String zipcode, String state) throws InterruptedException {
		adminUpdatePatientPage = new AdminUpdatePatientPage(driver);

		adminHomePG.clickOnPatientsLink();
		adminUpdatePatientPage.clickOnUpdatePatientLink();

		commonForms.UpdatePatientDetails(firstname, lastname, phone, dob, email, password, feet, inches, gender, weight,
				ssn, address, city, zipcode, state);
		String actualAlertMessage = adminUpdatePatientPage.getAlert();
		String alertConent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Patient Form");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Patient Details are not Updated");
	}
}

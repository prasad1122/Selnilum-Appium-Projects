package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminAddClinicPage;
import com.teledentistry.util.ConstantValues;

public class AdminAddClinicTest extends AdminTestBase {

	AdminAddClinicPage adminAddClinicPage;

	@Test(dataProvider = "dataProvider")
	public void verifyAddClinicFormForIndependentClinicWithoutCallCenter(String clinicName, String clinicEmail,
			String username, String password, String logoURL, String clinicType, String staffMembers)
			throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		String actualFormHeader = adminAddClinicPage.getaddClinicFormHeader();
		String expectedFormHeader = ConstantValues.ADD_CLINIC;
		testReport.info("Validate The Add Clinic Form Title");
		Assert.assertEquals(actualFormHeader, expectedFormHeader, "ERROR: Form Title is NOT Correct");
		commonForms.createNewClinic(clinicName, clinicEmail, username, password,
				logoURL, clinicType, staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Add Clinic Form For Independent Clinic Without CallCenter");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddClinicFormForDependentClinicWithCallCenter(String clinicName, String clinicEmail,
			String username, String password, String logoURL, String clinicType, String staffMembers)
			throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinic(clinicName, clinicEmail, username, password,
				logoURL, clinicType, staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Add Clinic Form For Dependent Clinic With Call Center");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddClinicFormForDependentClinicWithOverflowCallCenter(String clinicName, String clinicEmail,
			String username, String password, String logoURL, String clinicType, String staffMembers)
			throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinic(clinicName, clinicEmail, username, password,
				logoURL, clinicType, staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Add Clinic Form For Dependent Clinic With Overflow Call Center");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddClinicFormForHealthCareClinicWithCallCenter(String clinicName, String clinicEmail,
			String username, String password, String logoURL, String clinicType, String staffMembers)
			throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinic(clinicName, clinicEmail, username, password,
				logoURL, clinicType, staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Add Clinic Form For Health Care Clinic With Call Center");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddClinicFormForHealthCareClinicWithoutCallCenter(String clinicName, String clinicEmail,
			String username, String password, String logoURL, String clinicType, String staffMembers)
			throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinic(clinicName, clinicEmail, username, password,
				logoURL, clinicType, staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Add Clinic Form For Health Care Clinic Without Call Center");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddClinicFormForValueAddedBenefit(String clinicName, String clinicEmail, String username,
			String password, String logoURL, String clinicType, String staffMembers) throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinic(clinicName, clinicEmail, username, password, logoURL,
				clinicType, staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Add Clinic Form For Value Added Benefit");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyWithInvalidClinicEmail(String clinicName, String clinicEmail, String username, String password,
			String logoURL, String clinicType, String staffMembers) throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinicWithInvalidEmail(clinicName, clinicEmail, username, password, logoURL, clinicType,
				staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertcontent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate Add Clinic Form With Invalid Email");
		logger.info("################# Alert Message: " + alertcontent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyWithInvalidClinicUsername(String clinicName, String clinicEmail, String username, String password,
			String logoURL, String clinicType, String staffMembers) throws InterruptedException {
		adminAddClinicPage = new AdminAddClinicPage(driver);

		adminHomePG.clickOnClinicsLink();
		adminAddClinicPage.clickOnAddNewClinicLink();
		commonForms.createNewClinicWIthInvalidUsername(clinicName, clinicEmail, username, password, logoURL, clinicType,
				staffMembers);
		String actualAlertMessage = adminHomePG.getAlert();
		String alertcontent = adminHomePG.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate Add Clinic Form With Invalid Username");
		logger.info("################# Alert Message: " + alertcontent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are Added");
	}

}

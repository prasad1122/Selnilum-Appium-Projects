package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminTimeZonesPage;
import com.teledentistry.util.ConstantValues;

public class AdminTimeZonesTestViaBookAppointment extends AdminTestBase {

	AdminTimeZonesPage timeZonesPage;

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithAlaskaTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Alaska");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithAleutianTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Aleutian");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithArizonaTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Arizona");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithCentralTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Central");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithEastIndianaTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/East-Indiana");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithEasternTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Eastern");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithHawaiiTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Hawaii");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithIndStarkeTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Michigan");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithMichiganTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Michigan");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithMountainTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Mountain");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithPacificTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Pacific");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithSamoaTimeZone(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {

		timeZonesPage = new AdminTimeZonesPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();

		timeZonesPage.createBookAppointment(clinic, timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Samoa");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

}

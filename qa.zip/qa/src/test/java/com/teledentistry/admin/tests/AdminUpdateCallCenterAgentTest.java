package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminUpdateCallCenterAgentPage;
import com.teledentistry.util.ConstantValues;

public class AdminUpdateCallCenterAgentTest extends AdminTestBase{
	
	AdminUpdateCallCenterAgentPage adminUpdateCallCenterAgentPage;
	
	
	@Test(dataProvider = "dataProvider")
	public void verifyUpdateCallCenterAgentForm(String name, String password) throws InterruptedException{
		adminUpdateCallCenterAgentPage = new AdminUpdateCallCenterAgentPage(driver);

		adminHomePG.clickOnCallCenterTeamLink();
		adminUpdateCallCenterAgentPage.clickOnUpdateCallCenterAgentLink();
		String actualHeader = adminUpdateCallCenterAgentPage.getUpdateCallCenterAgentFormHeader();
		String expectedHeader = ConstantValues.USER_AGENT_UPADTE_FORM_HEADER;
		testReport.info("Validate the Update User Agent Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");
		adminUpdateCallCenterAgentPage.updateCallCenterAgentDetails(name, password);
		String actualAlertMessage = adminUpdateCallCenterAgentPage.getAlert();
		String alertConent = adminUpdateCallCenterAgentPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update User Agent Form");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: User Agent Details are not Updated");
	}

}

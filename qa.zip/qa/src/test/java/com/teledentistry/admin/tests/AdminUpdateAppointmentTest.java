package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminUpdateAppointmentPage;
import com.teledentistry.util.ConstantValues;

public class AdminUpdateAppointmentTest extends AdminTestBase {
	AdminUpdateAppointmentPage adminUpdateAppointment;

	@Test(dataProvider = "dataProvider")
	public void verifyUpdateAppointmentForm(String clinic, String clientName, String doctorName, String date,
			String time) throws Exception {
		adminUpdateAppointment = new AdminUpdateAppointmentPage(driver);

		adminHomePG.clickOnBookAppointmentsLink();
		adminUpdateAppointment.updateAppointmentLink();
		String actualHeader = adminUpdateAppointment.getUpdateAppointmentFormHeader();
		String expectedHeader = ConstantValues.UPDATE_APPOINTMENT;
		testReport.info("Validate the Update Appointment Form Heading");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Heading is NOT Correct");

		adminUpdateAppointment.updateAppointmentForm(clinic, clientName, doctorName, date, time);
		String actualStatusMesaage = adminUpdateAppointment.getAlert();
		String alertmessage = adminHomePG.getAlertContent();
		String expectedStatusMessage = ConstantValues.SUCCESS;
		testReport.info("Validate Admin Update Appointment Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Appointment Details are Not Updated");
	}

}

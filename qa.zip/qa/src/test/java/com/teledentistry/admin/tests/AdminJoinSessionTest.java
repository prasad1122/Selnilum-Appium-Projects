package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminJoinSessionPage;
import com.teledentistry.util.ConstantValues;

public class AdminJoinSessionTest extends AdminTestBase {
	AdminJoinSessionPage adminJoinSession = new AdminJoinSessionPage(driver);

	@Test
	public void joinSession() throws Exception {
		adminJoinSession = new AdminJoinSessionPage(driver);
		adminHomePG.clickOnBookAppointmentsLink();
		adminJoinSession.clickOnOPtionsLink();

		adminJoinSession.switchToNewTab();

		String actualRoomHeader = adminJoinSession.getRoomHeader();
		String expectedRoomHeader = ConstantValues.MEETING_ROOM_HEADER;
		testReport.info("Validate The Header");
		Assert.assertEquals(actualRoomHeader, expectedRoomHeader, "ERROR: Header is NOT Correct");

		adminJoinSession.clickOnMeetingContinueLink();

		adminJoinSession.clickToJoinSession();

		adminJoinSession.clickonDisconnect();
	}

}

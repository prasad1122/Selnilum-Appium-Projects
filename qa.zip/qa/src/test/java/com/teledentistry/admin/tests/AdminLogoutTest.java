package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminLogoutPage;
import com.teledentistry.util.ConstantValues;

public class AdminLogoutTest extends AdminTestBase{
	
	AdminLogoutPage adminLogout;
	
	@Test(enabled=true)
	public void verifyLogoutButton() throws InterruptedException {
		adminLogout=new AdminLogoutPage(driver);
		adminHomePG.clickOnLogoutButton();
		String actualHeader = adminLogout.getLoginPageHedaer();
		String expectedHeader = ConstantValues.ADMIN_LOGIN_FORM_HEADER;
		testReport.info("Verify The Logout Button");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Not Working Logout Button");
		
	}

}

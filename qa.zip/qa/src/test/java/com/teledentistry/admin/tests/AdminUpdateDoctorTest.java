package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminUpdateDoctorPage;
import com.teledentistry.util.ConstantValues;

public class AdminUpdateDoctorTest extends AdminTestBase {

	AdminUpdateDoctorPage adminUpdateDoctorPage;

	@Test(dataProvider = "dataProvider",priority=2)
	public void verifyUpdateDoctorForm(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipcode, String statecode,
			String NPINumber, String DEANumber, String DEAState) throws Exception {
		adminUpdateDoctorPage = new AdminUpdateDoctorPage(driver);

		adminHomePG.clickOnDoctorsLink();
		adminUpdateDoctorPage.clickOnUpdateDoctorLink();
		String actualTitle = adminUpdateDoctorPage.getUpdateDoctorFormHeader();
		String expectedTitle = ConstantValues.UPDATE_DOCTOR;
		testReport.info("Validate the Update Doctor Form Title");
		Assert.assertEquals(actualTitle, expectedTitle, "ERROR: Form Title is NOT Correct");

		commonForms.updateDoctorForm(firstname, lastname, phone, fax, email, password, dob, state, address, city,
				zipcode, statecode, NPINumber, DEANumber, DEAState);
		String actualStatusMesaage = adminUpdateDoctorPage.getAlert();
		String alertmessage = adminHomePG.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Doctor Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Doctor details are not Updated");
	}

	@Test(dataProvider = "dataProvider", priority=1)
	public void verifyUpdateDoctorFormWithDiffCity(String firstname, String lastname, String phone, String fax,
			String email, String password, String dob, String state, String address, String city, String zipcode,
			String statecode, String NPINumber, String DEANumber, String DEAState) throws Exception {
		adminUpdateDoctorPage = new AdminUpdateDoctorPage(driver);

		adminHomePG.clickOnDoctorsLink();
		adminUpdateDoctorPage.clickOnUpdateDoctorLink();

		commonForms.updateDoctorFormWithDiffCity(firstname, lastname, phone, fax, email, password, dob, state, address, city,
				zipcode, statecode, NPINumber, DEANumber, DEAState);
		String actualStatusMesaage = adminUpdateDoctorPage.getAlert();
		String alertmessage = adminHomePG.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Doctor Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Doctor details are not Updated");
	}

}

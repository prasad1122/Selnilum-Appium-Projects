package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminAddDoctorPage;
import com.teledentistry.util.ConstantValues;

public class AdminAddDoctorTest extends AdminTestBase {

	AdminAddDoctorPage adminAddDoctorPage;

	@Test(dataProvider = "dataProvider")
	public void verifyAddDoctorForm(String clinicName, String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipCode, String stateCode,
			String NPINumber, String DEANumber, String DEAState) throws InterruptedException {
		adminAddDoctorPage = new AdminAddDoctorPage(driver);

		adminHomePG.clickOnDoctorsLink();
		adminAddDoctorPage.clickOnAddNewDoctorLink();

		String actualHeader = adminAddDoctorPage.getAddDoctorFormHeader();
		String expectedHeader = ConstantValues.ADD_DOCTOR;
		testReport.info("Validate the Add Doctor Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		commonForms.createNewDoctor(clinicName, firstname, lastname, phone, fax, email, password, dob, state, address, city,
				zipCode, stateCode, NPINumber, DEANumber, DEAState);
		String actualStatusMessage = adminAddDoctorPage.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		String expectedStatusMessage = ConstantValues.ADDED;
		testReport.info("Validate Add Doctor Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "SUCCESS: Doctor Details Added");

	}

	@Test(dataProvider = "dataProvider")
	public void verifyWithInvalidDoctorEmail(String clinicName, String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipCode, String stateCode,
			String NPINumber, String DEANumber, String DEAState) throws InterruptedException {
		adminAddDoctorPage = new AdminAddDoctorPage(driver);

		adminHomePG.clickOnDoctorsLink();
		adminAddDoctorPage.clickOnAddNewDoctorLink();
		commonForms.createNewDoctorwithInvalidEmail(clinicName,firstname, lastname, phone, fax, email, password, dob, state,
				address, city, zipCode, stateCode, NPINumber, DEANumber, DEAState);
		String actualStatusMessage = adminAddDoctorPage.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		testReport.info("Validate Add Doctor Form With Invalid Email");
		String expectedStatusMessage = ConstantValues.ERROR;
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "ERROR: Doctor Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyWithInvalidDoctorDateofBirth(String clinicName,String firstname, String lastname, String phone, String fax,
			String email, String password, String dob, String state, String address, String city, String zipCode,
			String stateCode, String NPINumber, String DEANumber, String DEAState) throws InterruptedException {
		adminAddDoctorPage = new AdminAddDoctorPage(driver);

		adminHomePG.clickOnDoctorsLink();
		adminAddDoctorPage.clickOnAddNewDoctorLink();
		commonForms.createNewDoctorwithInvalidDob(clinicName, firstname, lastname, phone, fax, email, password, dob, state, address,
				city, zipCode, stateCode, NPINumber, DEANumber, DEAState);
		String actualStatusMessage = adminAddDoctorPage.getAlert();
		String alertContent = adminHomePG.getAlertContent();
		testReport.info("Validate Add Doctor Form With Invalid Dob");
		String expectedStatusMessage = ConstantValues.ERROR;
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "Alert: Doctor Details are Not Added");
	}

}

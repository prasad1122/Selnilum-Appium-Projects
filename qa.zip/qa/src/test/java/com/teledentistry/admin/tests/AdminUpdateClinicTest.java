package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminUpdateClinicPage;
import com.teledentistry.util.ConstantValues;

public class AdminUpdateClinicTest extends AdminTestBase{
	
	AdminUpdateClinicPage adminUpdateClinicPage;
	
	@Test(dataProvider = "dataProvider" )
	public void verifyUpdateClinicForm(String clinicname, String clinicemail, String username, String password, String logourl, String clinictype, String staffmembers) throws InterruptedException
	{
		adminUpdateClinicPage=new AdminUpdateClinicPage(driver);
		
		adminHomePG.clickOnClinicsLink();
		adminUpdateClinicPage.clickOnUpdateClinicLink();
		
		String actualHeader = adminUpdateClinicPage.getUpdateClinicFormHeader();
		String expectedHeader = ConstantValues.UPDATE_CLINIC;
        testReport.info("Validate the Update Clinic Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");
		
		commonForms.updateClinic(clinicname, clinicemail, username, password, logourl, clinictype, staffmembers);
		String actualAlertMessage=adminUpdateClinicPage.getAlert();
		String alertContent= adminUpdateClinicPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.SUCCESS;
		testReport.info("Validate Update Clinic Form");

			logger.info("################# Alert Message: " + alertContent + " #################");
		    Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Details are not Updated");
		
	}	


}

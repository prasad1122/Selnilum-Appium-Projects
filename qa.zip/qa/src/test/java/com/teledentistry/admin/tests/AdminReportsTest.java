package com.teledentistry.admin.tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminReportsPage;
import com.teledentistry.util.ConstantValues;

public class AdminReportsTest extends AdminTestBase {

	AdminReportsPage adminReportsPage;

	@Test(dataProvider = "dataProvider")
	public void verifyDownloadMonthAndYearClinicsReport(String report, String year) throws InterruptedException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnMonthYearLink();

		String actualHeader = adminReportsPage.getReportsFormHeader();
		String expectedHeader = ConstantValues.MONTH_YEAR_REPORTS_HEADER;
		testReport.info("Validate the Reports Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		adminReportsPage.selectReportTypeAndYear(report, year);

		adminReportsPage.clickOnClinicReportDownloadButton();

		Assert.assertTrue(adminReportsPage.getResult(), "ERROR: Month/Year Report NOT Downloaded");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyDownloadMonthAndYearConsultsReport(String report, String clinics, String year)
			throws InterruptedException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnMonthYearLink();

		adminReportsPage.selectReportTypeAndClinicsAndYear(report, clinics, year);

		adminReportsPage.clickOnConsultsReportDownloadButton();

		Assert.assertTrue(adminReportsPage.getConsultReportResult(), "ERROR: Month/Year Report NOT Downloaded");
	}
	
	@Test(dataProvider = "dataProvider")
	public void verifyDownloadMonthReportViaCountHyperlink(String report, String year)
			throws InterruptedException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnMonthYearLink();

		adminReportsPage.selectReportTypeAndYear(report, year);
		
		adminReportsPage.clickOnCountHyperLink();

		adminReportsPage.clickOnCountHyperLinkDownloadButton();

		Assert.assertTrue(adminReportsPage.getMonthReportViaCountHyperLinkResult(), "ERROR: Month/Year Report NOT Downloaded");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyDownloadPatientChatProcessListReports(String clinic, String patient) throws InterruptedException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnChatReportsLink();

		String actualHeader = adminReportsPage.getChatReportsFormHeader();
		String expectedHeader = ConstantValues.CHAT_REPORTS_HEADER;
		testReport.info("Validate the Chat Reports Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		adminReportsPage.selectClinicAndPatient(clinic, patient);

		adminReportsPage.clickOnChatReportDownloadButton();

		Assert.assertTrue(adminReportsPage.getResult(), "ERROR: Chat Report NOT Downloaded");
	}

	@Test(enabled = true)
	public void verifyDownloadNotLoggedInListUserActivityReports() throws InterruptedException, IOException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnUserActivityReportsLink();

		String actualHeader = adminReportsPage.getUserActivityReportsFormHeader();
		String expectedHeader = ConstantValues.USER_ACTIVITY_REPORTS_HEADER;
		testReport.info("Validate the User Activity Reports Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		adminReportsPage.selectClinic();
		adminReportsPage.clickOnNotLoggedInListDownloadButton();

		Assert.assertTrue(adminReportsPage.isFileDownloaded(ConstantValues.NOT_LOGGED_IN_LIST_FILE_NAME),
				"Failed to download Not-Logged-In-List document");

	}

	@Test(enabled = true)
	public void verifyDownloadEdocNotFilledListUserActivityReports() throws InterruptedException, IOException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnUserActivityReportsLink();

		adminReportsPage.selectClinic();
		adminReportsPage.clickOnEdocNotFilledListDownloadButton();

		Assert.assertTrue(adminReportsPage.isFileDownloaded(ConstantValues.EDOC_NOT_FILLED_LIST_FILE_NAME),
				"Failed to download Edoc-Not-Filled-List document");

	}

	@Test(enabled = true)
	public void verifyDownloadNotJoinedConsultsListUserActivityReports() throws InterruptedException, IOException {

		adminReportsPage = new AdminReportsPage(driver);

		adminHomePG.clickOnReportsLink();

		adminReportsPage.clickOnUserActivityReportsLink();

		adminReportsPage.selectClinic();
		adminReportsPage.clickOnNotJoinedConsultsListDownloadButton();

		Assert.assertTrue(adminReportsPage.isFileDownloaded(ConstantValues.NOT_JOINED_CONSULTS_LIST_FILE_NAME),
				"Failed to download Not-Joined-Consults-List document");

	}
}

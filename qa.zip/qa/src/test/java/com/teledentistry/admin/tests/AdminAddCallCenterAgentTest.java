package com.teledentistry.admin.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.admin.pages.AdminAddCallCenterAgentPage;
import com.teledentistry.util.ConstantValues;

public class AdminAddCallCenterAgentTest extends AdminTestBase {
	
	AdminAddCallCenterAgentPage addCallCenterAgentPage;

	@Test(dataProvider = "dataProvider")
	public void verifyAddCallCenterAgentForm(String name, String email, String zoomId) throws InterruptedException {

		addCallCenterAgentPage = new AdminAddCallCenterAgentPage(driver);

		adminHomePG.clickOnCallCenterTeamLink();
		addCallCenterAgentPage.clickOnAddNewButton();

		addCallCenterAgentPage.createCallCenterAgent(name, email, zoomId);
		String actualStatus = addCallCenterAgentPage.getAlert();
		String alertContent = addCallCenterAgentPage.getAlertContent();
		String expectedStatus = ConstantValues.ADDED;
		testReport.info("Validate The Add Call Center Agent Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Call Center Agent Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddCallCenterAgentFormWithInvalidEmail(String name, String email, String zoomId) throws InterruptedException {

		addCallCenterAgentPage = new AdminAddCallCenterAgentPage(driver);

		adminHomePG.clickOnCallCenterTeamLink();
		addCallCenterAgentPage.clickOnAddNewButton();

		addCallCenterAgentPage.createCallCenterAgentWithInvalidEmail(name, email, zoomId);
		String actualStatus = addCallCenterAgentPage.getAlert();
		String alertContent = addCallCenterAgentPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate The Add Call Center Agent Form With Invalid Email");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Call Center Agent Added");
	}
}

package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicAddPatientPage;
import com.teledentistry.util.ConstantValues;

public class ClinicAddPatientTest extends ClinicTestBase {

	ClinicAddPatientPage clinicAddPatientPage;

	@Test(dataProvider = "dataProvider")
	public void verifyClinicAddPatientForm(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String ssn, String address,
			String city, String zipcode, String state) throws InterruptedException {
		clinicAddPatientPage = new ClinicAddPatientPage(driver);

		clinicHomePG.clickOnClinicPatientsLink();
		clinicAddPatientPage.clickOnAddNewPatientLink();
		String actualFormHeader = clinicAddPatientPage.getaddPatientFormHeader();
		String expectedFormHeader = ConstantValues.ADD_PATIENT;
		testReport.info("Validate the Add Patient Form Title");
		Assert.assertEquals(actualFormHeader, expectedFormHeader, "ERROR: Form Title is NOT Correct");

		commonForms.createNewPatient(firstname, lastname, phone, dob, email, password, feet, inches, gender, weight,
				ssn, address, city, zipcode, state);
		String actualStatusMesaage = clinicAddPatientPage.getAlert();
		String alertContent = clinicAddPatientPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATED;
		testReport.info("Validate Add Patient Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Patient Details are not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyClinicAddPatientFormWithInvalidEmail(String firstname, String lastname, String phone, String dob,
			String email, String password, String feet, String inches, String gender, String weight, String ssn,
			String address, String city, String zipcode, String state) throws InterruptedException {

		clinicAddPatientPage = new ClinicAddPatientPage(driver);

		clinicHomePG.clickOnClinicPatientsLink();
		clinicAddPatientPage.clickOnAddNewPatientLink();
		commonForms.createPatientWithInvalidEmail(firstname, lastname, phone, dob, email, password, feet, inches,
				gender, weight, ssn, address, city, zipcode, state);
		String actualStatusMesaage = clinicAddPatientPage.getAlert();
		String alertContent = clinicAddPatientPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.ERROR;
		testReport.info("Validate Add Patient Form With Invalid Email");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Patient Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyClinicAddPatientFormWithInvalidPassword(String firstname, String lastname, String phone,
			String dob, String email, String password, String feet, String inches, String gender, String weight,
			String ssn, String address, String city, String zipcode, String state) throws InterruptedException {

		clinicAddPatientPage = new ClinicAddPatientPage(driver);

		clinicHomePG.clickOnClinicPatientsLink();
		clinicAddPatientPage.clickOnAddNewPatientLink();
		commonForms.createPatientWithInvalidDateofBirth(firstname, lastname, phone, dob, email, password, feet, inches,
				gender, weight, ssn, address, city, zipcode, state);
		String actualStatusMesaage = clinicAddPatientPage.getAlert();
		String alertContent = clinicAddPatientPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.ALERT;
		testReport.info("Validate Add Patient Form With Invalid DOB");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Patient Details are Not Added");
	}

}

package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicAddStaffMemberPage;
import com.teledentistry.util.ConstantValues;

public class ClinicAddStaffMemberTest extends ClinicTestBase {

	ClinicAddStaffMemberPage staffMemberPage;

	@Test(dataProvider = "dataProvider")
	public void verifyAddStaffMemberForm(String name, String email, String userName, String password, String status)
			throws InterruptedException {

		staffMemberPage = new ClinicAddStaffMemberPage(driver);

		clinicHomePG.clickOnStaffMembersLink();
		staffMemberPage.clickOnAddNewStaffLink();

		String actualHeader = staffMemberPage.getAddStaffMemberFormHeader();
		String expectedHeader = ConstantValues.ADD_STAFF_MEMBER_HEADER;
		testReport.info("Validate the Add Staff Member Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		staffMemberPage.createStaffMember(name, email, userName, password, status);
		String actualStatus = staffMemberPage.getAlert();
		String alertContent = staffMemberPage.getAlertContent();
		String expectedStatus = ConstantValues.USER_CREATED;
		testReport.info("Validate Add Staff Member Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Staff Member Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddStaffMemberFormWithInvalidUsername(String name, String email, String userName, String password,
			String status) throws InterruptedException {

		staffMemberPage = new ClinicAddStaffMemberPage(driver);

		clinicHomePG.clickOnStaffMembersLink();
		staffMemberPage.clickOnAddNewStaffLink();

		staffMemberPage.createStaffMemberWithInvalidUsername(name, email, userName, password, status);
		String actualStatus = staffMemberPage.getAlert();
		String alertContent = staffMemberPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate Add Staff Member Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Staff Member Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyAddStaffMemberFormWithInvalidEmail(String name, String email, String userName, String password,
			String status) throws InterruptedException {

		staffMemberPage = new ClinicAddStaffMemberPage(driver);

		clinicHomePG.clickOnStaffMembersLink();
		staffMemberPage.clickOnAddNewStaffLink();

		staffMemberPage.createStaffMemberWithInvalidEmail(name, email, userName, password, status);
		String actualStatus = staffMemberPage.getAlert();
		String alertContent = staffMemberPage.getAlertContent();
		String expectedStatus = ConstantValues.ERROR;
		testReport.info("Validate Add Staff Member Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Staff Member Added");
	}

}

package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.teledentistry.clinic.pages.ClinicBookAppointmentViaTimeZonesPage;
import com.teledentistry.util.ConstantValues;

public class ClinicBookAppointmentViaTimeZonesTest extends ClinicTestBase {

	ClinicBookAppointmentViaTimeZonesPage timeZonesPage;

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithAlaskaTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Alaska Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithAleutianTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Aleutian Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithArizonaTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Arizona Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithCentralTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Central Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithEastIndTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/East-Indiana Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithEasternTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Eastern Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithHawaiiTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Hawaii Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithIndStarkeTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Michigan Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithMichiganTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Michigan Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithMountainTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Mountain Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithPacificTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Pacific Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyBookAppointmentFormWithSamoaTimeZone(String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		timeZonesPage = new ClinicBookAppointmentViaTimeZonesPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		timeZonesPage.clickOnAddNewBookAppointmentLink();
		timeZonesPage.createBookAppointment(timeZone, clientName, doctorName, date, time);
		String actualStatus = timeZonesPage.getAlert();
		String alertContent = timeZonesPage.getAlertContent();
		String expectedStatus = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form with US/Samoa Time Zone");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatus, expectedStatus, "ERROR: Appointment Not Booked");
	}

}

package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicAddDoctorPage;
import com.teledentistry.util.ConstantValues;

public class ClinicAddDoctorTest extends ClinicTestBase {

	ClinicAddDoctorPage clinicAddDoctorPage;

	@Test(dataProvider = "dataProvider")
	public void verifyClinicAddDoctorForm(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipCode, String stateCode,
			String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredLocation) throws InterruptedException {
		clinicAddDoctorPage = new ClinicAddDoctorPage(driver);

		clinicHomePG.clickOnDoctorsLink();
		clinicAddDoctorPage.clickOnAddNewDoctorLink();

		String actualHeader = clinicAddDoctorPage.getAddDoctorFormHeader();
		String expectedHeader = ConstantValues.CLINIC_ADD_DOCTOR;
		testReport.info("Validate the Add Doctor Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		commonForms.createNewDoctor(firstname, lastname, phone, fax, email, password, dob, state, address, city,
				zipCode, stateCode, NPINumber, DEANumber, DEAState, status, uberization, preferredLocation);
		String actualStatusMessage = clinicAddDoctorPage.getAlert();
		String alertContent = clinicHomePG.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATED;
		testReport.info("Validate Add Doctor Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "ERROR: Doctor Details Not Added");

	}

	@Test(dataProvider = "dataProvider")
	public void verifyClinicAddDoctorFormWithInvalidEmail(String firstname, String lastname, String phone, String fax,
			String email, String password, String dob, String state, String address, String city, String zipCode,
			String stateCode, String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredLocation) throws InterruptedException {
		clinicAddDoctorPage = new ClinicAddDoctorPage(driver);

		clinicHomePG.clickOnDoctorsLink();
		clinicAddDoctorPage.clickOnAddNewDoctorLink();
		commonForms.createNewDoctorwithInvalidEmail(firstname, lastname, phone, fax, email, password, dob, state,
				address, city, zipCode, stateCode, NPINumber, DEANumber, DEAState, status, uberization,
				preferredLocation);
		String actualStatusMessage = clinicAddDoctorPage.getAlert();
		String alertContent = clinicAddDoctorPage.getAlertContent();
		testReport.info("Validate Add Doctor Form With Invalid Email");
		String expectedStatusMessage = ConstantValues.ERROR;
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "ERROR: Doctor Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyClinicAddDoctorFormWithInvalidPassword(String firstname, String lastname, String phone,
			String fax, String email, String password, String dob, String state, String address, String city,
			String zipCode, String stateCode, String NPINumber, String DEANumber, String DEAState, String status,
			String uberization, String preferredLocation) throws InterruptedException {
		clinicAddDoctorPage = new ClinicAddDoctorPage(driver);

		clinicHomePG.clickOnDoctorsLink();
		clinicAddDoctorPage.clickOnAddNewDoctorLink();
		commonForms.createNewDoctorwithInvalidPassword(firstname, lastname, phone, fax, email, password, dob, state,
				address, city, zipCode, stateCode, NPINumber, DEANumber, DEAState, status, uberization,
				preferredLocation);
		String actualStatusMessage = clinicAddDoctorPage.getAlert();
		String alertContent = clinicAddDoctorPage.getAlertContent();
		testReport.info("Validate Add Doctor Form With Invalid Password");
		String expectedStatusMessage = ConstantValues.ALERT;
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "ERROR: Doctor Details are Not Added");
	}

}

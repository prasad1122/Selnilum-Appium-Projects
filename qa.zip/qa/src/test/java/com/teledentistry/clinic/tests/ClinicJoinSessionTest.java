package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicJoinSessionPage;
import com.teledentistry.util.ConstantValues;

public class ClinicJoinSessionTest extends ClinicTestBase {

	ClinicJoinSessionPage clinicJoinSession;

	@Test
	public void joinSession() throws Exception {
		clinicJoinSession = new ClinicJoinSessionPage(driver);
		clinicHomePG.clickOnBookAppointmentsLink();
		clinicJoinSession.clickOnOPtionsLink();

		clinicJoinSession.switchToNewTab();

		String actualRoomHeader = clinicJoinSession.getRoomHeader();
		String expectedRoomHeader = ConstantValues.MEETING_ROOM_HEADER;
		testReport.info("Validate The Header");
		Assert.assertEquals(actualRoomHeader, expectedRoomHeader, "ERROR: Header is NOT Correct");

		clinicJoinSession.clickOnMeetingContinueLink();

		//clinicJoinSession.switchAndAcceptPopup();

		clinicJoinSession.clickToJoinSession();

		clinicJoinSession.clickonDisconnect();
	}

}

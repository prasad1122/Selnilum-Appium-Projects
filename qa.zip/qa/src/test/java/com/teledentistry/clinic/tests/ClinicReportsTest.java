package com.teledentistry.clinic.tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.teledentistry.clinic.pages.ClinicReportsPage;
import com.teledentistry.util.ConstantValues;

public class ClinicReportsTest extends ClinicTestBase{
	
	ClinicReportsPage clinicReportsPage;
	
	@Test(enabled=true)
	public void verifyDownloadPatientChatProcessListReports() throws InterruptedException {

		clinicReportsPage = new ClinicReportsPage(driver);

		clinicHomePG.clickOnReportsLink();

		clinicReportsPage.clickOnChatReportsLink();

		String actualHeader = clinicReportsPage.getReportsFormHeader();
		String expectedHeader = ConstantValues.CHAT_REPORTS_HEADER;
		testReport.info("Validate the Reports Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");


		clinicReportsPage.clickOnChatReportDownloadButton();

		Assert.assertTrue(clinicReportsPage.getResult(), "ERROR: Chat Report NOT Downloaded");
	}
	
	@Test(enabled=true)
	public void verifyDownloadConsultsReportsExcelFormat() throws InterruptedException, IOException {

		clinicReportsPage = new ClinicReportsPage(driver);

		clinicHomePG.clickOnReportsLink();

		clinicReportsPage.clickOnConsultsReportsLink();

		clinicReportsPage.clickOnClickToExportButton();
		
		clinicReportsPage.clickOnConsultsReportsXLSXDownloadButton();

		Assert.assertTrue(clinicReportsPage.isFileDownloaded(ConstantValues.CONSULTS_REPORTS_XLSX_FILE_NAME),
				"Failed to download consultS report Excel document");
	}
	
	@Test(enabled=true)
	public void verifyDownloadConsultsReportsPDFFormat() throws InterruptedException, IOException {

		clinicReportsPage = new ClinicReportsPage(driver);

		clinicHomePG.clickOnReportsLink();

		clinicReportsPage.clickOnConsultsReportsLink();

		clinicReportsPage.clickOnClickToExportButton();
		
		clinicReportsPage.clickOnConsultsReportsPDFDownloadButton();

		Assert.assertTrue(clinicReportsPage.isFileDownloaded(ConstantValues.CONSULTS_REPORTS_PDF_FILE_NAME),
				"Failed to download consultS report PDF document");
	}
	
	@Test(enabled=true)
	public void verifyDownloadOverflowConsultsReportsPDFFormat() throws InterruptedException, IOException {

		clinicReportsPage = new ClinicReportsPage(driver);

		clinicHomePG.clickOnReportsLink();

		clinicReportsPage.clickOnOverflowConsultsReportsLink();

		clinicReportsPage.clickOnClickToExportButton();
		
		clinicReportsPage.clickOnConsultsReportsPDFDownloadButton();

		Assert.assertTrue(clinicReportsPage.isFileDownloaded(ConstantValues.CONSULTS_REPORTS_PDF_FILE_NAME),
				"Failed to download consultS report PDF document");
	}
	
	@Test(enabled=true)
	public void verifyDownloadOverflowConsultsReportsExcelFormat() throws InterruptedException, IOException {

		clinicReportsPage = new ClinicReportsPage(driver);

		clinicHomePG.clickOnReportsLink();

		clinicReportsPage.clickOnOverflowConsultsReportsLink();

		clinicReportsPage.clickOnClickToExportButton();
		
		clinicReportsPage.clickOnConsultsReportsXLSXDownloadButton();

		Assert.assertTrue(clinicReportsPage.isFileDownloaded(ConstantValues.CONSULTS_REPORTS_XLSX_FILE_NAME),
				"Failed to download consultS report Excel document");
	}

}

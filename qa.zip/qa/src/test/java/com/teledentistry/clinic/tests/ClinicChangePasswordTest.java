package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicChangePasswordPage;
import com.teledentistry.util.ConstantValues;

public class ClinicChangePasswordTest extends ClinicTestBase {

	ClinicChangePasswordPage clinicChangePasswordPage;

	@Test(priority = 1, dataProvider = "dataProvider")
	public void verifyChangePasswordFormWithBelow8Characters(String oldPassword, String newPassword,
			String confirmPassword) throws InterruptedException {
		clinicChangePasswordPage = new ClinicChangePasswordPage(driver);

		clinicHomePG.clickOnChangePasswordModule();

		clinicChangePasswordPage.clinicChangePasswordWithInvalidData(oldPassword, newPassword, confirmPassword);
		String actualAlertMessage = clinicChangePasswordPage.getAlert();
		String alertConent = clinicChangePasswordPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate The Change Password Form with Below 8 Charatcers");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Password not Updated");
	}

	@Test(priority = 2, dataProvider = "dataProvider")
	public void verifyChangePasswordFormWithWrongOldPassword(String oldPassword, String newPassword,
			String confirmPassword) throws InterruptedException {
		clinicChangePasswordPage = new ClinicChangePasswordPage(driver);

		clinicHomePG.clickOnChangePasswordModule();

		clinicChangePasswordPage.clinicChangePasswordWithInvalidData(oldPassword, newPassword, confirmPassword);
		String actualAlertMessage = clinicChangePasswordPage.getAlert();
		String alertConent = clinicChangePasswordPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate The Change Password Form with Wrong Old Password");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Clinic Password not Updated");
	}

	@Test(priority = 3, dataProvider = "dataProvider")
	public void verifyChangePasswordForm(String oldPassword, String newPassword, String confirmPassword)
			throws InterruptedException {
		clinicChangePasswordPage = new ClinicChangePasswordPage(driver);

		clinicHomePG.clickOnChangePasswordModule();

		String actualHeader = clinicChangePasswordPage.getFormHeader();
		String expectedHeader = ConstantValues.CHANGEPASSWORD_FORM_HEADER;
		testReport.info("Validate the Change Password Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		clinicChangePasswordPage.clinicChangePassword(oldPassword, newPassword, confirmPassword);
		String actualRedirectHeader = clinicChangePasswordPage.getGeneralReportHeader();
		String expectedRedirectHeader = ConstantValues.GENERAL_REPORT_HEADER;
		testReport.info("Validate The Change Password Form");
		Assert.assertEquals(actualRedirectHeader, expectedRedirectHeader, "ERROR: Clinic Password not Updated");
	}

}

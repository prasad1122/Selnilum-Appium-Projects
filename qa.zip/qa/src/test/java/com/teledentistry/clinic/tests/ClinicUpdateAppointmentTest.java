package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicUpdateAppointmentPage;
import com.teledentistry.util.ConstantValues;

public class ClinicUpdateAppointmentTest extends ClinicTestBase {
	
	ClinicUpdateAppointmentPage clinicUpdateAppointment;
	
	@Test(dataProvider = "dataProvider")
	public void verifyUpdateAppointmentForm(String clinic, String clientName, String doctorName, String date, String time ) throws Exception
	{
		clinicUpdateAppointment=new ClinicUpdateAppointmentPage(driver);
		
		clinicHomePG.clickOnBookAppointmentsLink();
		clinicUpdateAppointment.updateAppointmentLink();
		String actualHeader = clinicUpdateAppointment.getUpdateAppointmentFormHeader();
		String expectedHeader = ConstantValues.UPDATE_APPOINTMENT;
        testReport.info("Validate the Update Appointment Form Heading");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Heading is NOT Correct");
		
		clinicUpdateAppointment.updateAppintmentForm(clinic, clientName, doctorName, date, time);
	    String actualStatusMesaage=	clinicUpdateAppointment.getAlert();
		String alertmessage= clinicUpdateAppointment.getAlertContent();
		String expectedStatusMessage = ConstantValues.SUCCESS;
		testReport.info("Validate Admin Update Appointment Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
	    Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Appointment Details are Not Updated");
	}

}

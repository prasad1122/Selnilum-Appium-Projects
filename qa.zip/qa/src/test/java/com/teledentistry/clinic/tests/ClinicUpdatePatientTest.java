package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicUpdatePatientPage;
import com.teledentistry.util.ConstantValues;

public class ClinicUpdatePatientTest extends ClinicTestBase {

	ClinicUpdatePatientPage clinicUpdatePatientPage;

	@Test(dataProvider = "dataProvider")
	public void verifyUpdatePatientForm(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String ssn, String address,
			String city, String zipcode, String state) throws InterruptedException {
		clinicUpdatePatientPage = new ClinicUpdatePatientPage(driver);

		clinicHomePG.clickOnClinicPatientsLink();
		clinicUpdatePatientPage.clickOnUpdatePatientLink();
		String actualHeader = clinicUpdatePatientPage.getUpdatePatientFormHeader();
		String expectedHeader = "Update Patient";
		testReport.info("Validate the Update Patient Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");
		commonForms.UpdatePatientDetails(firstname, lastname, phone, dob, email, password, feet, inches, gender, weight,
				ssn, address, city, zipcode, state);
		String actualAlertMessage = clinicUpdatePatientPage.getAlert();
		String alertConent = clinicUpdatePatientPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Patient Form");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Patient Details are not Updated");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyUpdatePatientFormWithDiffCity(String firstname, String lastname, String phone, String dob,
			String email, String password, String feet, String inches, String gender, String weight, String ssn,
			String address, String city, String zipcode, String state) throws InterruptedException {
		clinicUpdatePatientPage = new ClinicUpdatePatientPage(driver);

		clinicHomePG.clickOnClinicPatientsLink();
		clinicUpdatePatientPage.clickOnUpdatePatientLink();

		commonForms.UpdatePatientDetails(firstname, lastname, phone, dob, email, password, feet, inches, gender, weight,
				ssn, address, city, zipcode, state);
		String actualAlertMessage = clinicUpdatePatientPage.getAlert();
		String alertConent = clinicUpdatePatientPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Patient Form With Different City");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Patient Details are not Updated");
	}

}

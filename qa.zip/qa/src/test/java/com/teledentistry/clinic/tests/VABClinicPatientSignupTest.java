package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.VABClinicPatientSignupPage;
import com.teledentistry.util.ConstantValues;

public class VABClinicPatientSignupTest extends ClinicTestBase {

	VABClinicPatientSignupPage vabClinicPatientSignupPage;

	@Test(dataProvider = "dataProvider")
	public void verifyVABClinicPatientSignupForm(String firstname, String lastname, String phone, String email,
			String dateOfBirth, String ssn, String feet, String inches, String weight, String city, String state,
			String zipCode, String painExp, String opinion, String drugAllergie) {
		vabClinicPatientSignupPage = new VABClinicPatientSignupPage(driver);
		String actualHeader = vabClinicPatientSignupPage.getFormHeader();
		String expectedHeader = ConstantValues.PATIENT_SIGNUP_FORM_HEADER;
		testReport.info("Validate the Patient Signup Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		vabClinicPatientSignupPage.patientSignup(firstname, lastname, phone, email);
		testReport.info("Validate The Patient Signup Form");
		boolean status = vabClinicPatientSignupPage.getSignupStatus();
		Assert.assertTrue(status, "ERROR: Signup Failed");

		vabClinicPatientSignupPage.personalDetailsValidation(dateOfBirth, ssn, feet, inches, weight, city, state,
				zipCode);

		vabClinicPatientSignupPage.dentalHistoryValidation(painExp, opinion);

		vabClinicPatientSignupPage.medicalHistoryValidation(drugAllergie);

		String actualHeader2 = vabClinicPatientSignupPage.getDestionationPageFormHeader();
		String expectedHeader2 = ConstantValues.VAB_DESTINATION_PAGE_HEADER;
		testReport.info("Validate the Destination Page Header");
		Assert.assertEquals(actualHeader2, expectedHeader2, "ERROR: Hedaer is NOT Correct");

	}

	@Test(dataProvider = "dataProvider")
	public void verifyVABClinicPatientPasswordCreation(String firstname, String lastname, String phone, String email,
			String newPassword, String conformPassword) throws InterruptedException {
		vabClinicPatientSignupPage = new VABClinicPatientSignupPage(driver);

		vabClinicPatientSignupPage.patientSignup(firstname, lastname, phone, email);

		testReport.info("Validate The Patient Paasword Creation");

		vabClinicPatientSignupPage.ResetPasswordLinkValidation();

		vabClinicPatientSignupPage.clickLink();

		vabClinicPatientSignupPage.changePasswordLink();

		vabClinicPatientSignupPage.createPassword(newPassword, conformPassword);
		
		String actualHeader = vabClinicPatientSignupPage.getPatientLoginFormHeader();
		String expectedHeader = ConstantValues.PATIENT_LOGIN_FORM_HEADER;
		testReport.info("Validate The Password creation Form");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Password not Created");

	}

}

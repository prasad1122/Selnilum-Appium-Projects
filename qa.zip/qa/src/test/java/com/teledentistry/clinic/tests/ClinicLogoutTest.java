package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicLogoutPage;
import com.teledentistry.util.ConstantValues;

public class ClinicLogoutTest extends ClinicTestBase {

	ClinicLogoutPage clinicLogoutPage;

	@Test(enabled = true)
	public void verifyLogoutButton() throws InterruptedException {
		clinicLogoutPage = new ClinicLogoutPage(driver);
		clinicHomePG.clickOnLogoutButton();
		String actualHeader = clinicLogoutPage.getLoginPageHedaer();
		String expectedHeader = ConstantValues.CLINIC_LOGIN_FORM_HEADER;
		testReport.info("Verify The Logout Button");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Not Working Logout Button");
	}

}

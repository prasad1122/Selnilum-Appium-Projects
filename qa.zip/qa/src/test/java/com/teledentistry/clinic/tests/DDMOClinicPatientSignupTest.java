package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.DDMOClinicPatientSignupPage;
import com.teledentistry.util.ConstantValues;

public class DDMOClinicPatientSignupTest extends ClinicTestBase {

	DDMOClinicPatientSignupPage ddmoClinicPatientSignupPage;

	@Test(dataProvider = "dataProvider")
	public void verifyDDMOClinicPatientSignupForm(String firstname, String lastname, String phone, String email,
			String address, String city, String state, String zipcode, String dateOfBirth, String ssn, String feet,
			String inches, String weight, String painExp, String opinion, String drugAllergie)
			throws InterruptedException {
		ddmoClinicPatientSignupPage = new DDMOClinicPatientSignupPage(driver);
		String actualHeader = ddmoClinicPatientSignupPage.getFormHeader();
		String expectedHeader = ConstantValues.DDMO_PATIENT_SIGNUP_FORM_HEADER;
		testReport.info("Validate the Patient Signup Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		ddmoClinicPatientSignupPage.patientSignup(firstname, lastname, phone, email, address, city, state, zipcode);
		testReport.info("Validate The Patient Signup Form");

		String actualStatusMessage = ddmoClinicPatientSignupPage.getAlert();
		String alertContent = ddmoClinicPatientSignupPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.SUCCESS;
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "ERROR: Signup Failed");

		ddmoClinicPatientSignupPage.personalDetailsValidation(dateOfBirth, ssn, feet, inches, weight);

		ddmoClinicPatientSignupPage.dentalHistoryValidation(painExp, opinion);

		ddmoClinicPatientSignupPage.medicalHistoryValidation(drugAllergie);

		String actualHeader2 = ddmoClinicPatientSignupPage.getDestionationPageFormHeader();
		String expectedHeader2 = ConstantValues.DDMO_DESTINATION_PAGE_HEADER;
		testReport.info("Validate the Destination Page Header");
		Assert.assertEquals(actualHeader2, expectedHeader2, "ERROR: Hedaer is NOT Correct");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyDDMOClinicPatientPasswordCreation(String firstname, String lastname, String phone, String email,
			String address, String city, String state, String zipcode, String dateOfBirth, String ssn, String feet,
			String inches, String weight, String painExp, String opinion, String drugAllergie, String newPassword,
			String confirmPassword) throws InterruptedException {
		ddmoClinicPatientSignupPage = new DDMOClinicPatientSignupPage(driver);

		ddmoClinicPatientSignupPage.patientSignup(firstname, lastname, phone, email, address, city, state, zipcode);

		testReport.info("Validate The Patient Paasword Creation");

		ddmoClinicPatientSignupPage.ResetPasswordLinkValidation();

		ddmoClinicPatientSignupPage.clickLink();

		ddmoClinicPatientSignupPage.changePasswordLink();

		ddmoClinicPatientSignupPage.createPassword(newPassword, confirmPassword);
		
		String actualHeader = ddmoClinicPatientSignupPage.getPatientLoginFormHeader();
		String expectedHeader = ConstantValues.PATIENT_LOGIN_FORM_HEADER;
		testReport.info("Validate The Password creation Form");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Password not Created");

	}

}

package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicBookAppointmentPage;
import com.teledentistry.util.ConstantValues;

public class ClinicBookAppointmentTest extends ClinicTestBase {

	ClinicBookAppointmentPage bookApointmentPage;

	@Test(dataProvider = "dataProvider")
	public void verifyClinicBookAppointmentForm(String timeZone, String clientname, String doctorname, String date,
			String time) throws InterruptedException {
		bookApointmentPage = new ClinicBookAppointmentPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		bookApointmentPage.clickOnAddNewBookAppointmentLink();

		String actualHeader = bookApointmentPage.getBookAppointmentFormHeader();
		String expectedHeader = ConstantValues.BOOK_APPOINTMENT;
		testReport.info("Validate the Book Appointment Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		bookApointmentPage.createBookAppointment(timeZone, clientname, doctorname, date, time);
		String actualStatusMesaage = bookApointmentPage.getAlert();
		String alertContent = bookApointmentPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.SUCCESS;
		testReport.info("Validate Book Appointment Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Appointment Not Booked");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyClinicBookAppointmentWithInvalidDate(String timeZone, String clientname, String doctorname,
			String date, String time) throws InterruptedException {
		bookApointmentPage = new ClinicBookAppointmentPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		bookApointmentPage.clickOnAddNewBookAppointmentLink();
		bookApointmentPage.createBookAppointmentWithInvalidDate(timeZone, clientname, doctorname, date, time);
		String actualStatusMesaage = bookApointmentPage.getAlert();
		String alertContent = bookApointmentPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.ERROR;
		testReport.info("Validate Book Appointment Form");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage,
				"ERROR: Book Appointment Details are Not Added");
	}

	@Test(dataProvider = "dataProvider")
	public void verifyClinicBookAppointmentWithPastTime(String timeZone, String clientname, String doctorname,
			String date, String time) throws InterruptedException {
		bookApointmentPage = new ClinicBookAppointmentPage(driver);

		clinicHomePG.clickOnBookAppointmentsLink();
		bookApointmentPage.clickOnAddNewBookAppointmentLink();
		bookApointmentPage.createBookAppointmentWithInvalidTime(timeZone, clientname, doctorname, date, time);
		String actualStatusMesaage = bookApointmentPage.getAlert();
		String alertContent = bookApointmentPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.ERROR;
		testReport.info("Validate Book Appointment Form With Past Time");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage,
				"ERROR: Book Appointment Details are Added");
	}  

}

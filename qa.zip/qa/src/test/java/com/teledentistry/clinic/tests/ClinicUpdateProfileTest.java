package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicUpdateProfilePage;
import com.teledentistry.util.ConstantValues;

public class ClinicUpdateProfileTest extends ClinicTestBase {

	ClinicUpdateProfilePage clinicUpdateProfilePage;

	@Test(dataProvider = "dataProvider")
	public void verifyClinicUpdateProfileForm(String clinicName, String phoneNumber, String webSiteURL)
			throws Exception {
		clinicUpdateProfilePage = new ClinicUpdateProfilePage(driver);

		clinicHomePG.clickOnProfileLink();
		String actualTitle = clinicUpdateProfilePage.getUpdateProfileFormHeader();
		String expectedTitle = ConstantValues.UPDATE_PROFILE;
		testReport.info("Validate the Update Profile Form Title");
		Assert.assertEquals(actualTitle, expectedTitle, "ERROR: Form Title is NOT Correct");

		commonForms.updateProfileForm(clinicName, phoneNumber, webSiteURL);
		String actualStatusMesaage = clinicUpdateProfilePage.getAlert();
		String alertmessage = clinicUpdateProfilePage.getAlertContent();
		String expectedStatusMessage = ConstantValues.SUCCESS;
		testReport.info("Validate Update Profile Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Profile details are not Updated");

	}

}

package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicUpdateDoctorPage;
import com.teledentistry.util.ConstantValues;

public class ClinicUpdateDoctorTest extends ClinicTestBase {

	ClinicUpdateDoctorPage clinicUpdateDoctorPage;

	@Test(dataProvider = "dataProvider")
	public void verifyUpdateDoctorForm(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipcode, String statecode,
			String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredlocation) throws Exception {
		clinicUpdateDoctorPage = new ClinicUpdateDoctorPage(driver);

		clinicHomePG.clickOnDoctorsLink();
		clinicUpdateDoctorPage.clickOnUpdateDoctorLink();
		String actualTitle = clinicUpdateDoctorPage.getUpdateDoctorFormHeader();
		String expectedTitle = ConstantValues.UPDATE_DOCTOR;
		testReport.info("Validate the Update Doctor Form Title");
		Assert.assertEquals(actualTitle, expectedTitle, "ERROR: Form Title is NOT Correct");

		commonForms.updateDoctorForm(firstname, lastname, phone, fax, email, password, dob, state, address,
				city, zipcode, statecode, NPINumber, DEANumber, DEAState, status, uberization, preferredlocation);
		String actualStatusMesaage = clinicUpdateDoctorPage.getAlert();
		String alertmessage = clinicUpdateDoctorPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Doctor Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Doctor details are not Updated");

	}
	
	@Test(dataProvider = "dataProvider")
	public void verifyUpdateDoctorFormWithDiffCity(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipcode, String statecode,
			String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredlocation) throws Exception {
		clinicUpdateDoctorPage = new ClinicUpdateDoctorPage(driver);

		clinicHomePG.clickOnDoctorsLink();
		clinicUpdateDoctorPage.clickOnUpdateDoctorLink();

		commonForms.updateDoctorForm(firstname, lastname, phone, fax, email, password, dob, state, address,
				city, zipcode, statecode, NPINumber, DEANumber, DEAState, status, uberization, preferredlocation);
		String actualStatusMesaage = clinicUpdateDoctorPage.getAlert();
		String alertmessage = clinicUpdateDoctorPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATED;
		testReport.info("Validate Update Doctor Form");
		logger.info("################# Alert Message: " + alertmessage + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Doctor details are not Updated");

	}

}

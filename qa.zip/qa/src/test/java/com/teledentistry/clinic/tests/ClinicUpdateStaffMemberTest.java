package com.teledentistry.clinic.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.clinic.pages.ClinicUpdateStaffMemberPage;
import com.teledentistry.util.ConstantValues;

public class ClinicUpdateStaffMemberTest extends ClinicTestBase {

	ClinicUpdateStaffMemberPage clinicUpdateStaffMemberPage;

	@Test(dataProvider = "dataProvider")
	public void verifyUpdateStaffMemberForm(String name, String email, String password) throws InterruptedException {
		clinicUpdateStaffMemberPage = new ClinicUpdateStaffMemberPage(driver);

		clinicHomePG.clickOnStaffMembersLink();
		clinicUpdateStaffMemberPage.clickOnUpdateStaffMemberLink();
		String actualHeader = clinicUpdateStaffMemberPage.getUpdateStaffMemberFormHeader();
		String expectedHeader = ConstantValues.UPDATE_STAFF_MEMBER_FORM_HEADER;
		testReport.info("Validate the Update Staff Member Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");
		clinicUpdateStaffMemberPage.UpdateStaffMemberDetails(name, email, password);
		String actualAlertMessage = clinicUpdateStaffMemberPage.getAlert();
		String alertConent = clinicUpdateStaffMemberPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.STAFF_MEMBER_UPDATED;
		testReport.info("Validate Update Staff Member Form");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Staff Member Details are not Updated");
	}

}

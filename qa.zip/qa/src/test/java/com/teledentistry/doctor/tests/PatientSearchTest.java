package com.teledentistry.doctor.tests;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.doctor.pages.PatientSearchPage;
import com.teledentistry.util.ConstantValues;

public class PatientSearchTest extends DoctorTestBase {

	PatientSearchPage patientSearchPage;

	/**
	 * Validate if Search result is displayed corresponding to the string which was
	 * searched
	 * 
	 * @throws InterruptedException
	 */
	@Test(priority=1, enabled=true)
	public void verifyPatientSearch() throws InterruptedException {

		patientSearchPage = new PatientSearchPage(driver);

		doctorHomePG.clickOnPatientsLink();

		patientSearchPage.searchItem();

		String actualHeader = patientSearchPage.getHeader();
		String expectedHeader = ConstantValues.PATIENT_PAGE_HEADER;
		testReport.info("Validate the Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is Not Correct");

		List<WebElement> searchResult = patientSearchPage.getSearchResult();	
		testReport.info("Validate the Search Result with Size");
		Assert.assertNotEquals(searchResult.size(), 0);
		testReport.info("Validate the Search Result");
		for (int i = 0; i < searchResult.size(); i++) {
			String temp = searchResult.get(i).getText();

			if ((temp.contains(ConstantValues.SEARCH_KEYWORD))) {

				Assert.assertTrue(true, ConstantValues.SEARCH_KEYWORD + " is displayed on Patient Name: " + temp);

			} else {

				Assert.assertTrue(false, ConstantValues.SEARCH_KEYWORD + " is not displayed on Patient Name: " + temp);

			}

		}
	}

}

package com.teledentistry.doctor.tests;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.doctor.pages.DoctorJoinSessionPage;
import com.teledentistry.util.ConstantValues;

public class DoctorJoinSessionTest extends DoctorTestBase {
	
	DoctorJoinSessionPage doctorJoinSessionPage;
	
	@Test()
	public void verifyDocotrJoinSession() throws InterruptedException, AWTException
	{
		doctorJoinSessionPage=new DoctorJoinSessionPage(driver);
		
		doctorHomePG.clickOnJoinVideoCallModuleLink();
		
		String actualHeader = doctorJoinSessionPage.getVideoCallRoomHeader();
		String expectedHeader = ConstantValues.JOIN_VIDEO_CALL;
	    testReport.info("Validate the Add Patient Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is NOT Correct");

		doctorJoinSessionPage.clickOnJoinSessionLink();
		
		doctorJoinSessionPage.switchToNewTab();
		
		doctorJoinSessionPage.clickOnMeetingContinueLink();
		
		doctorJoinSessionPage.clickToJoinSession();
		
		doctorJoinSessionPage.clickToDisconnect();	
		
	} 

}

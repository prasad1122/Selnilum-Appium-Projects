package com.teledentistry.doctor.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.doctor.pages.DoctorGalleryPage;
import com.teledentistry.util.ConstantValues;

public class DoctorGalleryTest extends DoctorTestBase {

	DoctorGalleryPage doctorGalleryPage;

	@Test(priority=1, enabled=true)
	public void verifyImages() throws InterruptedException {

		doctorGalleryPage = new DoctorGalleryPage(driver);

		doctorHomePG.clickOnPatientsLink();

		doctorGalleryPage.clickOnGalleryLink();

		String actualHeader = doctorGalleryPage.getHeader();
		String expectedHeader = ConstantValues.GALLERY_HEADER;
		testReport.info("Validate the Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is Not Correct");

		int imagesSize = doctorGalleryPage.getImageCountOnGallery();
		testReport.info("Validate the Visible Images");
		Assert.assertNotEquals(imagesSize, 0);

	}

	@Test(priority=2, enabled=true)
	public void verifySendUploadLinkButton() throws InterruptedException {

		doctorGalleryPage = new DoctorGalleryPage(driver);

		doctorHomePG.clickOnPatientsLink();

		doctorGalleryPage.clickOnGalleryLink();

		doctorGalleryPage.clickOnSendUploadLink();

		String actualStatusMessage = doctorGalleryPage.getAlert();
		String alertContent = doctorGalleryPage.getAlertContent();
		String expectedStatusMessage = ConstantValues.SUCCESS;
		testReport.info("Validate The Send Upload Link Button");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMessage, expectedStatusMessage, "ERROR: Upload Link is Not Sent");

	}

}

package com.teledentistry.doctor.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.doctor.pages.DoctorProfileUpdatePage;
import com.teledentistry.util.ConstantValues;

public class DoctorProfileUpdateTest extends DoctorTestBase {
	DoctorProfileUpdatePage doctorUpdateProfilePage;

	@Test(dataProvider = "dataProvider")
	public void verifyDoctorProfileUpdateForm(String address, String city, String zipcode, String state, String dateOfBirth)
			throws InterruptedException {
		doctorUpdateProfilePage = new DoctorProfileUpdatePage(driver);
		doctorHomePG.clickOnDoctorProfileLink();
		String actualFormHeader = doctorUpdateProfilePage.getupdateDoctorProfileFormHeader();
		String expectedFormHeader = ConstantValues.UPDATE_DOCTOR_PROFILE_HEADER;
		testReport.info("Validate doctor Update Profile Header");
		Assert.assertEquals(actualFormHeader, expectedFormHeader, "ERROR: Form Title is NOT Correct");
		doctorUpdateProfilePage.doctorProfileUpdate(address, city, zipcode, state, dateOfBirth);
		String actualStatusMesaage = doctorUpdateProfilePage.getAlert();
		String alertContent = doctorUpdateProfilePage.getAlertContent();
		String expectedStatusMessage = ConstantValues.UPDATE_DOCTOR_PROFILE;
		testReport.info("Validate the Doctor Profile Update");
		logger.info("################# Alert Message: " + alertContent + " #################");
		Assert.assertEquals(actualStatusMesaage, expectedStatusMessage, "ERROR: Doctor Details are not Updated");
	}

}

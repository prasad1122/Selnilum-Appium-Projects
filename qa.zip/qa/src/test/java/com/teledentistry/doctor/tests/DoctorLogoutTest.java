package com.teledentistry.doctor.tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.teledentistry.doctor.pages.DoctorLogoutPage;
import com.teledentistry.util.ConstantValues;

public class DoctorLogoutTest extends DoctorTestBase {

	DoctorLogoutPage doctorLogoutPage;

	@Test(enabled = true)
	public void verifyLogoutButton() throws InterruptedException {
		doctorLogoutPage = new DoctorLogoutPage(driver);
		doctorHomePG.clickOnLogoutButton();
		String actualHeader = doctorLogoutPage.getLoginPageHedaer();
		String expectedHeader = ConstantValues.DOCTOR_LOGIN_FORM_HEADER;
		testReport.info("Verify The Logout Button");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Not Working Logout Button");
	}

}

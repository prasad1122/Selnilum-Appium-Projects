package com.teledentistry.doctor.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.doctor.pages.DoctorChangePasswordPage;
import com.teledentistry.util.ConstantValues;

public class DoctorChangePasswordTest extends DoctorTestBase {

	DoctorChangePasswordPage doctorChangePasswordPage;

	@Test(priority = 1, dataProvider = "dataProvider")
	public void verifyChangePasswordFormWithBelow8Characters(String oldPassword, String newPassword,
			String confirmPassword) throws InterruptedException {
		doctorChangePasswordPage = new DoctorChangePasswordPage(driver);

		doctorHomePG.clickOnChangePasswordModule();

		doctorChangePasswordPage.doctorChangePasswordWithInvalidData(oldPassword, newPassword, confirmPassword);
		String actualAlertMessage = doctorChangePasswordPage.getAlert();
		String alertConent = doctorChangePasswordPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate The Change Password Form with Below 8 Charatcers");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Doctor Password not Updated");
	}

	@Test(priority = 2, dataProvider = "dataProvider")
	public void verifyChangePasswordFormWithWrongOldPassword(String oldPassword, String newPassword,
			String confirmPassword) throws InterruptedException {
		doctorChangePasswordPage = new DoctorChangePasswordPage(driver);

		doctorHomePG.clickOnChangePasswordModule();

		doctorChangePasswordPage.doctorChangePasswordWithInvalidData(oldPassword, newPassword, confirmPassword);
		String actualAlertMessage = doctorChangePasswordPage.getAlert();
		String alertConent = doctorChangePasswordPage.getAlertContent();
		String expectedAlertMessage = ConstantValues.ERROR;
		testReport.info("Validate The Change Password Form with Same Password");
		logger.info("################# Alert Message: " + alertConent + " #################");
		Assert.assertEquals(actualAlertMessage, expectedAlertMessage, "ERROR: Doctor Password not Updated");
	}

	@Test(priority = 3, dataProvider = "dataProvider")
	public void verifyChangePasswordForm(String oldPassword, String newPassword, String confirmPassword)
			throws InterruptedException {
		doctorChangePasswordPage = new DoctorChangePasswordPage(driver);

		doctorHomePG.clickOnChangePasswordModule();

		String actualHeader = doctorChangePasswordPage.getFormHeader();
		String expectedHeader = ConstantValues.CHANGEPASSWORD_FORM_HEADER;
		testReport.info("Validate the Change Password Form Title");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Form Title is NOT Correct");

		doctorChangePasswordPage.doctorChangePassword(oldPassword, newPassword, confirmPassword);
		
		String actualRedirectHeader = doctorChangePasswordPage.getGeneralHeader();
		String expectedRedirectHeader = ConstantValues.GENERAL_HEADER;
		testReport.info("Validate The Change Password Form");
		Assert.assertEquals(actualRedirectHeader, expectedRedirectHeader, "ERROR: Doctor Password not Updated");
	}
}

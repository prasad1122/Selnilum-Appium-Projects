package com.teledentistry.doctor.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.teledentistry.doctor.pages.PatientEdocUpdatedDeatilsPage;
import com.teledentistry.util.ConstantValues;

public class PatientEdocUpdatedDeatilsTest extends DoctorTestBase {

	PatientEdocUpdatedDeatilsPage patientEdocUpdatedDeatilsPage;

	@Test(priority=1, enabled=true)
	public void verifyPatientEdocUpdatedDetails() throws InterruptedException {

		patientEdocUpdatedDeatilsPage = new PatientEdocUpdatedDeatilsPage(driver);

		doctorHomePG.clickOnPatientsLink();

		patientEdocUpdatedDeatilsPage.clickOnEdoclink();

		String actualHeader = patientEdocUpdatedDeatilsPage.getHeader();
		String expectedHeader = ConstantValues.EDOC_HEADER;
		testReport.info("Validate the Header");
		Assert.assertEquals(actualHeader, expectedHeader, "ERROR: Header is Not Correct");

		patientEdocUpdatedDeatilsPage.clickOnEdocumentActiveLink();
		String actualFirstFormHeader = patientEdocUpdatedDeatilsPage.getFirstFormHeader();
		String expectedFirstFormHeader = ConstantValues.EDOC_FIRST_FORM_HEADER;
		testReport.info("Validate the First Form Header");
		Assert.assertEquals(actualFirstFormHeader, expectedFirstFormHeader, "ERROR: Header is Not Correct");

		patientEdocUpdatedDeatilsPage.clickOnNextButton();
		String actualSecondFormHeader = patientEdocUpdatedDeatilsPage.getSecondFormHeader();
		String expectedSecondFormHeader = ConstantValues.EDOC_SECOND_FORM_HEADER;
		testReport.info("Validate the Second Form Header");
		Assert.assertEquals(actualSecondFormHeader, expectedSecondFormHeader, "ERROR: Header is Not Correct");

		patientEdocUpdatedDeatilsPage.clickOnNextButton();
		String actualThirdFormHeader = patientEdocUpdatedDeatilsPage.getThirdFormHeader();
		String expectedThirdFormHeader = ConstantValues.EDOC_THIRD_FORM_HEADER;
		testReport.info("Validate the Third Form Header");
		Assert.assertEquals(actualThirdFormHeader, expectedThirdFormHeader, "ERROR: Header is Not Correct");

		patientEdocUpdatedDeatilsPage.clickOnNextButton();

	}

}

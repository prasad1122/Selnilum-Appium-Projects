package com.teledentistry.patient.pages;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientImageUploadViaCameraPage extends PatientPageBase {

	// PageElements
	@FindBy(xpath = "//button[@id='camera']")
	WebElement cameraLink;

	@FindBy(xpath = "//h2[contains(text(),'Take Pictures From Camera')]")
	WebElement header;

	@FindBy(xpath = "//button[@id='capture']")
	WebElement captureButton;

	@FindBy(css = ".file.box.rounded-md")
	List<WebElement> galleryCount;

	public PatientImageUploadViaCameraPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public void clickOnCameraLink() throws InterruptedException, AWTException {
		waitForVisible(driver, cameraLink);
		cameraLink.click();
		Thread.sleep(8000);
	}

	public String getHeader() {
		waitForVisible(driver, header);
		return header.getText();
	}

	public void clickOnCapture() throws InterruptedException {
		waitForVisible(driver, captureButton);
		captureButton.click();
		Thread.sleep(8000);
	}

	public int getImageCountOnGallery() throws InterruptedException {
		PatientHomePage patientHomePage = new PatientHomePage(driver);
		patientHomePage.clickOnGalleryLink();
		waitForMultipleVisible(driver, galleryCount);
		List<WebElement> elements = galleryCount;
		int size = elements.size();
		return size;
	}

}

package com.teledentistry.patient.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PatientProfileUpdatePage extends PatientPageBase {

	// PageElements

	@FindBy(xpath = "//h2[contains(text(),'Profile')]")
	WebElement formHeader;

	@FindBy(id = "feet")
	WebElement feetDropdown;

	@FindBy(id = "inches")
	WebElement inchesDropdown;

	@FindBy(id = "address")
	WebElement addressTextField;

	@FindBy(id = "city")
	WebElement cityTextField;

	@FindBy(id = "zip")
	WebElement zipCodeTextField;

	@FindBy(xpath = "//button[@type='submit']")
	WebElement submitButton;

	@FindBy(id = "state")
	WebElement stateDropdown;

	// Initializing the Page Objects:

	public PatientProfileUpdatePage(WebDriver driver) {
		super(driver);
	}

	/**
	 * Enter Patient Details in Update Profile form with valid data
	 * 
	 * @param feet
	 * @param inches
	 * @param address
	 * @param city
	 * @param zipCode
	 * @throws InterruptedException
	 */

	public void patientProfileUpdate(String feet, String inches, String address, String state, String city,
			String zipCode) throws InterruptedException {
		waitForVisible(driver, feetDropdown);
		Select selectFeet = new Select(feetDropdown);
		selectFeet.selectByVisibleText(feet);

		Select selectInches = new Select(inchesDropdown);
		selectInches.selectByVisibleText(inches);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(3000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(8000);
		submitButton.click();
		Thread.sleep(2000);
	}

	public String getPatientUpdateProfileFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

package com.teledentistry.patient.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientLogoutPage extends PatientPageBase {

	// PageElements
	@FindBy(xpath = "//h2[normalize-space()='Patient Login']")
	WebElement loginFormHeader;

	public PatientLogoutPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public String getLoginPageHedaer() {
		waitForVisible(driver, loginFormHeader);
		return loginFormHeader.getText();
	}

}

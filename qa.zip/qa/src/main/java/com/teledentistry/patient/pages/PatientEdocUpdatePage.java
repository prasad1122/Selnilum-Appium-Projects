package com.teledentistry.patient.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PatientEdocUpdatePage extends PatientPageBase {

	// PageElements

	@FindBy(linkText = "Details")
	WebElement detailsLink;

	@FindBy(xpath = "//h2[contains(text(),'E-Documents')]")
	WebElement edocumentHeader;

	@FindBy(id = "save")
	WebElement nextButton;

	@FindBy(css = "#select2-feet-container")
	WebElement feetDropdown;

	@FindBy(css = "#select2-inches-container")
	WebElement inchesDropdown;
	
	@FindBy(css = "#select2-feet-results>li")
	List<WebElement> feetDropdownList;

	@FindBy(css = "#select2-inches-results>li")
	List<WebElement> inchesDropdownList;

	@FindBy(id = "City")
	WebElement cityTextField;

	@FindBy(id = "weight")
	WebElement weightTextField;

	@FindBy(id = "zip")
	WebElement zipCodeTextField;

	@FindBy(name = "Are-you-currently-experiencing-dental-pain-or-discomfort")
	WebElement dentalPainExpDropdown;

	@FindBy(name = "Are-you-interested-in-getting-your-teeth-straightened-with-aligners")
	WebElement opinionDropdown;

	@FindBy(id = "Do-you-have-any-known-drug-allergies")
	WebElement drugAllergieDropdown;

	@FindBy(xpath = "//h1[normalize-space()='Dental History Information']")
	WebElement dentalHistoryFormHeader;

	@FindBy(xpath = "//h1[normalize-space()='Medical History']")
	WebElement medicalHistoryFormHeader;

	@FindBy(xpath = "//h2[normalize-space()='Request Consult']")
	WebElement targetPageFromHeader;

	// Initializing the Page Objects:
	public PatientEdocUpdatePage(WebDriver driver) {
		super(driver);
	}

	public void clickOnDetailsLink() throws InterruptedException {
		waitForVisible(driver, detailsLink);
		detailsLink.click();
		// Thread.sleep(5000);
	}

	public String getEdocumentsHeader() throws InterruptedException {
		waitForVisible(driver, edocumentHeader);
		return edocumentHeader.getText();
	}

	public void clickOnNextButton() throws InterruptedException {
		waitForVisible(driver, nextButton);
		nextButton.click();
		Thread.sleep(2000);
	}

	// OperationalMethods

	/**
	 * Enter Personal Details in Personal Information form with valid data
	 * 
	 * @param feet
	 * @param inches
	 * @param weight
	 * @param city
	 * @param zipCode
	 * @throws InterruptedException
	 */

	public void updatePersonalInformation(String feet, String inches, String weight, String city, String zipCode)
			throws InterruptedException {

		waitForVisible(driver, feetDropdown);
		feetDropdown.click();
		selectDropdownValue(feetDropdownList, feet);

		inchesDropdown.click();
		selectDropdownValue(inchesDropdownList, inches);
		
		weightTextField.clear();
		weightTextField.sendKeys(weight);
		cityTextField.clear();
		cityTextField.sendKeys(city);
		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipCode);
		// Thread.sleep(2000);
	}

	/**
	 * Enter Dental History Details in DentalHistoryInformation form with valid data
	 * 
	 * @param painExp
	 * @param opinion
	 * @throws InterruptedException
	 */

	public void updateDentalHistoryInformation(String painExp, String opinion) throws InterruptedException {
		waitForVisible(driver, dentalPainExpDropdown);
		Select selectfeet = new Select(dentalPainExpDropdown);
		selectfeet.selectByVisibleText(painExp);
		Select selectinches = new Select(opinionDropdown);
		selectinches.selectByVisibleText(opinion);
		// Thread.sleep(2000);
	}

	public void updateMedicalHistoryInformation(String drugAllergie) {
		waitForVisible(driver, drugAllergieDropdown);
		Select sel = new Select(drugAllergieDropdown);
		sel.selectByVisibleText(drugAllergie);
	}

	public String getDentalHistoryFormHeader() {
		waitForVisible(driver, dentalHistoryFormHeader);
		return dentalHistoryFormHeader.getText();
	}

	public String getMedicalHistoryFormHeader() {
		waitForVisible(driver, medicalHistoryFormHeader);
		return medicalHistoryFormHeader.getText();
	}

	public String getTargetPageFormHeader() {
		waitForVisible(driver, targetPageFromHeader);
		return targetPageFromHeader.getText();
	}

}

package com.teledentistry.patient.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientChangePasswordPage extends PatientPageBase {

	// PageElements
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(id = "opwd")
	WebElement oldPasswordTextField;

	@FindBy(id = "npwd")
	WebElement newPasswordTextField;

	@FindBy(id = "cpwd")
	WebElement confirmPasswordTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(css = ".text-bold.bold.font-medium.truncate")
	WebElement officeDetailsHeader;

	public PatientChangePasswordPage(WebDriver driver) {
		super(driver);
	}

	// operational Methods
	public String getFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void patientChangePassword(String oldPassword, String newPassword, String confirmPassword)
			throws InterruptedException {
		String randomPassword = randomPassword(newPassword);
		waitForVisible(driver, oldPasswordTextField);
		oldPasswordTextField.sendKeys(oldPassword);
		newPasswordTextField.sendKeys(randomPassword);
		confirmPasswordTextField.sendKeys(randomPassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void patientChangePasswordWithInvalidData(String oldPassword, String newPassword, String confirmPassword) {
		waitForVisible(driver, oldPasswordTextField);
		oldPasswordTextField.sendKeys(oldPassword);
		newPasswordTextField.sendKeys(newPassword);
		confirmPasswordTextField.sendKeys(confirmPassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public String getOfficeDetilsHeader() {
		waitForVisible(driver, officeDetailsHeader);
		return officeDetailsHeader.getText();
	}

}

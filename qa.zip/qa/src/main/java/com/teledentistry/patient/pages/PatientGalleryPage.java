package com.teledentistry.patient.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientGalleryPage extends PatientPageBase {

	// PageElements
	@FindBy(css = ".file.box.rounded-md")
	List<WebElement> galleryCount;

	@FindBy(xpath = "//h2[contains(text(),'Gallery')]")
	WebElement header;

	@FindBy(xpath = "(//i[@class='far fa-trash-alt w-5 h-5 text-gray-500'])[1]")
	WebElement deleteIcon;

	@FindBy(xpath = "//button[contains(text(),'confirm')]")
	WebElement deleteConfirmButton;

	// PageFactory Constructor
	public PatientGalleryPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public int getImageCountOnGallery() throws InterruptedException {
		waitForMultipleVisible(driver, galleryCount);
		List<WebElement> elements = galleryCount;
		int size = elements.size();
		return size;
	}

	public String getHeader() {
		waitForVisible(driver, header);
		return header.getText();
	}

	public void clickOnDeleteIcon() throws InterruptedException {
		waitForVisible(driver, deleteIcon);
		deleteIcon.click();
		// Thread.sleep(3000);
		waitForVisible(driver, deleteConfirmButton);
		deleteConfirmButton.click();
		driver.navigate().refresh();
	}

}

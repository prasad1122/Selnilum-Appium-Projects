package com.teledentistry.patient.pages;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PatientPageBase {

	WebDriver driver;
	Logger logger;

	// PageElements
	@FindBy(className = "jconfirm-content")
	WebElement popupStatusContent;

	@FindBy(className = "jconfirm-title")
	WebElement popupStatus;

	public PatientPageBase(WebDriver driver) {
		logger = Logger.getLogger(this.getClass().getSimpleName());

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// OperationalMethods
	public String getAlertContent() throws InterruptedException {
		waitForVisible(driver, popupStatusContent);
		return popupStatusContent.getText();
	}

	public String getAlert() throws InterruptedException {
		waitForVisible(driver, popupStatus);
		return popupStatus.getText();
	}

	public String randomPassword(String password) {
		password = password + RandomStringUtils.randomNumeric(4);
		return password;
	}

	public void waitForVisible(WebDriver driver, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void waitForMultipleVisible(WebDriver driver, List<WebElement> galleryCount2) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(galleryCount2));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectDropdownValue(List<WebElement> elementsList, String report) {
		for (WebElement element : elementsList) {
			String elementText = element.getText();
			if (elementText.contains(report)) {
				element.click();
				break;
			}
		}
	}
}

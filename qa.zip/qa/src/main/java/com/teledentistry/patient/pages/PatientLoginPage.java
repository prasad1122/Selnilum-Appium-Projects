package com.teledentistry.patient.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientLoginPage extends PatientPageBase {

	public PatientLoginPage(WebDriver driver) {
		super(driver);
	}

	// Login Page Elements

	@FindBy(name = "email")
	WebElement userNameInputFiled;

	@FindBy(name = "password")
	WebElement passwordInputField;

	@FindBy(className = "buttonfx")
	WebElement loginBtn;

	@FindBy(id = "loginotp")
	WebElement loginOTPTextField;

	// Operational methods

	public PatientHomePage patientLogin(String user, String password) throws InterruptedException {
		logger.debug("Parameters revceived: " + user + "," + password);
		userNameInputFiled.sendKeys(user);
		passwordInputField.sendKeys(password);
		Thread.sleep(4000);
		loginBtn.click();
		Thread.sleep(4000);
		logger.info("########## Successfully LogedIn ################");
		return new PatientHomePage(driver);
	}

}
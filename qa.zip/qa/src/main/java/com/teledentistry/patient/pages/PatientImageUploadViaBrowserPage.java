package com.teledentistry.patient.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientImageUploadViaBrowserPage extends PatientPageBase {

	// PageElements
	@FindBy(xpath = "//div[contains(text(),'You can upload multiple files.')]")
	WebElement imageUploadViaBrowserLink;

	@FindBy(xpath = "//h2[contains(text(),'Browse Picture')]")
	WebElement header;

	@FindBy(css = ".file.box.rounded-md")
	List<WebElement> galleryCount;

	public PatientImageUploadViaBrowserPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public String getHeader() {
		waitForVisible(driver, header);
		return header.getText();
	}

	public int getImageCountOnGallery() throws InterruptedException {
		PatientHomePage patientHomePage = new PatientHomePage(driver);
		patientHomePage.clickOnGalleryLink();
		waitForMultipleVisible(driver, galleryCount);
		List<WebElement> elements = galleryCount;
		int size = elements.size();
		return size;
	}

	public void uploadImageViaBrowser() throws InterruptedException, IOException, AWTException {

		imageUploadViaBrowserLink.click();
		Thread.sleep(4000);
		Robot rb = new Robot();

		// copying File path to Clipboard
		StringSelection str = new StringSelection(System.getProperty("user.dir") + "\\ImageUploadViaBrowser.jpg");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);

		Thread.sleep(4000);

		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);

		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);

		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);

	}

}

package com.teledentistry.patient.pages;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientJoinSessionPage extends PatientPageBase {

	// Page Elements

	@FindBy(linkText = "Join a Consult")
	WebElement joinAConsulthdr;

	@FindBy(linkText = "Join Session")
	WebElement joinSessionLink;

	@FindBy(xpath = "//button[@id='details-button']")
	WebElement advancedButton;

	@FindBy(xpath = "//a[@class='small-link']")
	WebElement domainLink;

	@FindBy(xpath = "//h5[text()='Join a Room']")
	WebElement roomHeader;

	@FindBy(xpath = "//span[text()='Continue']")
	WebElement meetingContinueButton;

	@FindBy(xpath = "//span[text()='Click to Join Session']")
	WebElement videoCallSessionLink;

	@FindBy(xpath = "(//span[text()='Disconnect'])[2]")
	WebElement callDisconnectButton;

	@FindBy(xpath = "//p[text()='demo+patient']")
	WebElement hederTxtField;

	// Initializing the Page Objects:

	public PatientJoinSessionPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public void clickOnJoinSessionLink() {
		waitForVisible(driver, joinSessionLink);
		joinSessionLink.click();
	}

	public String getHeader() {
		waitForVisible(driver, joinAConsulthdr);
		return joinAConsulthdr.getText();
	}

	public void switchToNewTab() throws InterruptedException {

		Set<String> tabs = driver.getWindowHandles();
		ArrayList<String> win = new ArrayList<String>(tabs);
		driver.switchTo().window(win.get(1));
	}

	public String getRoomHeader() {
		waitForVisible(driver, hederTxtField);
		return hederTxtField.getText();
	}

	public void clickOnMeetingContinueLink() throws InterruptedException {
		waitForVisible(driver, meetingContinueButton);
		meetingContinueButton.click();
	}

	public void clickToJoinSession() throws InterruptedException {
		waitForVisible(driver, videoCallSessionLink);
		Thread.sleep(3000);
		videoCallSessionLink.click();
	}

	public void clickToDisconnect() {
		waitForVisible(driver, callDisconnectButton);
		callDisconnectButton.click();
	}

}

package com.teledentistry.patient.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientHomePage extends PatientPageBase {

	// Page Elements
	@FindBy(linkText = "Join a Consult")
	WebElement JoinaConsultModuleLink;

	@FindBy(linkText = "E-Documents")
	WebElement eDocumentsModuleLink;

	@FindBy(linkText = "Take a picture")
	WebElement takeAPictureLink;

	@FindBy(linkText = "Gallery")
	WebElement galleryModuleLink;

	@FindBy(linkText = "Profile")
	WebElement profileModuleLink;

	@FindBy(linkText = "Change Password")
	WebElement changePasswordModuleLink;

	@FindBy(linkText = "Logout")
	WebElement logoutBtn;

	// Initializing the Page Objects:
	public PatientHomePage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public PatientJoinSessionPage clickOnJoinaConsultLink() {
		waitForVisible(driver, JoinaConsultModuleLink);
		JoinaConsultModuleLink.click();
		return new PatientJoinSessionPage(driver);

	}

	public PatientEdocUpdatePage clickOnEdocumentsLink() throws InterruptedException {
		waitForVisible(driver, eDocumentsModuleLink);
		eDocumentsModuleLink.click();
		return new PatientEdocUpdatePage(driver);
	}

	public PatientImageUploadViaCameraPage clickOnTakeAPictureLink() throws InterruptedException {
		waitForVisible(driver, takeAPictureLink);
		takeAPictureLink.click();
		return new PatientImageUploadViaCameraPage(driver);
	}

	public PatientImageUploadViaCameraPage clickOnGalleryLink() throws InterruptedException {
		waitForVisible(driver, galleryModuleLink);
		galleryModuleLink.click();
		return new PatientImageUploadViaCameraPage(driver);
	}

	public PatientProfileUpdatePage clickOnPatientProfileLink() throws InterruptedException {
		waitForVisible(driver, profileModuleLink);
		profileModuleLink.click();
		return new PatientProfileUpdatePage(driver);
	}

	public PatientChangePasswordPage clickOnChangePasswordModule() {
		waitForVisible(driver, changePasswordModuleLink);
		changePasswordModuleLink.click();
		return new PatientChangePasswordPage(driver);
	}

	public PatientLogoutPage clickOnLogoutButton() {
		waitForVisible(driver, logoutBtn);
		logoutBtn.click();
		return new PatientLogoutPage(driver);
	}
}

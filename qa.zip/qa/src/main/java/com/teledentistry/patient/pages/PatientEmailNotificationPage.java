package com.teledentistry.patient.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientEmailNotificationPage extends PatientPageBase {

	public PatientEmailNotificationPage(WebDriver driver) {
		super(driver);
	}

	// Yopmail page elements

	@FindBy(css = "#login")
	WebElement mailLoginTextField;

	@FindBy(css = "button.md")
	WebElement submitButton;

	@FindBy(css = "#refresh")
	WebElement refreshButton;

	@FindBy(css = "#ifinbox")
	WebElement inboxButton;

	@FindBy(xpath = "(//div[@class='lms' and contains(text(),'automation_test_clinic - Your Booked Session')])[1]")
	WebElement inboxFirstMessage;

	@FindBy(css = "#ifmail")
	WebElement messageBody;

	@FindBy(xpath = "//*[contains(text(),'Join Session')]")
	WebElement joinSessionButton;

	@FindBy(xpath = "//main[@class='yscrollbar']")
	WebElement contentField;

	@FindBy(xpath = "//h3[normalize-space()='Dear test auto']")
	WebElement patientName;

	// Operational methods

	public Map<String, String> handleAppointmentBookedEmailNotification() throws InterruptedException {

		Map<String, String> map = new HashMap<String, String>();

		String parentWindowId = driver.getWindowHandle();

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.open();");

		for (String window : driver.getWindowHandles()) {

			driver.switchTo().window(window);

		}

		driver.get("https://yopmail.com/");

		mailLoginTextField.sendKeys("testauto");

		submitButton.click();

		refreshButton.click();

		Thread.sleep(5000);

		driver.switchTo().frame(inboxButton);

		inboxFirstMessage.click();

		driver.switchTo().defaultContent();

		driver.switchTo().frame(messageBody);

		Thread.sleep(5000);

		boolean joinButton = joinSessionButton.isDisplayed();
		String PatentName = patientName.getText();
		map.put("name", PatentName);
		if (joinButton) {
			map.put("status", "true");
		} else {
			map.put("status", "false");
		}

		driver.close();

		Thread.sleep(4000);

		driver.switchTo().window(parentWindowId);

		Thread.sleep(4000);
		return map;
	}
}

package com.teledentistry.util;

public class ConstantValues {

	public ConstantValues() {
		throw new IllegalStateException("Constant Class");
	}

	public static final String ERROR = "Error";
	public static final String ALERT = "Alert";
	public static final String SUCCESS = "Success";
	public static final String ADDED = "Added";
	public static final String ADD_CLINIC = "Add Clinic";
	public static final String ADD_DOCTOR = "Add Doctor";
	public static final String ADD_PATIENT = "Add Patient";
	public static final String BOOK_APPOINTMENT = "Book Appointment";
	public static final String UPDATE_APPOINTMENT = "Update Appointment";
	public static final String UPDATE_CLINIC = "Update Clinic";
	public static final String UPDATED = "Updated";
	public static final String UPDATE_DOCTOR = "Update Doctor";
	public static final String JOIN_CONSULT = "Join a Consult";
	public static final String PATIENT_MEETING_ROOM_HEADER = "demo+patient (You)";
	public static final String JOIN_VIDEO_CALL = "Join a Video Call";
	public static final String DOCTOR_MEETING_ROOM_HEADER = "createnewdoc01+new (You)";
	public static final String CLINIC_ADD_DOCTOR = "Add New Doctor";
	public static final String PATIENT_EDOCUMENT = "E-Documents";
	public static final String MEETING_ROOM_HEADER = "Join a Room";
	public static final String UPDATE_PROFILE = "Edit Profile";
	public static final String PATIENT_IMG_UPLOAD_CAMERA_HEADER = "Take Pictures From Camera";
	public static final String UPDATE_DOCTOR_PROFILE = "Updated";
	public static final String UPDATE_DOCTOR_PROFILE_HEADER = "Profile";
	public static final String UPDATE_PATIENT_PROFILE_HEADER = "Profile";
	public static final String UPDATE_PATIENT_PROFILE = "Updated";
	public static final String GALLERY_HEADER = "Gallery";
	public static final String SEARCH_KEYWORD = "test";
	public static final String PATIENT_PAGE_HEADER = "Patients";
	public static final String EDOC_HEADER = "Edoc";
	public static final String EDOC_FIRST_FORM_HEADER = "Contact and Personal Information";
	public static final String EDOC_SECOND_FORM_HEADER = "Dental History Information";
	public static final String EDOC_THIRD_FORM_HEADER = "Medical History";
	public static final String PATIENT_IMG_UPLOAD_BROWSER_HEADER = "Browse Picture";
	public static final CharSequence CLINIC_NAME_SEARCH_KEYWORD = "testclinic@yopmail.com";
	public static final String CLINIC_NAME = "automation_test_clinic";
	public static final CharSequence DOCTOR_SEARCH_KEYWORD = "tdautomationt.test212121@yopmail.com";
	public static final CharSequence PATIENT_SEARCH_KEYWORD = "tdautomationt.test212121@yopmail.com";
	public static final CharSequence USERNAME = "Dear test auto";
	public static final String ADD_STAFF_MEMBER_HEADER = "Add Staff Member";
	public static final String USER_CREATED = "User Created!";
	public static final String PATIENT_SIGNUP_FORM_HEADER = "Patient Signup";
	public static final String DDMO_PATIENT_SIGNUP_FORM_HEADER = "Delta Dental — Virtual Visits";
	public static final String DDMO_DESTINATION_PAGE_HEADER = "Request Consult";
	public static final String VAB_DESTINATION_PAGE_HEADER = "Request Consult";
	public static final String D2C_DESTINATION_PAGE_HEADER = "Payment";
	public static final String CHANGEPASSWORD_FORM_HEADER = "Change Password";
	public static final String PATIENT_LOGIN_FORM_HEADER = "Patient Login";
	public static final String GENERAL_REPORT_HEADER = "General Report";
	public static final String GENERAL_HEADER = "General";
	public static final String OFFICE_DETAILS_HEADER = "Office Details:";
	public static final CharSequence USER_AGENT_SEARCH_KEYWORD = "testagent@gmail.com";
	public static final String USER_AGENT_UPADTE_FORM_HEADER = "Update Agent";
	public static final CharSequence STAFF_MEMBER_SEARCH_KEYWORD = "teststaffuser@gmail.com";
	public static final String UPDATE_STAFF_MEMBER_FORM_HEADER = "Update Staff Member";
	public static final String STAFF_MEMBER_UPDATED = "Updated!";
	public static final String MONTH_YEAR_REPORTS_HEADER = "Reports";
	public static final String CHAT_REPORTS_HEADER = "Patient Chat process list";
	public static final String USER_ACTIVITY_REPORTS_HEADER = "User Activity Reports";
	public static final String NOT_LOGGED_IN_LIST_FILE_NAME = "Not_Loggedin_List.xls";
	public static final String EDOC_NOT_FILLED_LIST_FILE_NAME = "NotFilled_EdocList.xls";
	public static final String NOT_JOINED_CONSULTS_LIST_FILE_NAME = "Not_joined_Consult.xls";
	public static final String DENTAL_HISTORY_FORM_HEADER = "Dental History Information";
	public static final String MEDICAL_HISTORY_FORM_HEADER = "Medical History";
	public static final String TARGET_PAGE_FORM_HEADER = "Request Consult";
	public static final String CONSULTS_REPORTS_XLSX_FILE_NAME = "TeleDentistry.xlsx";
	public static final String CONSULTS_REPORTS_PDF_FILE_NAME = "TeleDentistry.pdf";
	public static final String ADMIN_LOGIN_FORM_HEADER = "Super Admin login";
	public static final String CLINIC_LOGIN_FORM_HEADER = "Practice portal login";
	public static final String DOCTOR_LOGIN_FORM_HEADER = "Doctor Login";
}

package com.teledentistry.doctor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DoctorChangePasswordPage extends DoctorPageBase {

	// PageElements
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(id = "opwd")
	WebElement oldPasswordTextField;

	@FindBy(id = "npwd")
	WebElement newPasswordTextField;

	@FindBy(id = "cpwd")
	WebElement confirmPasswordTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(xpath = "//h2[normalize-space()='General']")
	WebElement generalHeader;

	public DoctorChangePasswordPage(WebDriver driver) {
		super(driver);
	}

	// operational Methods
	public String getFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void doctorChangePassword(String oldPassword, String newPassword, String confirmPassword)
			throws InterruptedException {
		String randomPassword = randomPassword(newPassword);
		waitForVisible(driver, oldPasswordTextField);
		oldPasswordTextField.sendKeys(oldPassword);
		newPasswordTextField.sendKeys(randomPassword);
		confirmPasswordTextField.sendKeys(randomPassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void doctorChangePasswordWithInvalidData(String oldPassword, String newPassword, String confirmPassword) {
		waitForVisible(driver, oldPasswordTextField);
		oldPasswordTextField.sendKeys(oldPassword);
		newPasswordTextField.sendKeys(newPassword);
		confirmPasswordTextField.sendKeys(confirmPassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public String getGeneralHeader() {
		waitForVisible(driver, generalHeader);
		return generalHeader.getText();
	}

}

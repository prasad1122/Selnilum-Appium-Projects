package com.teledentistry.doctor.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DoctorGalleryPage extends DoctorPageBase {

	// PageElements
	@FindBy(css = ".file.box.rounded-md")
	List<WebElement> galleryCount;

	@FindBy(css = ".text-lg.font-medium.mr-auto")
	WebElement header;

	@FindBy(xpath = "(//a[@class='button  text-white bg-theme-1 flex items-center'])[1]")
	WebElement galleryLink;

	@FindBy(id = "uploadLink")
	WebElement uploadLinkButton;

	public DoctorGalleryPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public int getImageCountOnGallery() throws InterruptedException {
		List<WebElement> elements = galleryCount;
		int size = elements.size();
		return size;
	}

	public String getHeader() {
		String headerName = header.getText();
		String headerValue = headerName.substring(0, 7);
		return headerValue;
	}

	public void clickOnGalleryLink() {
		waitForVisible(driver, galleryLink);
		galleryLink.click();
	}

	public void clickOnSendUploadLink() throws InterruptedException {
		waitForVisible(driver, uploadLinkButton);
		uploadLinkButton.click();
	}

}

package com.teledentistry.doctor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatientEdocUpdatedDeatilsPage extends DoctorPageBase {

	// Page Elements
	@FindBy(linkText = "E-Doc")
	WebElement edocLink;

	@FindBy(css = "h2.mr-auto")
	WebElement headerText;

	@FindBy(linkText = "Edocument (automation_test_clinic)")
	WebElement edocumentActiveLink;

	@FindBy(xpath = "//h1[contains(text(),'Contact and Personal Information')]")
	WebElement edocumentFirstFormHeader;

	@FindBy(xpath = "//h1[contains(text(),'Dental History Information')]")
	WebElement edocumentSecondFormHeader;

	@FindBy(xpath = "//h1[contains(text(),'Medical History')]")
	WebElement edocumentThirdFormHeader;

	@FindBy(id = "save")
	WebElement nextButton;

	// PageFactory Constructor
	public PatientEdocUpdatedDeatilsPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void clickOnEdoclink() {
		waitForVisible(driver, edocLink);
		edocLink.click();
	}

	public String getHeader() {
		waitForVisible(driver, headerText);
		return headerText.getText();
	}

	public void clickOnEdocumentActiveLink() {
		waitForVisible(driver, edocumentActiveLink);
		edocumentActiveLink.click();
	}

	public String getFirstFormHeader() throws InterruptedException {
		waitForVisible(driver, edocumentFirstFormHeader);
		return edocumentFirstFormHeader.getText();
	}

	public void clickOnNextButton() {
		waitForVisible(driver, nextButton);
		nextButton.click();
	}

	public String getSecondFormHeader() throws InterruptedException {
		waitForVisible(driver, edocumentSecondFormHeader);
		return edocumentSecondFormHeader.getText();
	}

	public String getThirdFormHeader() throws InterruptedException {
		waitForVisible(driver, edocumentThirdFormHeader);
		return edocumentThirdFormHeader.getText();
	}

}

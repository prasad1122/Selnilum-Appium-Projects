package com.teledentistry.doctor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DoctorLogoutPage extends DoctorPageBase {

	// PageElements
	@FindBy(xpath = "//h2[normalize-space()='Doctor Login']")
	WebElement loginFormHeader;

	public DoctorLogoutPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public String getLoginPageHedaer() {
		waitForVisible(driver, loginFormHeader);
		return loginFormHeader.getText();
	}

}

package com.teledentistry.doctor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class DoctorProfileUpdatePage extends DoctorPageBase {

	// PageElements
	@FindBy(css = ".text-lg.font-medium.mr-auto")
	WebElement formHeader;

	@FindBy(id = "address")
	WebElement addressTextField;

	@FindBy(id = "city")
	WebElement cityTextField;

	@FindBy(id = "zip")
	WebElement zipCodeTextField;

	@FindBy(id = "address_state")
	WebElement stateTextField;

	@FindBy(tagName = "button")
	WebElement submitButton;

	@FindBy(id = "dob")
	WebElement dateOfBirthDatePicker;

	public DoctorProfileUpdatePage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethds
	public String getupdateDoctorProfileFormHeader() throws InterruptedException {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void doctorProfileUpdate(String address, String city, String zipcode, String state, String dateOfBirth)
			throws InterruptedException {

		dateOfBirthDatePicker.clear();
		dateOfBirthDatePicker.sendKeys(dateOfBirth);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(state);
		Thread.sleep(3000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipcode);

		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

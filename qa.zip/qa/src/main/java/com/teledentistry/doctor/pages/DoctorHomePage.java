package com.teledentistry.doctor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.admin.pages.AdminLogoutPage;

public class DoctorHomePage extends DoctorPageBase {

	// PageElements
	@FindBy(linkText = "Join a Video Call")
	WebElement doctorJoinSessionModuleLink;

	@FindBy(linkText = "Profile")
	WebElement profileModuleLink;

	@FindBy(linkText = "Patients")
	WebElement patientsModuleLink;

	@FindBy(linkText = "Change Password")
	WebElement changePasswordModuleLink;

	@FindBy(linkText = "Logout")
	WebElement logoutBtn;

	// Initializing the Page Objects:
	public DoctorHomePage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public DoctorJoinSessionPage clickOnJoinVideoCallModuleLink() throws InterruptedException {
		waitForVisible(driver, doctorJoinSessionModuleLink);
		Thread.sleep(3000);
		doctorJoinSessionModuleLink.click();
		return new DoctorJoinSessionPage(driver);

	}

	public DoctorProfileUpdatePage clickOnDoctorProfileLink() throws InterruptedException {
		waitForVisible(driver, profileModuleLink);
		Thread.sleep(3000);
		profileModuleLink.click();
		return new DoctorProfileUpdatePage(driver);
	}

	public DoctorGalleryPage clickOnPatientsLink() throws InterruptedException {
		waitForVisible(driver, patientsModuleLink);
		Thread.sleep(3000);
		patientsModuleLink.click();
		return new DoctorGalleryPage(driver);
	}

	public DoctorChangePasswordPage clickOnChangePasswordModule() throws InterruptedException {
		waitForVisible(driver, changePasswordModuleLink);
		Thread.sleep(5000);
		changePasswordModuleLink.click();
		return new DoctorChangePasswordPage(driver);
	}

	public DoctorLogoutPage clickOnLogoutButton() {
		waitForVisible(driver, logoutBtn);
		logoutBtn.click();
		return new DoctorLogoutPage(driver);
	}

}

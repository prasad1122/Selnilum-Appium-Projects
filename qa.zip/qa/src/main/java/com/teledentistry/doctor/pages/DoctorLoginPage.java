package com.teledentistry.doctor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DoctorLoginPage extends DoctorPageBase {

	public DoctorLoginPage(WebDriver driver) {
		super(driver);
	}

	// PageElements
	@FindBy(name = "email")
	WebElement userNameInputFiled;

	@FindBy(name = "password")
	WebElement passwordInputField;

	@FindBy(className = "buttonfx")
	WebElement loginBtn;

	// Operational methods

	public DoctorHomePage patientLogin(String user, String password) throws InterruptedException {
		logger.debug("Parameters revceived: " + user + "," + password);
		userNameInputFiled.sendKeys(user);
		passwordInputField.sendKeys(password);
		Thread.sleep(4000);
		loginBtn.click();
		logger.info("########## Successfully LogedIn ################");
		return new DoctorHomePage(driver);
	}

}

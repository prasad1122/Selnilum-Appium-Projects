package com.teledentistry.doctor.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class PatientSearchPage extends DoctorPageBase {

	// Page Elements
	@FindBy(id = "search")
	WebElement searchBoxFiled;

	@FindBy(css = ".text-lg.font-medium.mr-auto")
	WebElement header;

	@FindBy(xpath = "//div[@class='flex flex-col lg:flex-row items-center p-5 mb-3']")
	List<WebElement> searchResult;

	// PageFactory Constructor
	public PatientSearchPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void searchItem() throws InterruptedException {
		searchBoxFiled.sendKeys(ConstantValues.SEARCH_KEYWORD);
		Thread.sleep(10000);
	}

	public String getHeader() {
		waitForVisible(driver, header);
		return header.getText();
	}

	public List<WebElement> getSearchResult() throws InterruptedException {
		waitForMultipleVisible(driver, searchResult);
		List<WebElement> elements = searchResult;
		return elements;
	}
}

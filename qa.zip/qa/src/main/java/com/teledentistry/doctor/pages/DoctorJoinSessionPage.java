package com.teledentistry.doctor.pages;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DoctorJoinSessionPage extends DoctorPageBase {

	// Page Elements
	@FindBy(linkText = "Join a Video Call")
	WebElement joinVideoCallhdr;

	@FindBy(linkText = "Join Session")
	WebElement joinSessionLink;

	@FindBy(css = ".MuiButton-label")
	WebElement meetingContinueButton;

	@FindBy(xpath = "//span[text()='Click to Join Session']")
	WebElement videoCallSessionLink;

	@FindBy(xpath = "(//span[text()='Disconnect'])[2]")
	WebElement callDisconnectButton;

	// Initializing the Page Objects:
	public DoctorJoinSessionPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void clickOnJoinSessionLink() {
		waitForVisible(driver, joinSessionLink);
		joinSessionLink.click();
	}

	public String getVideoCallRoomHeader() {
		waitForVisible(driver, joinVideoCallhdr);
		return joinVideoCallhdr.getText();
	}

	public void switchToNewTab() throws InterruptedException {
		Set<String> tabs = driver.getWindowHandles();
		ArrayList<String> win = new ArrayList<String>(tabs);
		driver.switchTo().window(win.get(1));
	}

	public void clickOnMeetingContinueLink() throws InterruptedException {
		waitForVisible(driver, meetingContinueButton);
		meetingContinueButton.click();
	}

	public void clickToJoinSession() throws InterruptedException {
		waitForVisible(driver, videoCallSessionLink);
		Thread.sleep(3000);
		videoCallSessionLink.click();
	}

	public void clickToDisconnect() {
		waitForVisible(driver, callDisconnectButton);
		callDisconnectButton.click();
	}

}

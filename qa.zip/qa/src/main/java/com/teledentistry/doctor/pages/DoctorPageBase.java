package com.teledentistry.doctor.pages;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DoctorPageBase {

	WebDriver driver;
	Logger logger;

	// PageElements
	@FindBy(className = "jconfirm-content")
	WebElement popupStatusContent;

	@FindBy(className = "jconfirm-title")
	WebElement popupStatus;

	public DoctorPageBase(WebDriver driver) {
		logger = Logger.getLogger(this.getClass().getSimpleName());

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// OperationalMethods
	public String getAlertContent() {
		waitForVisible(driver, popupStatusContent);
		return popupStatusContent.getText();
	}

	public String getAlert() {
		waitForVisible(driver, popupStatus);
		return popupStatus.getText();
	}

	public void waitForVisible(WebDriver driver, WebElement element) {
		try {
			// Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForMultipleVisible(WebDriver driver, List<WebElement> galleryCount2) {
		try {
			// Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOfAllElements(galleryCount2));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String randomPassword(String password) {
		password = password + RandomStringUtils.randomNumeric(5);
		return password;
	}

}

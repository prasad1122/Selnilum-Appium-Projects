package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class ClinicUpdatePatientPage extends ClinicPageBase {

	// PageElements
	@FindBy(xpath = "//h2[normalize-space()='Update Patient']")
	WebElement formHeader;

	@FindBy(xpath = "(//a[@class='button  text-white bg-theme-1 mr-2 flex items-center'])[4]")
	WebElement profileLink;

	@FindBy(tagName = "input")
	WebElement searchBoxFiled;

	public ClinicUpdatePatientPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void clickOnUpdatePatientLink() throws InterruptedException {
		searchBoxFiled.sendKeys(ConstantValues.PATIENT_SEARCH_KEYWORD);
		Thread.sleep(8000);
		waitForVisible(driver, profileLink);
		profileLink.click();
	}

	public String getUpdatePatientFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

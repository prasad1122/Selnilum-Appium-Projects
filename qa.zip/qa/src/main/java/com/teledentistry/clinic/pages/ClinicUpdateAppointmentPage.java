package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicUpdateAppointmentPage extends ClinicPageBase {

	// Page Elements

	@FindBy(linkText = "Update")
	WebElement updateLink;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(name = "user_id")
	WebElement clientNameDropdown;

	@FindBy(name = "doctor_id")
	WebElement doctorNameDropdown;

	@FindBy(id = "datepicker")
	WebElement datePickerField;

	@FindBy(id = "timepicker")
	WebElement timePickerField;

	@FindBy(id = "send")
	WebElement submitButton;

	@FindBy(xpath = "//*[@id='dt']/tbody/tr[1]/td[5]/div/button")
	WebElement optionsButton;

	// PageFactory Constructor
	public ClinicUpdateAppointmentPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void updateAppointmentLink() {
		waitForVisible(driver, optionsButton);
		optionsButton.click();
		waitForVisible(driver, updateLink);
		updateLink.click();
	}

	public String getUpdateAppointmentFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	/**
	 * Enter Appointment Details in Update Appointment form with valid data
	 * 
	 * @param clinic
	 * @param clientname
	 * @param doctorname
	 * @param date
	 * @param time
	 * @throws InterruptedException
	 */

	public void updateAppintmentForm(String clinic, String clientname, String doctorname, String date, String time)
			throws InterruptedException {
		time = systemTime();
		waitForVisible(driver, timePickerField);
		timePickerField.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

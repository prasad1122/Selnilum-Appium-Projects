package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicUpdateDoctorPage extends ClinicPageBase {

	// Page elements
	@FindBy(linkText = "Edit")
	WebElement editLink;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	// PageFactory constructor
	public ClinicUpdateDoctorPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public void clickOnUpdateDoctorLink() {
		waitForVisible(driver, editLink);
		editLink.click();

	}

	public String getUpdateDoctorFormHeader() throws InterruptedException {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

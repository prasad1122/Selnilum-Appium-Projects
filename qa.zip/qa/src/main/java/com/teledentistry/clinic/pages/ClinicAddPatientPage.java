package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicAddPatientPage extends ClinicPageBase {

	// Page Factory - OR:
	@FindBy(className = "buttonfx")
	WebElement addNewPatinetLink;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	// Initializing the Page Objects:
	public ClinicAddPatientPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public void clickOnAddNewPatientLink() throws InterruptedException {
		waitForVisible(driver, addNewPatinetLink);
		addNewPatinetLink.click();

	}

	public String getaddPatientFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}
}

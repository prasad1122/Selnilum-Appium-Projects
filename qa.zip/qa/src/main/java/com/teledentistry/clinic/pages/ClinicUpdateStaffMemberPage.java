package com.teledentistry.clinic.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class ClinicUpdateStaffMemberPage extends ClinicPageBase {

	// PageElements
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(xpath = "//td[normalize-space()='teststaffuser@gmail.com']//following::a[normalize-space()='Edit']")
	WebElement editLink;

	@FindBy(css = "input[type='search']")
	WebElement searchBoxField;

	@FindBy(xpath = "//div[@onclick='toggleView()']")
	WebElement toggleButton;

	@FindBy(id = "name")
	WebElement nameTextField;

	@FindBy(id = "email")
	WebElement emailTextField;

	@FindBy(id = "password")
	WebElement passwordTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	public ClinicUpdateStaffMemberPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public void clickOnUpdateStaffMemberLink() throws InterruptedException {
		waitForVisible(driver, searchBoxField);
		searchBoxField.sendKeys(ConstantValues.STAFF_MEMBER_SEARCH_KEYWORD);
		if (driver.findElements(By.xpath("//div[@onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		Thread.sleep(10000);
		waitForVisible(driver, editLink);
		editLink.click();
	}

	public String getUpdateStaffMemberFormHeader() {
		return formHeader.getText();
	}

	public void UpdateStaffMemberDetails(String name, String email, String password) {

		waitForVisible(driver, nameTextField);
		nameTextField.clear();
		nameTextField.sendKeys(name);
		emailTextField.clear();
		emailTextField.sendKeys(email);
		passwordTextField.clear();
		passwordTextField.sendKeys(password);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

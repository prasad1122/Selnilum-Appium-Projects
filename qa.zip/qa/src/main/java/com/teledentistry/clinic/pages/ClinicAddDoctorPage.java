package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicAddDoctorPage extends ClinicPageBase {

	// PageElements

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(linkText = "Add New Doctor")
	WebElement addNewDoctorLink;

	public ClinicAddDoctorPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public void clickOnAddNewDoctorLink() {
		waitForVisible(driver, addNewDoctorLink);
		addNewDoctorLink.click();

	}

	public String getAddDoctorFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

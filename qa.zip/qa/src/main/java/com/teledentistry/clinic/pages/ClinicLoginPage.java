package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicLoginPage extends ClinicPageBase {

	public ClinicLoginPage(WebDriver driver) {
		super(driver);
	}

	// Login Page elements

	@FindBy(name = "username")
	WebElement userNameTextField;

	@FindBy(name = "password")
	WebElement passwordTextField;

	@FindBy(className = "buttonfx")
	WebElement loginBtn;

	@FindBy(id = "loginotp")
	WebElement loginOTPTextField;

	// Operational methods

	public ClinicHomePage clinicLogin(String user, String password) throws InterruptedException {
		logger.debug("Parameters revceived: " + user + "," + password);
		userNameTextField.sendKeys(user);
		passwordTextField.sendKeys(password);
		Thread.sleep(4000);
		loginBtn.click();
		Thread.sleep(4000);
		logger.info("########## Successfully LogedIn ################");
		return new ClinicHomePage(driver);
	}

}
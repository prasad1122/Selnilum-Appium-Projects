package com.teledentistry.clinic.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicBookAppointmentPage extends ClinicPageBase {

	// PageElements
	@FindBy(xpath = "//span[contains(text(),'Select Client')]")
	WebElement clientNameDropdownField;

	@FindBy(xpath = "//span[contains(text(),'Select Doctor')]")
	WebElement doctorNameDropdownField;

	@FindBy(id = "datepicker")
	WebElement datePickerField;

	@FindBy(id = "timepicker")
	WebElement timePickerField;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(id = "send")
	WebElement submitButton;

	@FindBy(className = "buttonfx")
	WebElement bookNewAppointmentLink;

	@FindBy(css = "#select2-timezone-container")
	WebElement timeZoneField;
	
	@FindBy(css="#select2-timezone-results>li")
	List<WebElement> timezoneDropdownList;
	
	@FindBy(xpath="//li[@role='option']")
	List<WebElement> clientNameDropdownList;
	
	@FindBy(xpath="//li[@role='option']")
	List<WebElement> doctorNameDropdownList;

	// PageFactory Constructor
	public ClinicBookAppointmentPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void clickOnAddNewBookAppointmentLink() {
		waitForVisible(driver, bookNewAppointmentLink);
		bookNewAppointmentLink.click();
	}

	public String getBookAppointmentFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	/**
	 * Enter Appointment Details in Book Appointment form with valid data
	 * 
	 * @param timeZone
	 * @param clientname
	 * @param doctorname
	 * @param date
	 * @param time
	 * @throws InterruptedException
	 */

	public void createBookAppointment(String timeZone, String clientname, String doctorname, String date, String time)
			throws InterruptedException {

		time = systemTime();
		waitForVisible(driver, timeZoneField);
		timeZoneField.click();
		selectDropdownValue(timezoneDropdownList, timeZone);

		waitForVisible(driver, clientNameDropdownField);
		clientNameDropdownField.click();
		selectDropdownValue(clientNameDropdownList, clientname);

		waitForVisible(driver, doctorNameDropdownField);
		doctorNameDropdownField.click();
		selectDropdownValue(doctorNameDropdownList, doctorname);
		waitForVisible(driver, timePickerField);
		timePickerField.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Appointment Details in Book Appointment form with Invalid date
	 * 
	 * @param timeZone
	 * @param clientname
	 * @param doctorname
	 * @param date
	 * @param time
	 * @throws InterruptedException
	 */

	public void createBookAppointmentWithInvalidDate(String timeZone, String clientname, String doctorname, String date,
			String time) throws InterruptedException {

		time = systemTime();
		waitForVisible(driver, timeZoneField);
		timeZoneField.click();
		selectDropdownValue(timezoneDropdownList, timeZone);

		waitForVisible(driver, clientNameDropdownField);
		clientNameDropdownField.click();
		selectDropdownValue(clientNameDropdownList, clientname);

		waitForVisible(driver, doctorNameDropdownField);
		doctorNameDropdownField.click();
		selectDropdownValue(doctorNameDropdownList, doctorname);
		waitForVisible(driver, datePickerField);
		datePickerField.sendKeys(date);
		waitForVisible(driver, timePickerField);
		timePickerField.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	public void createBookAppointmentWithInvalidTime(String timeZone, String clientname, String doctorname, String date,
			String time) {
		time = systemTimeWithPastTime();
		waitForVisible(driver, timeZoneField);
		timeZoneField.click();
		selectDropdownValue(timezoneDropdownList, timeZone);

		waitForVisible(driver, clientNameDropdownField);
		clientNameDropdownField.click();
		selectDropdownValue(clientNameDropdownList, clientname);

		waitForVisible(driver, doctorNameDropdownField);
		doctorNameDropdownField.click();
		selectDropdownValue(doctorNameDropdownList, doctorname);
		waitForVisible(driver, timePickerField);

		timePickerField.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

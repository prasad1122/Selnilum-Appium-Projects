package com.teledentistry.clinic.pages;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicReportsPage extends ClinicPageBase{
	
	// Page Elements
	
	@FindBy(xpath = "//div[normalize-space()='Chat reports']")
	WebElement chatReportSubModuleLink;
	
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;
	
	@FindBy(css = "#btnPrint")
	WebElement downloadButton;
	
	@FindBy(linkText="Consults Reports")
	WebElement consultsReportsSubModuleLink;
	
	@FindBy(xpath="//span[contains(text(),'Click to Export')]")
	WebElement clickOnExportButton;
	
	@FindBy(xpath="//span[contains(text(),'Excel')]")
	WebElement consultsReportsXLSXDownloadButton;
	
	@FindBy(xpath="//span[normalize-space()='PDF']")
	WebElement consultsReportsPDFDownloadButton;
	
	@FindBy(linkText="Overflow Consults Reports")
	WebElement overflowConsultsReportSubModuleLink;

	public ClinicReportsPage(WebDriver driver) {
		super(driver);
	}

	//Operational Methods
	public void clickOnChatReportsLink() {
		waitForVisible(driver, chatReportSubModuleLink);
		chatReportSubModuleLink.click();
	}

	public String getReportsFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void clickOnChatReportDownloadButton() {
		waitForVisible(driver, downloadButton);
		downloadButton.click();
	}

	public boolean getResult() {
		if (downloadButton.isEnabled()) {
			return true;
		}
		return false;
	}

	public void clickOnConsultsReportsLink() {
		waitForVisible(driver, consultsReportsSubModuleLink);
		consultsReportsSubModuleLink.click();
	}

	public void clickOnClickToExportButton() {
		waitForVisible(driver, clickOnExportButton);
		clickOnExportButton.click();
	}

	public void clickOnConsultsReportsXLSXDownloadButton() throws InterruptedException {
		waitForVisible(driver, consultsReportsXLSXDownloadButton);
		consultsReportsXLSXDownloadButton.click();
		Thread.sleep(5000);
	}

	public boolean isFileDownloaded(String fileName) throws IOException {
		if (Files.notExists(Paths.get("DownloadFiles"))) {
			Files.createDirectory(Paths.get("DownloadFiles"));
		}

		File dir = new File(System.getProperty("user.dir") + "\\DownloadFiles");
		File[] dirContents = dir.listFiles();

		for (int i = 0; i < dirContents.length; i++) {
			if (dirContents[i].getName().equals(fileName)) {
				// File has been found, it can now be deleted:
				dirContents[i].delete();
				return true;
			}
		}
		return false;
	}

	public void clickOnConsultsReportsPDFDownloadButton() throws InterruptedException {
		waitForVisible(driver, consultsReportsPDFDownloadButton);
		consultsReportsPDFDownloadButton.click();
		Thread.sleep(5000);
	}

	public void clickOnOverflowConsultsReportsLink() {
		waitForVisible(driver, overflowConsultsReportSubModuleLink);
		overflowConsultsReportSubModuleLink.click();
	}

}

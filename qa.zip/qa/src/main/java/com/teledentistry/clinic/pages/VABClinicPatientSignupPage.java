package com.teledentistry.clinic.pages;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class VABClinicPatientSignupPage extends ClinicPageBase {

	String randomemail;
	String actualFormHeader;

	// Page Elements
	@FindBy(xpath = "//h2[normalize-space()='Patient Signup']")
	WebElement patientSignFormHeader;

	@FindBy(id = "fname")
	WebElement firstnameTextField;

	@FindBy(id = "lname")
	WebElement lastnameTextField;

	@FindBy(id = "phone")
	WebElement phonenumberTextField;

	@FindBy(id = "email")
	WebElement emailTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(linkText = "Logout")
	WebElement logoutButton;

	@FindBy(id = "Date-of-Birth")
	WebElement dateOfBirthDatepicker;

	@FindBy(id = "Social-Security-Number")
	WebElement ssnCodeTextField;

	@FindBy(css = "#select2-feet-container")
	WebElement feetDropdown;

	@FindBy(css = "#select2-inches-container")
	WebElement inchesDropdown;

	@FindBy(css = "#select2-feet-results>li")
	List<WebElement> feetDropdownList;

	@FindBy(css = "#select2-inches-results>li")
	List<WebElement> inchesDropdownList;

	@FindBy(id = "weight")
	WebElement weightTextField;

	@FindBy(id = "save")
	WebElement nextButton;

	@FindBy(id = "terms_conditions")
	WebElement checkboxField;

	@FindBy(xpath = "//div[@class='px-5 sm:px-20 mt-10 pt-10 border-t border-gray-200']")
	WebElement clickAction;

	@FindBy(xpath = "//h2[normalize-space()='Request Consult']")
	WebElement destinationPageFormHeader;

	@FindBy(id = "City")
	WebElement cityTextField;

	@FindBy(name = "State")
	WebElement stateDropdown;

	@FindBy(id = "zip")
	WebElement zipcodeTextField;

	@FindBy(name = "Are-you-currently-experiencing-dental-pain-or-discomfort")
	WebElement dentalPainExpDropdown;

	@FindBy(name = "Are-you-interested-in-getting-your-teeth-straightened-with-aligners")
	WebElement opinionDropdown;

	@FindBy(id = "Do-you-have-any-known-drug-allergies")
	WebElement drugAllergieDropdown;

	@FindBy(xpath = "//h2[normalize-space()='Patient Login']")
	WebElement loginFormHeader;

	// Email Elements

	@FindBy(xpath = "//input[@id='identifierId']")
	WebElement email;

	@FindBy(xpath = "//*[@id='password']/div[1]/div/div[1]/input")
	WebElement passwordField;

	@FindBy(xpath = "//div[@data-tooltip='Messages from social networks, media-sharing sites, online dating services and other social websites.']")
	WebElement Social;

	@FindBy(name = "q")
	WebElement searchField;

	@FindBy(xpath = "//span[@class='bog']")
	List<WebElement> emailThreads;

	@FindBy(xpath = "//img[@class='gb_Ca gbii']")
	WebElement profileLogo;

	@FindBy(xpath = "(//a[contains(@href,'teledentistry.com')])[1]")
	WebElement passwordLink;

	@FindBy(name = "new_password")
	WebElement newPassword;

	@FindBy(name = "confirm_password")
	WebElement confromPassword;

	@FindBy(xpath = "//div[@class='asor_b asor_f']")
	WebElement searchResult;

	// Initializing the Page Objects
	public VABClinicPatientSignupPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public String getFormHeader() {
		waitForVisible(driver, patientSignFormHeader);
		return patientSignFormHeader.getText();
	}

	public void patientSignup(String firstname, String lastname, String phone, String email) {

		randomemail = randomEmailWithPlusExtension(email);
		waitForVisible(driver, firstnameTextField);
		firstnameTextField.sendKeys(firstname);
		lastnameTextField.sendKeys(lastname);
		phonenumberTextField.sendKeys(phone);
		emailTextField.sendKeys(randomemail);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public boolean getSignupStatus() {
		waitForVisible(driver, logoutButton);
		return logoutButton.isDisplayed();
	}

	public void personalDetailsValidation(String dateOfBirth, String ssn, String feet, String inches, String weight,
			String city, String state, String zipCode) {

		waitForVisible(driver, dateOfBirthDatepicker);
		dateOfBirthDatepicker.clear();
		dateOfBirthDatepicker.sendKeys(dateOfBirth);

		clickAction.click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value='" + ssn + "';", ssnCodeTextField);

		feetDropdown.click();
		selectDropdownValue(feetDropdownList, feet);

		inchesDropdown.click();
		selectDropdownValue(inchesDropdownList, inches);
		weightTextField.clear();
		weightTextField.sendKeys(weight);
		cityTextField.sendKeys(city);
		zipcodeTextField.sendKeys(zipCode);
		waitForVisible(driver, nextButton);
		nextButton.click();
	}

	public void dentalHistoryValidation(String painExp, String opinion) {
		waitForVisible(driver, dentalPainExpDropdown);
		Select selectfeet = new Select(dentalPainExpDropdown);
		selectfeet.selectByVisibleText(painExp);
		Select selectinches = new Select(opinionDropdown);
		selectinches.selectByVisibleText(opinion);
		waitForVisible(driver, nextButton);
		nextButton.click();
	}

	public void medicalHistoryValidation(String drugAllergie) {
		waitForVisible(driver, drugAllergieDropdown);
		Select sel = new Select(drugAllergieDropdown);
		sel.selectByVisibleText(drugAllergie);
		waitForVisible(driver, checkboxField);
		checkboxField.click();
		waitForVisible(driver, nextButton);
		nextButton.click();
	}

	public String getDestionationPageFormHeader() {
		waitForVisible(driver, destinationPageFormHeader);
		return destinationPageFormHeader.getText();
	}

	public void ResetPasswordLinkValidation() throws InterruptedException {
		Thread.sleep(5000);
		String parentWindowId = driver.getWindowHandle();

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.open();");

		for (String window : driver.getWindowHandles()) {

			driver.switchTo().window(window);
		}
		driver.get("https://mail.google.com");
		waitForVisible(driver, email);
		Actions actions = new Actions(driver);
		actions.moveToElement(email);
		actions.click();
		actions.sendKeys("telesentistrytestemail@gmail.com" + Keys.ENTER);
		actions.build().perform();

		waitForVisible(driver, passwordField);
		// Actions actions1 = new Actions(driver);
		actions.moveToElement(passwordField);
		actions.click();
		Thread.sleep(2000);
		actions.sendKeys("Test@123" + Keys.ENTER);
		actions.build().perform();
//		waitForVisible(driver, Social);
//		Social.click();
		waitForVisible(driver, searchField);
		// Actions actions2 = new Actions(driver);
		actions.moveToElement(searchField);
		actions.click();
		actions.sendKeys(randomemail + Keys.ENTER);
		actions.build().perform();
		waitForVisible(driver, profileLogo);

		for (int i = 0; i < emailThreads.size(); i++) {

			if (emailThreads.get(i).getText().contains("Welcome to Teledentistry.com")) {
				emailThreads.get(i).click();
				break;
			}
		}

	}

	public void clickLink() {
		waitForVisible(driver, passwordLink);
		actualFormHeader = passwordLink.getText();
	}

	public void changePasswordLink() throws InterruptedException {
		String parentWindowId = driver.getWindowHandle();

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.open();");

		for (String window : driver.getWindowHandles()) {

			driver.switchTo().window(window);
		}
		Thread.sleep(3000);
		driver.get(actualFormHeader);
		Thread.sleep(2000);
	}

	public void createPassword(String newpassword, String conformpassword) {
		waitForVisible(driver, newPassword);
		newPassword.sendKeys(newpassword);
		waitForVisible(driver, confromPassword);
		confromPassword.sendKeys(conformpassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public String getPatientLoginFormHeader() {
		waitForVisible(driver, loginFormHeader);
		return loginFormHeader.getText();
	}

}

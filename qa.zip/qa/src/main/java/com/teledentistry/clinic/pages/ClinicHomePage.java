package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicHomePage extends ClinicPageBase {

	// PageElements
	@FindBy(linkText = "Doctors")
	WebElement doctorsModuleLink;

	@FindBy(linkText = "Patients")
	WebElement patientsModuleLink;

	@FindBy(linkText = "Clinics")
	WebElement clinicsModuleLink;

	@FindBy(linkText = "Book Appointment")
	WebElement bookAppointmentModuleLink;

	@FindBy(linkText = "Profile")
	WebElement profileModuleLink;

	@FindBy(linkText = "Staff Members")
	WebElement staffMemberModuleLink;

	@FindBy(linkText = "Change Password")
	WebElement changePasswordModuleLink;
	
	@FindBy(linkText = "Reports")
	WebElement reportsModuleLink;
	
	@FindBy(linkText = "Logout")
	WebElement logoutModuleLink;

	// Initializing the Page Objects:
	public ClinicHomePage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public ClinicAddPatientPage clickOnClinicPatientsLink() throws InterruptedException {
		waitForVisible(driver, patientsModuleLink);
		Thread.sleep(3000);
		patientsModuleLink.click();
		return new ClinicAddPatientPage(driver);
	}

	public ClinicAddDoctorPage clickOnDoctorsLink() throws InterruptedException {
		waitForVisible(driver, doctorsModuleLink);
		Thread.sleep(3000);
		doctorsModuleLink.click();
		return new ClinicAddDoctorPage(driver);
	}

	public ClinicBookAppointmentPage clickOnBookAppointmentsLink() throws InterruptedException {
		waitForVisible(driver, bookAppointmentModuleLink);
		Thread.sleep(4000);
		bookAppointmentModuleLink.click();
		return new ClinicBookAppointmentPage(driver);
	}

	public ClinicUpdateProfilePage clickOnProfileLink() throws InterruptedException {
		waitForVisible(driver, profileModuleLink);
		Thread.sleep(3000);
		profileModuleLink.click();
		return new ClinicUpdateProfilePage(driver);
	}

	public ClinicAddStaffMemberPage clickOnStaffMembersLink() throws InterruptedException {
		waitForVisible(driver, staffMemberModuleLink);
		Thread.sleep(3000);
		staffMemberModuleLink.click();
		return new ClinicAddStaffMemberPage(driver);
	}

	public ClinicChangePasswordPage clickOnChangePasswordModule() throws InterruptedException {
		waitForVisible(driver, changePasswordModuleLink);
		Thread.sleep(3000);
		changePasswordModuleLink.click();
		return new ClinicChangePasswordPage(driver);
	}

	public ClinicReportsPage clickOnReportsLink() throws InterruptedException {
		waitForVisible(driver, reportsModuleLink);
		Thread.sleep(3000);
		reportsModuleLink.click();
		return new ClinicReportsPage(driver);
	}

	public ClinicLogoutPage clickOnLogoutButton() throws InterruptedException {
		waitForVisible(driver, logoutModuleLink);
		Thread.sleep(2000);
		logoutModuleLink.click();
		return new ClinicLogoutPage(driver);
	}

}

package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicUpdateProfilePage extends ClinicPageBase {

	// PageElements
	@FindBy(xpath = "//h2[contains(text(),'Edit Profile')]")
	WebElement formHeader;

	// PageFactory Constructor
	public ClinicUpdateProfilePage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public String getUpdateProfileFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

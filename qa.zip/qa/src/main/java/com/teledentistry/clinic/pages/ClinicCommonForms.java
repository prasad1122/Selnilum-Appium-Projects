package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ClinicCommonForms extends ClinicPageBase {

	public ClinicCommonForms(WebDriver driver) {
		super(driver);
	}

	// Common Elements

	@FindBy(id = "firstname")
	WebElement firstNameTextField;

	@FindBy(id = "lastname")
	WebElement lastNameTextField;

	@FindBy(id = "phone")
	WebElement phoneNumberTextField;

	@FindBy(id = "fax")
	WebElement faxTextField;

	@FindBy(id = "email")
	WebElement emailTextField;

	@FindBy(id = "password")
	WebElement passwordTextField;

	@FindBy(id = "dob")
	WebElement dateOfBirthDatePicker;

	@FindBy(id = "address")
	WebElement addressTextField;

	@FindBy(id = "city")
	WebElement cityTextField;

	@FindBy(id = "zip")
	WebElement zipCodeTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(id = "name")
	WebElement clinicNameTextField;

	@FindBy(id = "phone")
	WebElement clinicPhoneNumberTextField;

	@FindBy(id = "website")
	WebElement clinicWebSiteURLTextField;

	// Doctor Forms Elements

	@FindBy(css = ".select2-selection.select2-selection--multiple")
	WebElement stateComboBox;

	@FindBy(id = "address_state")
	WebElement stateTextField;

	@FindBy(id = "npi_number")
	WebElement npiNumberTextField;

	@FindBy(id = "dea_number")
	WebElement deaNumberTextField;

	@FindBy(id = "dea_state")
	WebElement deaStateTextField;

	@FindBy(name = "status")
	WebElement statusDropdown;

	@FindBy(name = "uberized")
	WebElement uberizedDropdown;

	@FindBy(id = "ubd_state")
	WebElement preferredLocationDropdown;

	@FindBy(linkText = "Add New Doctor")
	WebElement addNewDoctorLink;

	@FindBy(xpath = "//li[normalize-space()='CALIFORNIA']")
	WebElement selectState;

	@FindBy(xpath = "//div[contains(text(),'License Details')]")
	WebElement toEnableCombobox;

	// Patient Forms Elements

	@FindBy(id = "feet")
	WebElement feetDropdown;

	@FindBy(id = "inches")
	WebElement inchesDropdown;

	@FindBy(id = "gender")
	WebElement genderDropdown;

	@FindBy(id = "weight")
	WebElement weightTextField;

	@FindBy(id = "ssn")
	WebElement ssnCodeTextField;

	@FindBy(id = "state")
	WebElement stateDropdown;

	// Doctor Forms operational methods

	/**
	 * Enter Doctor Details in Add Doctor form with valid data
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param password
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param NPINumber
	 * @param DEANumber
	 * @param DEAState
	 * @param status
	 * @param uberization
	 * @param preferredLocation
	 * @throws InterruptedException
	 */
	public void createNewDoctor(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipCode, String stateCode,
			String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredLocation) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, firstNameTextField);
		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		faxTextField.sendKeys(fax);
		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);
		dateOfBirthDatePicker.sendKeys(dob);
		toEnableCombobox.click();
		stateComboBox.click();
		selectState.click();
		addressTextField.sendKeys(address);
		waitForVisible(driver, stateTextField);
		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		npiNumberTextField.sendKeys(NPINumber);
		deaNumberTextField.sendKeys(DEANumber);
		deaStateTextField.sendKeys(DEAState);
		Select selectPreferredLocation = new Select(preferredLocationDropdown);
		selectPreferredLocation.selectByVisibleText(preferredLocation);

		submitButton.click();

	}

	/**
	 * Enter Doctor Details in Add Doctor form with invalid email
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param password
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param NPINumber
	 * @param DEANumber
	 * @param DEAState
	 * @param status
	 * @param uberization
	 * @param preferredLocation
	 * @throws InterruptedException
	 */
	public void createNewDoctorwithInvalidEmail(String firstname, String lastname, String phone, String fax,
			String email, String password, String dob, String state, String address, String city, String zipCode,
			String stateCode, String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredLocation) throws InterruptedException {

		waitForVisible(driver, firstNameTextField);
		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		faxTextField.sendKeys(fax);
		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);
		dateOfBirthDatePicker.sendKeys(dob);
		toEnableCombobox.click();
		stateComboBox.click();
		selectState.click();
		addressTextField.sendKeys(address);
		waitForVisible(driver, stateTextField);
		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		npiNumberTextField.sendKeys(NPINumber);
		deaNumberTextField.sendKeys(DEANumber);
		deaStateTextField.sendKeys(DEAState);
		Select selectPreferredLocation = new Select(preferredLocationDropdown);
		selectPreferredLocation.selectByVisibleText(preferredLocation);
		submitButton.click();

	}

	/**
	 * Enter Doctor Details in Add Doctor form with invalid password
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param password
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param NPINumber
	 * @param DEANumber
	 * @param DEAState
	 * @param status
	 * @param uberization
	 * @param preferredLocation
	 * @throws InterruptedException
	 */
	public void createNewDoctorwithInvalidPassword(String firstname, String lastname, String phone, String fax,
			String email, String password, String dob, String state, String address, String city, String zipCode,
			String stateCode, String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredLocation) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, firstNameTextField);
		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		faxTextField.sendKeys(fax);
		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);
		dateOfBirthDatePicker.sendKeys(dob);
		toEnableCombobox.click();
		stateComboBox.click();
		selectState.click();
		addressTextField.sendKeys(address);
		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		npiNumberTextField.sendKeys(NPINumber);
		deaNumberTextField.sendKeys(DEANumber);
		deaStateTextField.sendKeys(DEAState);
		Select selectPreferredLocation = new Select(preferredLocationDropdown);
		selectPreferredLocation.selectByVisibleText(preferredLocation);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void updateDoctorForm(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipcode, String stateCode,
			String NPINumber, String DEANumber, String DEAState, String status, String uberization,
			String preferredlocation) throws InterruptedException {

		waitForVisible(driver, firstNameTextField);
		firstNameTextField.clear();
		firstNameTextField.sendKeys(firstname);

		lastNameTextField.clear();
		lastNameTextField.sendKeys(lastname);

		phoneNumberTextField.clear();
		phoneNumberTextField.sendKeys(phone);

		faxTextField.clear();
		faxTextField.sendKeys(fax);

		passwordTextField.clear();
		passwordTextField.sendKeys(password);

		dateOfBirthDatePicker.clear();
		dateOfBirthDatePicker.sendKeys(dob);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipcode);

		npiNumberTextField.clear();
		npiNumberTextField.sendKeys(NPINumber);

		deaNumberTextField.clear();
		deaNumberTextField.sendKeys(DEANumber);

		deaStateTextField.clear();
		deaStateTextField.sendKeys(DEAState);

		Select selectStatus = new Select(statusDropdown);
		selectStatus.selectByVisibleText(status);

		Select selectUberized = new Select(uberizedDropdown);
		selectUberized.selectByVisibleText(uberization);

		Select selectPreferredLocation = new Select(preferredLocationDropdown);
		selectPreferredLocation.selectByVisibleText(preferredlocation);

		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	// Patient Forms operational methods
	/**
	 * Enter Patient Details in Add Patient form with valid data
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param SSNCode
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */
	public void createNewPatient(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String SSNCode, String address,
			String city, String zipCode, String state) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, firstNameTextField);
		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.sendKeys(dob);

		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		Select selectfeet = new Select(feetDropdown);
		selectfeet.selectByVisibleText(feet);

		Select selectinches = new Select(inchesDropdown);
		selectinches.selectByVisibleText(inches);

		Select selectgender = new Select(genderDropdown);
		selectgender.selectByVisibleText(gender);

		weightTextField.sendKeys(weight);

		ssnCodeTextField.sendKeys(SSNCode);

		addressTextField.sendKeys(address);
		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		submitButton.click();
	}

	/**
	 * Enter Patient Details in Add Patient form with invalid email
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param SSNCode
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */
	public void createPatientWithInvalidEmail(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String SSNCode, String address,
			String city, String zipCode, String state) throws InterruptedException {

		waitForVisible(driver, firstNameTextField);
		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.sendKeys(dob);

		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		Select selectfeet = new Select(feetDropdown);
		selectfeet.selectByVisibleText(feet);

		Select selectinches = new Select(inchesDropdown);
		selectinches.selectByVisibleText(inches);

		Select selectgender = new Select(genderDropdown);
		selectgender.selectByVisibleText(gender);

		weightTextField.sendKeys(weight);
		waitForVisible(driver, ssnCodeTextField);
		ssnCodeTextField.sendKeys(SSNCode);

		addressTextField.sendKeys(address);
		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		submitButton.click();
	}

	/**
	 * Enter Patient Details in Add Patient form with invalid DateOfBirth
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param SSNCode
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */
	public void createPatientWithInvalidDateofBirth(String firstname, String lastname, String phone, String dob,
			String email, String password, String feet, String inches, String gender, String weight, String SSNCode,
			String address, String city, String zipCode, String state) throws InterruptedException {

		waitForVisible(driver, firstNameTextField);
		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.sendKeys(dob);

		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		Select selectfeet = new Select(feetDropdown);
		selectfeet.selectByVisibleText(feet);

		Select selectinches = new Select(inchesDropdown);
		selectinches.selectByVisibleText(inches);

		Select selectgender = new Select(genderDropdown);
		selectgender.selectByVisibleText(gender);

		weightTextField.sendKeys(weight);
		waitForVisible(driver, ssnCodeTextField);
		ssnCodeTextField.sendKeys(SSNCode);

		addressTextField.sendKeys(address);
		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(4000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		submitButton.click();

	}

	/**
	 * Enter Patient Details in Update Patient form with valid data
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param ssn
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */

	public void UpdatePatientDetails(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String ssn, String address,
			String city, String zipCode, String state) throws InterruptedException {

		waitForVisible(driver, dateOfBirthDatePicker);
		dateOfBirthDatePicker.sendKeys(dob);
		passwordTextField.clear();
		passwordTextField.sendKeys(password);

		Select selectFeet = new Select(feetDropdown);
		selectFeet.selectByVisibleText(feet);

		Select selectInches = new Select(inchesDropdown);
		selectInches.selectByVisibleText(inches);

		Select selectGender = new Select(genderDropdown);
		selectGender.selectByVisibleText(gender);

		weightTextField.clear();
		weightTextField.sendKeys(weight);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(6000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		submitButton.click();
	}

	public void updateProfileForm(String clinicName, String phoneNumber, String webSiteURL)
			throws InterruptedException {
		waitForVisible(driver, clinicNameTextField);
		clinicNameTextField.clear();
		clinicNameTextField.sendKeys(clinicName);
		clinicPhoneNumberTextField.clear();
		clinicPhoneNumberTextField.sendKeys(phoneNumber);
		clinicWebSiteURLTextField.clear();
		clinicWebSiteURLTextField.sendKeys(webSiteURL);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

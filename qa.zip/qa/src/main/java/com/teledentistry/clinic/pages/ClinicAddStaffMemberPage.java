package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ClinicAddStaffMemberPage extends ClinicPageBase {

	// PageElements
	@FindBy(className = "buttonfx")
	WebElement addNewStaffLink;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(id = "name")
	WebElement nameTextField;

	@FindBy(id = "email")
	WebElement emailTextField;

	@FindBy(id = "username")
	WebElement usernameTextField;

	@FindBy(id = "password")
	WebElement passwordTextField;

	@FindBy(name = "status")
	WebElement statusDropdown;

	@FindBy(tagName = "button")
	WebElement submitButton;

	public ClinicAddStaffMemberPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public void clickOnAddNewStaffLink() {
		waitForVisible(driver, addNewStaffLink);
		addNewStaffLink.click();
	}

	public String getAddStaffMemberFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void createStaffMember(String name, String email, String userName, String password, String status)
			throws InterruptedException {

		email = randomEmail(email);
		userName = randomClinicName(userName);
		waitForVisible(driver, nameTextField);
		nameTextField.sendKeys(name);
		emailTextField.sendKeys(email);
		usernameTextField.sendKeys(userName);
		passwordTextField.sendKeys(password);

		Select selectStatus = new Select(statusDropdown);
		selectStatus.selectByVisibleText(status);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void createStaffMemberWithInvalidUsername(String name, String email, String userName, String password,
			String status) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, nameTextField);
		nameTextField.sendKeys(name);
		emailTextField.sendKeys(email);
		usernameTextField.sendKeys(userName);
		passwordTextField.sendKeys(password);

		Select selectStatus = new Select(statusDropdown);
		selectStatus.selectByVisibleText(status);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void createStaffMemberWithInvalidEmail(String name, String email, String userName, String password,
			String status) throws InterruptedException {

		userName = randomClinicName(userName);
		waitForVisible(driver, nameTextField);
		nameTextField.sendKeys(name);
		emailTextField.sendKeys(email);
		usernameTextField.sendKeys(userName);
		passwordTextField.sendKeys(password);

		Select selectStatus = new Select(statusDropdown);
		selectStatus.selectByVisibleText(status);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

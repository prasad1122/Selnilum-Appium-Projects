package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicChangePasswordPage extends ClinicPageBase {

	// Page Elements
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(id = "opwd")
	WebElement oldPasswordTextField;

	@FindBy(id = "npwd")
	WebElement newPasswordTextField;

	@FindBy(id = "cpwd")
	WebElement confirmPasswordTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(xpath = "//h2[normalize-space()='General Report']")
	WebElement generalReportHeader;

	public ClinicChangePasswordPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public String getFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void clinicChangePassword(String oldPassword, String newPassword, String confirmPassword)
			throws InterruptedException {
		String randomPassword = randomPassword(newPassword);
		waitForVisible(driver, oldPasswordTextField);
		oldPasswordTextField.sendKeys(oldPassword);
		newPasswordTextField.sendKeys(randomPassword);
		confirmPasswordTextField.sendKeys(randomPassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void clinicChangePasswordWithInvalidData(String oldPassword, String newPassword, String confirmPassword) {
		waitForVisible(driver, oldPasswordTextField);
		oldPasswordTextField.sendKeys(oldPassword);
		newPasswordTextField.sendKeys(newPassword);
		confirmPasswordTextField.sendKeys(confirmPassword);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public String getGeneralReportHeader() {
		waitForVisible(driver, generalReportHeader);
		return generalReportHeader.getText();
	}

}

package com.teledentistry.clinic.pages;

import java.util.ArrayList;
import java.util.Set;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicJoinSessionPage extends ClinicPageBase {

	// Page Elements

	@FindBy(xpath = "//*[@id='dt']/tbody/tr[1]/td[5]/div/button")
	WebElement joinSessionOptionsButton;

	@FindBy(linkText = "Join Session")
	WebElement joinSessionlink;

	@FindBy(css = ".MuiTypography-root.jss59")
	WebElement roomHeader;

	@FindBy(css = ".MuiButton-label")
	WebElement meetingContinueButton;

	@FindBy(xpath = "//span[text()='Click to Join Session']")
	WebElement videoCallSessionLink;

	@FindBy(xpath = "(//span[text()='Disconnect'])[2]")
	WebElement callDisconnectButton;

	// PageFactory Constructor
	public ClinicJoinSessionPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public void clickOnOPtionsLink() throws Exception {

		waitForVisible(driver, joinSessionOptionsButton);
		joinSessionOptionsButton.click();
		waitForVisible(driver, joinSessionlink);
		joinSessionlink.click();
	}

	public void switchToNewTab() throws InterruptedException {

		Set<String> tabs = driver.getWindowHandles();
		ArrayList<String> win = new ArrayList<String>(tabs);
		driver.switchTo().window(win.get(1));
	}

	public String getRoomHeader() {
		waitForVisible(driver, roomHeader);
		return roomHeader.getText();
	}

	public void clickOnMeetingContinueLink() throws InterruptedException {
		waitForVisible(driver, meetingContinueButton);
		meetingContinueButton.click();
	}

	public void clickToJoinSession() throws InterruptedException {
		waitForVisible(driver, videoCallSessionLink);
		Thread.sleep(3000);
		videoCallSessionLink.click();
	}

	public void clickonDisconnect() {
		waitForVisible(driver, callDisconnectButton);
		callDisconnectButton.click();
	}

}

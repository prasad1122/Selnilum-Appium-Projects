package com.teledentistry.clinic.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicBookAppointmentViaTimeZonesPage extends ClinicPageBase {

	public ClinicBookAppointmentViaTimeZonesPage(WebDriver driver) {
		super(driver);
	}

	// PageElements

	@FindBy(xpath = "//span[contains(text(),'Select Client')]")
	WebElement clientNameDropdown;

	@FindBy(xpath = "//span[contains(text(),'Select Doctor')]")
	WebElement doctorNameDropdown;

	@FindBy(id = "datepicker")
	WebElement datePicker;

	@FindBy(id = "timepicker")
	WebElement timePicker;

	@FindBy(id = "send")
	WebElement submitButton;

	@FindBy(className = "buttonfx")
	WebElement bookNewAppointmentLink;

	@FindBy(css = "#select2-timezone-container")
	WebElement timeZoneDropdown;

	@FindBy(css = "#select2-timezone-results>li")
	List<WebElement> timezoneDropdownList;

	@FindBy(xpath = "//li[@role='option']")
	List<WebElement> clientNameDropdownList;

	@FindBy(xpath = "//li[@role='option']")
	List<WebElement> doctorNameDropdownList;

	// Operational methods

	public void clickOnAddNewBookAppointmentLink() throws InterruptedException {
		waitForVisible(driver, bookNewAppointmentLink);
		bookNewAppointmentLink.click();
	}

	public void createBookAppointment(String timeZone, String clientName, String doctorName, String date, String time)
			throws InterruptedException {

		time = systemTime();
		waitForVisible(driver, timeZoneDropdown);
		timeZoneDropdown.click();
		selectDropdownValue(timezoneDropdownList, timeZone);

		waitForVisible(driver, clientNameDropdown);
		clientNameDropdown.click();
		selectDropdownValue(clientNameDropdownList, clientName);

		waitForVisible(driver, doctorNameDropdown);
		doctorNameDropdown.click();
		selectDropdownValue(doctorNameDropdownList, doctorName);
		waitForVisible(driver, timePicker);

		timePicker.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

package com.teledentistry.clinic.pages;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ClinicPageBase {

	WebDriver driver;
	Logger logger;

	// PageElements
	@FindBy(className = "jconfirm-content")
	WebElement popupStatusContent;

	@FindBy(className = "jconfirm-title")
	WebElement popupStatus;

	public ClinicPageBase(WebDriver driver) {
		logger = Logger.getLogger(this.getClass().getSimpleName());

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Operational methods

	public String randomEmail(String email) {

		String splitstr[] = email.split("@");
		String firststr = splitstr[0] + RandomStringUtils.randomNumeric(10) + "@";
		email = firststr + splitstr[1];

		return email;
	}

	public String randomClinicName(String username) {

		String clinicusernameame = username + RandomStringUtils.randomNumeric(8);

		return clinicusernameame;
	}

	public String systemTime() {
		LocalDateTime localTime = LocalDateTime.now();

		int time = localTime.getMinute();
		time++;
		time++;
		String timeValue = localTime.getHour() + ":" + time;
		return timeValue;
	}

	public String systemTimeWithPastTime() {
		LocalDateTime localTime = LocalDateTime.now();

		int hour = localTime.getHour();
		hour--;
		int time = localTime.getMinute();
		time++;
		String timeValue = hour + ":" + time;
		return timeValue;
	}

	public String randomEmailWithPlusExtension(String email) {

		String splitstr[] = email.split("@");
		String firststr = splitstr[0] + "+" + RandomStringUtils.randomNumeric(10) + "@";
		email = firststr + splitstr[1];

		return email;
	}

	public String getAlert() {
		waitForVisible(driver, popupStatus);
		return popupStatus.getText();
	}

	public String getAlertContent() {
		waitForVisible(driver, popupStatusContent);
		return popupStatusContent.getText();
	}

	public void waitForVisible(WebDriver driver, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String randomPassword(String password) {
		password = password + RandomStringUtils.randomNumeric(3);
		return password;
	}
	
	public void selectDropdownValue(List<WebElement> elementsList, String report) {
		for(WebElement element:elementsList) {
			String elementText = element.getText();
			if(elementText.contains(report)) {
				element.click();
				break;
			}
		}
	}

}

package com.teledentistry.clinic.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClinicLogoutPage extends ClinicPageBase{

	// PageElements
	@FindBy(xpath="//h2[normalize-space()='Practice portal login']")
	WebElement loginFormHeader;
	
	public ClinicLogoutPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public String getLoginPageHedaer() {
		waitForVisible(driver, loginFormHeader);
		return loginFormHeader.getText();
	}

}

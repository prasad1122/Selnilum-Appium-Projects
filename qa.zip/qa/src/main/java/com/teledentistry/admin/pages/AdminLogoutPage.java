package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminLogoutPage extends AdminPageBase {
	
	// PageElements
	
	@FindBy(xpath="//h2[normalize-space()='Super Admin login']")
	WebElement loginFormHeader;

	public AdminLogoutPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	
	public String getLoginPageHedaer() {
		waitForVisible(driver, loginFormHeader);
		return loginFormHeader.getText();
	}

}

package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminAddDoctorPage extends AdminPageBase {

	// PageElements

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(linkText = "Add New Doctor")
	WebElement addNewDoctorLink;

	// Initializing the Page Objects:
	public AdminAddDoctorPage(WebDriver driver) {
		super(driver);
	}

	// Actions:

	public String getAddDoctorFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void clickOnAddNewDoctorLink() {
		waitForVisible(driver, addNewDoctorLink);
		addNewDoctorLink.click();
	}

}

package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminAddPatientPage extends AdminPageBase {

	// PageElements

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(className = "buttonfx")
	WebElement addNewPatinetLink;

	// PageFactory constructor
	public AdminAddPatientPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods

	public void clickOnAddNewpatientLink() {
		waitForVisible(driver, addNewPatinetLink);
		addNewPatinetLink.click();

	}

	public String getAddPatientFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

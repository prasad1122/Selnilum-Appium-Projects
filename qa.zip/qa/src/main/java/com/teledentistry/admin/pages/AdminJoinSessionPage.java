package com.teledentistry.admin.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminJoinSessionPage extends AdminPageBase {

	// Page Elements
	@FindBy(xpath = "(//button[@class='dropdown-toggle button inline-block bg-theme-1 text-white w-full'])[1]")
	WebElement joinSessionOptionsButton;

	@FindBy(linkText = "Join Session")
	WebElement joinSessionlink;

	@FindBy(css = ".MuiTypography-root.jss59")
	WebElement roomHeader;

	@FindBy(css = ".MuiButton-label")
	WebElement meetingContinueButton;

	@FindBy(xpath = "//span[text()='Click to Join Session']")
	WebElement videoCallSessionLink;

	@FindBy(xpath = "(//span[text()='Disconnect'])[2]")
	WebElement callDisconnectButton;

	@FindBy(linkText = "Filters")
	WebElement filtersLink;

	@FindBy(css = "#select2-clinic-container")
	WebElement clinicNameDropdown;
	
	@FindBy(css="#select2-clinic-results>li")
	List<WebElement> clinicDropdownList;

	@FindBy(id = "filter")
	WebElement filterSubmitButton;
	
	@FindBy(css = "div[onclick='toggleView()']")
	WebElement toggleButton;

	// PageFactory Constructor
	public AdminJoinSessionPage(WebDriver driver) {
		super(driver);
	}

	// OPerational methods
	public void clickOnOPtionsLink() throws Exception {
		waitForVisible(driver, filtersLink);
		filtersLink.click();
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, ConstantValues.CLINIC_NAME);
		filterSubmitButton.click();
		filtersLink.click();
		Thread.sleep(5000);

		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		waitForVisible(driver, joinSessionOptionsButton);
		joinSessionOptionsButton.click();
		waitForVisible(driver, joinSessionlink);
		joinSessionlink.click();

	}

	public void switchToNewTab() throws InterruptedException {

		Set<String> tabs = driver.getWindowHandles();
		ArrayList<String> win = new ArrayList<String>(tabs);
		driver.switchTo().window(win.get(1));

	}

	public String getRoomHeader() {
		waitForVisible(driver, roomHeader);
		return roomHeader.getText();
	}

	public void clickOnMeetingContinueLink() {
		waitForVisible(driver, meetingContinueButton);
		meetingContinueButton.click();
	}

	public void clickToJoinSession() throws InterruptedException {
		waitForVisible(driver, videoCallSessionLink);
		Thread.sleep(5000);
		videoCallSessionLink.click();
	}

	public void clickonDisconnect() {
		waitForVisible(driver, callDisconnectButton);
		callDisconnectButton.click();
	}

}

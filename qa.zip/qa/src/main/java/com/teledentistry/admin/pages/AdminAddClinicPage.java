package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminAddClinicPage extends AdminPageBase {

	// PageElements

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(className = "buttonfx")
	WebElement addNewClinicLink;

	// Initializing the Page Objects:
	public AdminAddClinicPage(WebDriver driver) {
		super(driver);
	}

	// OperationalMethods
	public void clickOnAddNewClinicLink() throws InterruptedException {
		waitForVisible(driver, addNewClinicLink);
		addNewClinicLink.click();
	}

	public String getaddClinicFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}
}
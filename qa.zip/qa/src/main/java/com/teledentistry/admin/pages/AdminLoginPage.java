package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class AdminLoginPage extends AdminPageBase {

	// PageElements

	@FindBy(tagName = "select")
	WebElement selectUserTypeDropdown;

	@FindBy(name = "email")
	WebElement emailTextField;

	@FindBy(name = "password")
	WebElement passwordTextField;

	@FindBy(className = "buttonfx")
	WebElement loginBtn;

	@FindBy(xpath = "//button[contains(text(),'ok')]")
	WebElement popupAccept;

	// Initializing the Page Objects:
	public AdminLoginPage(WebDriver driver) {
		super(driver);
	}

	public String validateLoginPageTitle() {
		return driver.getTitle();
	}

	// Operational methods

	public AdminHomePage login(String username, String pwd) throws InterruptedException {
		logger.debug("Parameters revceived: " + username + "," + pwd);
		Select dropdown = new Select(selectUserTypeDropdown);
		dropdown.selectByVisibleText("Admin");
		emailTextField.sendKeys(username);
		passwordTextField.sendKeys(pwd);
		Thread.sleep(3000);
		loginBtn.click();
		logger.info("########## Successfully LogedIn ################");
		return new AdminHomePage(driver);

	}

}

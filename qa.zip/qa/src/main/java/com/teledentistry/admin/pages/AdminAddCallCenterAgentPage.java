package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminAddCallCenterAgentPage extends AdminPageBase {

	// PageElements
	@FindBy(className = "buttonfx")
	WebElement addNewButton;

	@FindBy(id = "firstname")
	WebElement nameTextField;

	@FindBy(id = "email")
	WebElement emailTextField;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(id = "zoom_id")
	WebElement zoomIdTextField;

	public AdminAddCallCenterAgentPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public void clickOnAddNewButton() {
		waitForVisible(driver, addNewButton);
		addNewButton.click();
	}

	public void createCallCenterAgent(String name, String email, String zoomId) {

		email = randomEmail(email);
		waitForVisible(driver, nameTextField);
		nameTextField.sendKeys(name);
		emailTextField.sendKeys(email);
		zoomIdTextField.sendKeys(zoomId);
		submitButton.click();

	}

	public void createCallCenterAgentWithInvalidEmail(String name, String email, String zoomId) {

		waitForVisible(driver, nameTextField);
		nameTextField.sendKeys(name);
		emailTextField.sendKeys(email);
		zoomIdTextField.sendKeys(zoomId);
		submitButton.click();
	}

}

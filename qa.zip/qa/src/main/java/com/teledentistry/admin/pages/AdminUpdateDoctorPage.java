package com.teledentistry.admin.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminUpdateDoctorPage extends AdminPageBase {

	// Page elements
	@FindBy(xpath = "//*[normalize-space()='tdautomationt.test212121@yopmail.com']//following::span[normalize-space()='Edit']")
	WebElement editLink;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(css = "input[type='search']")
	WebElement searchBoxField;

	@FindBy(linkText = "Filters")
	WebElement filtersLink;

	@FindBy(css = "#submit")
	WebElement filterSubmitButton;

	@FindBy(xpath = "//div[@onclick='toggleView()']")
	WebElement toggleButton;

	@FindBy(xpath = "//li[@class='select2-results__option']")
	List<WebElement> clinicDropdownList;

	@FindBy(css = "#select2-clinic-container")
	WebElement clinicNameDropdown;

	// PageFactory constructor
	public AdminUpdateDoctorPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods
	public void clickOnUpdateDoctorLink() throws InterruptedException {
		waitForVisible(driver, filtersLink);
		filtersLink.click();
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		selectDropdownValue(clinicDropdownList, ConstantValues.CLINIC_NAME);
		waitForVisible(driver, filterSubmitButton);
		filterSubmitButton.click();
		filtersLink.click();
		waitForVisible(driver, searchBoxField);
		searchBoxField.sendKeys(ConstantValues.DOCTOR_SEARCH_KEYWORD);
		
		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//div[@onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		Thread.sleep(5000);
		waitForVisible(driver, editLink);
		editLink.click();

	}

	public String getUpdateDoctorFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

package com.teledentistry.admin.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminUpdateAppointmentPage extends AdminPageBase {

	// Page Elements
	@FindBy(id = "disupd")
	WebElement updateLink;

	@FindBy(xpath = "//h2[normalize-space()='Update Appointment']")
	WebElement formHeader;
	
	@FindBy(css = "#select2-clinic-container")
	WebElement clinicNameDropdown;

	@FindBy(css = "#select2-users-container")
	WebElement clientNameDropdown;

	@FindBy(css = "#select2-doctors-container")
	WebElement doctorNameDropdown;

	@FindBy(id = "datepicker")
	WebElement datePickerField;

	@FindBy(id = "timepicker")
	WebElement timePickerField;

	@FindBy(id = "send")
	WebElement submitButton;

	@FindBy(xpath = "//*[@id='dt']/tbody/tr[1]/td[5]/div/button")
	WebElement optionsButton;

	@FindBy(linkText = "Filters")
	WebElement filtersLink;

	@FindBy(id = "filter")
	WebElement filterSubmitButton;

	@FindBy(css = "div[onclick='toggleView()']")
	WebElement toggleButton;
	
	@FindBy(css="#select2-clinic-results>li")
	List<WebElement> clinicDropdownList;

	// PageFactory Constructor

	public AdminUpdateAppointmentPage(WebDriver driver) {
		super(driver);
	}

	// Operational methods

	public void updateAppointmentLink() throws Exception {
		waitForVisible(driver, filtersLink);
		filtersLink.click();
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, ConstantValues.CLINIC_NAME);
		waitForVisible(driver, filterSubmitButton);
		filterSubmitButton.click();
		waitForVisible(driver, filterSubmitButton);
		filtersLink.click();
		
		Thread.sleep(5000);
		if (driver.findElements(By.xpath("//div[@onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		waitForVisible(driver, optionsButton);
		optionsButton.click();
		waitForVisible(driver, updateLink);
		updateLink.click();
	}

	public String getUpdateAppointmentFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	/**
	 * Enter Appointment Details in Update Appointment form with valid data
	 * 
	 * @param clinic
	 * @param clientname
	 * @param doctorname
	 * @param date
	 * @param time
	 * @throws InterruptedException
	 */
	public void updateAppointmentForm(String clinic, String clientname, String doctorname, String date, String time)
			throws InterruptedException {
		time = systemTime();
		timePickerField.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

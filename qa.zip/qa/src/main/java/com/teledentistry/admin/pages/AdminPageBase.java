package com.teledentistry.admin.pages;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdminPageBase {

	WebDriver driver;
	Logger logger;

	@FindBy(className = "jconfirm-content")
	WebElement popupStatusContent;

	@FindBy(className = "jconfirm-title")
	WebElement popupStatus;

	public AdminPageBase(WebDriver driver) {
		logger = Logger.getLogger(this.getClass().getSimpleName());

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String randomEmail(String email) {

		String splitstr[] = email.split("@");
		String firststr = splitstr[0] + RandomStringUtils.randomNumeric(10) + "@";
		email = firststr + splitstr[1];

		return email;
	}

	public String randomClinicName(String username) {

		String clinicusernameame = username + RandomStringUtils.randomNumeric(8);

		return clinicusernameame;
	}

	public String systemTime() {
		LocalDateTime localTime = LocalDateTime.now();

		int time = localTime.getMinute();
		time++;
		time++;
		String timeValue = localTime.getHour() + ":" + time;
		return timeValue;
	}

	public String systemTimeWithPastTime() {
		LocalDateTime localTime = LocalDateTime.now();

		int hour = localTime.getHour();
		hour--;
		int time = localTime.getMinute();
		time++;
		String timeValue = hour + ":" + time;
		return timeValue;
	}

	public String getAlertContent() {
		waitForVisible(driver, popupStatusContent);
		return popupStatusContent.getText();
	}

	public String getAlert() {
		waitForVisible(driver, popupStatus);
		return popupStatus.getText();
	}

	public void waitForVisible(WebDriver driver, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void waitForListVisible(WebDriver driver, List<WebElement> galleryCount2) {
		try {
			// Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOfAllElements(galleryCount2));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectDropdownValue(List<WebElement> elementsList, String report) {
		for(WebElement element:elementsList) {
			String elementText = element.getText();
			if(elementText.contains(report)) {
				element.click();
				break;
			}
		}
	}

}

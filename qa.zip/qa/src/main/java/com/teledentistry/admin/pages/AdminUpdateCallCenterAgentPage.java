package com.teledentistry.admin.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminUpdateCallCenterAgentPage extends AdminPageBase{
	
	//PageElements	
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;
	
	@FindBy(xpath = "//*[normalize-space()='testagent@gmail.com']//following::span[normalize-space()='Edit']")
	WebElement editLink;
	
	@FindBy(css = "input[type='search']")
	WebElement searchBoxField;
	
	@FindBy(xpath = "//div[@onclick='toggleView()']")
	WebElement toggleButton;
	
	@FindBy(id = "firstname")
	WebElement nameTextField;
	
	@FindBy(id = "password")
	WebElement passwordTextField;
	
	@FindBy(css="button[type='submit']")
	WebElement submitButton;

	public AdminUpdateCallCenterAgentPage(WebDriver driver) {
		super(driver);
	}

	//Operational Methods
	public void clickOnUpdateCallCenterAgentLink() throws InterruptedException {
		
		waitForVisible(driver, searchBoxField);
		searchBoxField.sendKeys(ConstantValues.USER_AGENT_SEARCH_KEYWORD);		

		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//div[@onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		Thread.sleep(10000);
		waitForVisible(driver, editLink);
		editLink.click();
	}

	public String getUpdateCallCenterAgentFormHeader() {
		return formHeader.getText();
	}

	public void updateCallCenterAgentDetails(String name, String password) {

		waitForVisible(driver, nameTextField);
		nameTextField.clear();
		nameTextField.sendKeys(name);
		passwordTextField.clear();
		passwordTextField.sendKeys(password);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

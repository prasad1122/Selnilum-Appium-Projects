package com.teledentistry.admin.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminHomePage extends AdminPageBase {

	// PageElements
	@FindBy(linkText = "Doctors")
	WebElement doctorsModuleLink;

	@FindBy(linkText = "Patients")
	WebElement patientsModuleLink;

	@FindBy(linkText = "Clinics")
	WebElement clinicsModuleLink;

	@FindBy(linkText = "Book Appointment")
	WebElement bookAppointmentModuleLink;

	@FindBy(linkText = "Call Center Team")
	WebElement callCenterTeamModuleLink;

	@FindBy(linkText = "Reports")
	WebElement reportsModuleLink;

	@FindBy(linkText = "Logout")
	WebElement logoutBtn;

	// Initializing the Page Objects:
	public AdminHomePage(WebDriver driver) {
		super(driver);
	}

	public AdminAddDoctorPage clickOnDoctorsLink() {
		waitForVisible(driver, doctorsModuleLink);
		doctorsModuleLink.click();
		return new AdminAddDoctorPage(driver);
	}

	public AdminAddClinicPage clickOnClinicsLink() {
		waitForVisible(driver, clinicsModuleLink);
		clinicsModuleLink.click();
		return new AdminAddClinicPage(driver);
	}

	public AdminBookAppointmentPage clickOnBookAppointmentsLink() {
		waitForVisible(driver, bookAppointmentModuleLink);
		bookAppointmentModuleLink.click();
		return new AdminBookAppointmentPage(driver);
	}

	public AdminAddPatientPage clickOnPatientsLink() {
		waitForVisible(driver, patientsModuleLink);
		patientsModuleLink.click();
		return new AdminAddPatientPage(driver);
	}

	public AdminAddCallCenterAgentPage clickOnCallCenterTeamLink() {
		waitForVisible(driver, callCenterTeamModuleLink);
		callCenterTeamModuleLink.click();
		return new AdminAddCallCenterAgentPage(driver);
	}

	public AdminReportsPage clickOnReportsLink() {
		waitForVisible(driver, reportsModuleLink);
		reportsModuleLink.click();
		return new AdminReportsPage(driver);
	}

	public AdminLogoutPage clickOnLogoutButton() {
		waitForVisible(driver, logoutBtn);
		logoutBtn.click();
		return new AdminLogoutPage(driver);
	}
}

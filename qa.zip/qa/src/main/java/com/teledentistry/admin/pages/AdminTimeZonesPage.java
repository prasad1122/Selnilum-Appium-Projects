package com.teledentistry.admin.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminTimeZonesPage extends AdminPageBase {

	public AdminTimeZonesPage(WebDriver driver) {
		super(driver);
	}

	// PageElements

	@FindBy(css = "#select2-clinic-container")
	WebElement clinicNameDropdown;

	@FindBy(css = "#select2-users-container")
	WebElement clientNameDropdown;

	@FindBy(css = "#select2-doctors-container")
	WebElement doctorNameDropdown;

	@FindBy(css = "#select2-timezone-container")
	WebElement timezoneNameDropdown;

	@FindBy(id = "datepicker")
	WebElement datePicker;

	@FindBy(id = "timepicker")
	WebElement timePicker;

	@FindBy(id = "send")
	WebElement submitButton;

	@FindBy(className = "buttonfx")
	WebElement bookNewAppointmentLink;

	@FindBy(css = "#select2-clinic-results>li")
	List<WebElement> clinicDropdownList;

	@FindBy(css = "#select2-timezone-results>li")
	List<WebElement> timezoneDropdownList;

	@FindBy(css = "#select2-users-results>li")
	List<WebElement> clientsDropdownList;

	@FindBy(css = "#select2-doctors-results>li")
	List<WebElement> doctorsDropdownList;

	@FindBy(css = "div[onclick='toggleView()']")
	WebElement toggleButton;
	
	// Operational methods

	public void clickOnAddNewBookAppointmentLink() throws InterruptedException {
		waitForVisible(driver, bookNewAppointmentLink);
		bookNewAppointmentLink.click();
	}

	public void createBookAppointment(String clinic, String timeZone, String clientName, String doctorName, String date,
			String time) throws InterruptedException {

		time = systemTime();
		
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, clinic);
		
		Thread.sleep(3000);
		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		waitForVisible(driver, timezoneNameDropdown);
		timezoneNameDropdown.click();
		waitForListVisible(driver, timezoneDropdownList);
		selectDropdownValue(timezoneDropdownList, timeZone);
		waitForVisible(driver, clientNameDropdown);
		clientNameDropdown.click();
		waitForListVisible(driver, clientsDropdownList);
		selectDropdownValue(clientsDropdownList, clientName);
		waitForVisible(driver, doctorNameDropdown);
		doctorNameDropdown.click();
		waitForListVisible(driver, doctorsDropdownList);
		selectDropdownValue(doctorsDropdownList, doctorName);
		waitForVisible(driver, timePicker);
		timePicker.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

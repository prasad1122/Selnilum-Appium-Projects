package com.teledentistry.admin.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminUpdatePatientPage extends AdminPageBase {

	// PageElements
	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(xpath = "//*[normalize-space()='tdautomationt.test212121@yopmail.com']//following::span[normalize-space()='Edit']")
	WebElement editLink;

	@FindBy(css = "input[type='search']")
	WebElement searchBoxField;

	@FindBy(linkText = "Filters")
	WebElement filtersLink;

	@FindBy(css = "#select2-clinic-container")
	WebElement clinicNameDropdown;

	@FindBy(css = "#submit")
	WebElement filterSubmitButton;

	@FindBy(xpath = "//div[@onclick='toggleView()']")
	WebElement toggleButton;
	
	@FindBy(css="#select2-clinic-results>li")
	List<WebElement> clinicDropdownList;

	public AdminUpdatePatientPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void clickOnUpdatePatientLink() throws InterruptedException {

		waitForVisible(driver, filtersLink);
		filtersLink.click();
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, ConstantValues.CLINIC_NAME);
		waitForVisible(driver, filterSubmitButton);
		filterSubmitButton.click();
		filtersLink.click();
		waitForVisible(driver, searchBoxField);
		searchBoxField.sendKeys(ConstantValues.PATIENT_SEARCH_KEYWORD);

		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//div[@onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		Thread.sleep(8000);
		waitForVisible(driver, editLink);
		editLink.click();

	}

	public String getUpdatePatientFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}
}

package com.teledentistry.admin.pages;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminReportsPage extends AdminPageBase {

	// Month/Year Elements

	@FindBy(linkText = "Month/Year Reports")
	WebElement monthYearSubModuleLink;

	@FindBy(css = "#select2-report-container")
	WebElement selectReportDropdown;

	@FindBy(css = "input[role='searchbox']")
	WebElement searchBoxField;

	@FindBy(css = ".select2-results__option.select2-results__option")
	List<WebElement> reportsDropdownList;

	@FindBy(css = "#select2-type-container")
	WebElement selectYearDropdown;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(css = "#btnPrint")
	WebElement downloadButton;

	@FindBy(css = "#select2-clinic-container")
	WebElement selectClinicDropdown;

	@FindBy(css = "#btnPrint1")
	WebElement consultsDownloadBtn;

	@FindBy(linkText = "Chat Reports")
	WebElement chatReportSubModuleLink;
	
	@FindBy(xpath="(//td[@class='border-b-2 whitespace-no-wrap text-center']//span)[1]")
	WebElement countHyperLink; 
	
	@FindBy(css="div[id='cllist'] button[id='btnPrint1']")
	WebElement countHyperLinkDownLoadButton;

	// ChatReportElements

	@FindBy(css = "#select2-clinic_id-container")
	WebElement clinicDropdown;

	@FindBy(css = "#select2-user_id-container")
	WebElement patientDropdown;

	@FindBy(css = ".accordion__pane__toggle.font-medium.block")
	WebElement filterButton;

	@FindBy(css = "input[value='Filter']")
	WebElement filterSubmitButton;

	// UserActivityReportsElements

	@FindBy(linkText = "User Activity Reports")
	WebElement userActivitySubModuleLink;

	@FindBy(xpath = "//h2[1]//button[1]")
	WebElement notLoggedInListDownloadButton;

	@FindBy(xpath = "//h2[2]//button[1]")
	WebElement edocNotFilledListDownloadButton;

	@FindBy(xpath = "//h2[3]//button[1]")
	WebElement notJoinedConsultsListDownloadButton;
	
	@FindBy(css = "div[onclick='toggleView()']")
	WebElement toggleButton;

	String DownloadFiles;

	public AdminReportsPage(WebDriver driver) {
		super(driver);
	}

	public void clickOnMonthYearLink() {
		waitForVisible(driver, monthYearSubModuleLink);
		monthYearSubModuleLink.click();
	}

	public void selectReportTypeAndYear(String report, String year) throws InterruptedException {
		selectReportDropdown.click();
		selectDropdownValue(reportsDropdownList, report);
		Thread.sleep(5000);

		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		selectYearDropdown.click();
		selectDropdownValue(reportsDropdownList, year);
		submitButton.click();
		Thread.sleep(5000);
	}

	public String getReportsFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void clickOnClinicReportDownloadButton() throws InterruptedException {
		waitForVisible(driver, downloadButton);
		downloadButton.click();
		Thread.sleep(5000);
	}

	public boolean getResult() {
		if (downloadButton.isEnabled()) {
			return true;
		}
		return false;
	}

	public void selectReportTypeAndClinicsAndYear(String report, String clinics, String year)
			throws InterruptedException {
		selectReportDropdown.click();
		selectDropdownValue(reportsDropdownList, report);
		selectClinicDropdown.click();
		selectDropdownValue(reportsDropdownList, clinics);
		Thread.sleep(5000);
		
		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		selectYearDropdown.click();
		selectDropdownValue(reportsDropdownList, year);
		submitButton.click();
		Thread.sleep(5000);
	}

	public void clickOnConsultsReportDownloadButton() {
		waitForVisible(driver, consultsDownloadBtn);
		consultsDownloadBtn.click();
	}

	public boolean getConsultReportResult() {
		if (consultsDownloadBtn.isEnabled()) {
			return true;
		}
		return false;
	}

	public void clickOnChatReportsLink() {
		waitForVisible(driver, chatReportSubModuleLink);
		chatReportSubModuleLink.click();
	}

	public String getChatReportsFormHeader() {
		return formHeader.getText();
	}

	public void selectClinicAndPatient(String clinic, String patient) throws InterruptedException {
		waitForVisible(driver, filterButton);
		filterButton.click();
		waitForVisible(driver, clinicDropdown);
		clinicDropdown.click();
		selectDropdownValue(reportsDropdownList, clinic);
		
		Thread.sleep(3000);
		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		patientDropdown.click();
		selectDropdownValue(reportsDropdownList, patient);
		filterSubmitButton.click();
	}

	public void clickOnChatReportDownloadButton() throws InterruptedException {
		waitForVisible(driver, downloadButton);
		Thread.sleep(3000);
		downloadButton.click();
	}

	public void clickOnUserActivityReportsLink() {
		waitForVisible(driver, userActivitySubModuleLink);
		userActivitySubModuleLink.click();
	}

	public String getUserActivityReportsFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	public void selectClinic() {
		waitForVisible(driver, filterButton);
		filterButton.click();
		waitForVisible(driver, clinicDropdown);
		clinicDropdown.click();
		selectDropdownValue(reportsDropdownList, ConstantValues.CLINIC_NAME);
		waitForVisible(driver, filterSubmitButton);
		filterSubmitButton.click();
	}

	public void clickOnNotLoggedInListDownloadButton() throws InterruptedException {
		waitForVisible(driver, notLoggedInListDownloadButton);
		notLoggedInListDownloadButton.click();
		Thread.sleep(5000);
	}

	public boolean isFileDownloaded(String fileName) throws IOException {

		if (Files.notExists(Paths.get("DownloadFiles"))) {
			Files.createDirectory(Paths.get("DownloadFiles"));
		}

		File dir = new File(System.getProperty("user.dir") + "\\DownloadFiles");
		File[] dirContents = dir.listFiles();

		for (int i = 0; i < dirContents.length; i++) {
			if (dirContents[i].getName().equals(fileName)) {
				// File has been found, it can now be deleted:
				dirContents[i].delete();
				return true;
			}
		}
		return false;
	}

	public void clickOnEdocNotFilledListDownloadButton() throws InterruptedException {
		waitForVisible(driver, edocNotFilledListDownloadButton);
		edocNotFilledListDownloadButton.click();
		Thread.sleep(5000);
	}

	public void clickOnNotJoinedConsultsListDownloadButton() throws InterruptedException {
		waitForVisible(driver, notJoinedConsultsListDownloadButton);
		Thread.sleep(3000);
		notJoinedConsultsListDownloadButton.click();
		Thread.sleep(5000);
	}

	public void clickOnCountHyperLink() {
		waitForVisible(driver, countHyperLink);
		countHyperLink.click();
	}

	public void clickOnCountHyperLinkDownloadButton() {
		waitForVisible(driver, countHyperLinkDownLoadButton);
		countHyperLinkDownLoadButton.click();
	}

	public boolean getMonthReportViaCountHyperLinkResult() {
		if (countHyperLinkDownLoadButton.isEnabled()) {
			return true;
		}
		return false;
	}

}

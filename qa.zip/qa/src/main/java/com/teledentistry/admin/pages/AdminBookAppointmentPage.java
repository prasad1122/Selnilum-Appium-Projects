package com.teledentistry.admin.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminBookAppointmentPage extends AdminPageBase {

	// PageElements

	@FindBy(css = "#select2-clinic-container")
	WebElement clinicNameDropdown;

	@FindBy(css = "#select2-users-container")
	WebElement clientNameDropdown;

	@FindBy(css = "#select2-doctors-container")
	WebElement doctorNameDropdown;

	@FindBy(css = "#select2-timezone-container")
	WebElement timezoneNameDropdown;

	@FindBy(id = "datepicker")
	WebElement datePicker;

	@FindBy(id = "timepicker")
	WebElement timePicker;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(id = "send")
	WebElement submitButton;

	@FindBy(className = "buttonfx")
	WebElement bookNewAppointmentLink;

	@FindBy(css = "#select2-clinic-results>li")
	List<WebElement> clinicDropdownList;

	@FindBy(css = "#select2-timezone-results>li")
	List<WebElement> timezoneDropdownList;

	@FindBy(css = "#select2-users-results>li")
	List<WebElement> clientsDropdownList;

	@FindBy(css = "#select2-doctors-results>li")
	List<WebElement> doctorsDropdownList;
	
	@FindBy(css = "div[onclick='toggleView()']")
	WebElement toggleButton;

	// PageFactory Constructor
	public AdminBookAppointmentPage(WebDriver driver) {
		super(driver);
	}
	// Operational methods

	public void clickOnAddNewBookAppointmentLink() throws InterruptedException {
		waitForVisible(driver, bookNewAppointmentLink);
		bookNewAppointmentLink.click();

	}

	public String getBookAppointmentFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

	/**
	 * Enter Appointment Details in Book Appointment form with valid data
	 * 
	 * @param clinic
	 * @param clientName
	 * @param doctorName
	 * @param date
	 * @param time
	 * @throws InterruptedException
	 */
	public void createBookAppointment(String clinic, String timeZone, String clientName, String doctorName, String date,
			String time) throws InterruptedException {
		time = systemTime();

		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, clinic);	
		
		Thread.sleep(3000);
		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		waitForVisible(driver, timezoneNameDropdown);
		timezoneNameDropdown.click();				
		waitForListVisible(driver, timezoneDropdownList);
		selectDropdownValue(timezoneDropdownList, timeZone);
		waitForVisible(driver, clientNameDropdown);
		clientNameDropdown.click();
		waitForListVisible(driver, clientsDropdownList);
		selectDropdownValue(clientsDropdownList, clientName);
		waitForVisible(driver, doctorNameDropdown);
		doctorNameDropdown.click();
		waitForListVisible(driver, doctorsDropdownList);
		selectDropdownValue(doctorsDropdownList, doctorName);
		waitForVisible(driver, timePicker);
		timePicker.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Appointment Details in Book Appointment form with Invalid date
	 * 
	 * @param clinic
	 * @param clientName
	 * @param doctorName
	 * @param date
	 * @param time
	 * @throws InterruptedException
	 */
	public void createBookAppointmentWithInvalidDate(String clinic, String timeZone, String clientName,
			String doctorName, String date, String time) throws InterruptedException {
		
		time = systemTime();
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, clinic);
		
		Thread.sleep(3000);
		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		waitForVisible(driver, timezoneNameDropdown);
		timezoneNameDropdown.click();
		waitForListVisible(driver, timezoneDropdownList);
		selectDropdownValue(timezoneDropdownList, timeZone);
		waitForVisible(driver, clientNameDropdown);
		clientNameDropdown.click();
		waitForListVisible(driver, clientsDropdownList);
		selectDropdownValue(clientsDropdownList, clientName);
		waitForVisible(driver, doctorNameDropdown);
		doctorNameDropdown.click();
		waitForListVisible(driver, doctorsDropdownList);
		selectDropdownValue(doctorsDropdownList, doctorName);
		waitForVisible(driver, datePicker);
		datePicker.sendKeys(date);
		waitForVisible(driver, timePicker);
		timePicker.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	public void createBookAppointmentWithPastTime(String clinic, String timeZone, String clientName, String doctorName,
			String date, String time) throws InterruptedException {

		time = systemTimeWithPastTime();
		waitForVisible(driver, clinicNameDropdown);
		clinicNameDropdown.click();
		waitForListVisible(driver, clinicDropdownList);
		selectDropdownValue(clinicDropdownList, clinic);
		
		Thread.sleep(3000);
		if (driver.findElements(By.cssSelector("div[onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		waitForVisible(driver, timezoneNameDropdown);
		timezoneNameDropdown.click();
		waitForListVisible(driver, timezoneDropdownList);
		selectDropdownValue(timezoneDropdownList, timeZone);
		waitForVisible(driver, clientNameDropdown);
		clientNameDropdown.click();
		waitForListVisible(driver, clientsDropdownList);
		selectDropdownValue(clientsDropdownList, clientName);
		waitForVisible(driver, doctorNameDropdown);
		doctorNameDropdown.click();
		waitForListVisible(driver, doctorsDropdownList);
		selectDropdownValue(doctorsDropdownList, doctorName);

		timePicker.sendKeys(time);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

}

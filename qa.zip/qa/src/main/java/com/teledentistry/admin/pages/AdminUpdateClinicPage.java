package com.teledentistry.admin.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.teledentistry.util.ConstantValues;

public class AdminUpdateClinicPage extends AdminPageBase {

	// Page Elements
	@FindBy(linkText = "Edit")
	WebElement editClinicLink;

	@FindBy(css = "h2.mr-auto")
	WebElement formHeader;

	@FindBy(xpath = "//div[normalize-space()='test_automation']//following::a[normalize-space()='Options']")
	WebElement optionsButton;

	@FindBy(css = "input[type='search']")
	WebElement searchBoxField;

	@FindBy(xpath = "//div[@onclick='toggleView()']")
	WebElement toggleButton;

	// Initializing the Page Objects:
	public AdminUpdateClinicPage(WebDriver driver) {
		super(driver);
	}

	// Operational Methods
	public void clickOnUpdateClinicLink() throws InterruptedException {

		waitForVisible(driver, searchBoxField);
		searchBoxField.sendKeys(ConstantValues.CLINIC_NAME_SEARCH_KEYWORD);
		
		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//div[@onclick='toggleView()']")).size() != 0) {
			toggleButton.click();
		}
		
		waitForVisible(driver, optionsButton);
		optionsButton.click();
		waitForVisible(driver, editClinicLink);
		editClinicLink.click();
	}

	public String getUpdateClinicFormHeader() {
		waitForVisible(driver, formHeader);
		return formHeader.getText();
	}

}

package com.teledentistry.admin.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class AdminCommonForms extends AdminPageBase {

	public AdminCommonForms(WebDriver driver) {
		super(driver);
	}

	// Common Elements

	@FindBy(xpath = "//li[@class='select2-results__option']")
	List<WebElement> statesDropdownList;

	@FindBy(id = "firstname")
	WebElement firstNameTextField;

	@FindBy(id = "lastname")
	WebElement lastNameTextField;

	@FindBy(id = "phone")
	WebElement phoneNumberTextField;

	@FindBy(id = "email")
	WebElement emailTextField;

	@FindBy(id = "password")
	WebElement passwordTextField;

	@FindBy(id = "dob")
	WebElement dateOfBirthDatePicker;

	@FindBy(css = "button[type='submit']")
	WebElement submitButton;

	@FindBy(id = "clinic")
	WebElement clinicDropdown;

	// Patient forms Elements

	@FindBy(className = "buttonfx")
	WebElement addNewPatinetLink;

	@FindBy(id = "feet")
	WebElement feetDropdown;

	@FindBy(id = "inches")
	WebElement inchesDropdown;

	@FindBy(id = "gender")
	WebElement genderDropdown;

	@FindBy(id = "weight")
	WebElement weightTextField;

	@FindBy(id = "ssn")
	WebElement SSNcodeTextField;

	@FindBy(id = "address")
	WebElement addressTextField;

	@FindBy(id = "fax")
	WebElement faxTextField;

	@FindBy(id = "city")
	WebElement cityTextField;

	@FindBy(id = "zip")
	WebElement zipCodeTextField;

	@FindBy(id = "state")
	WebElement stateDropdown;

	// Doctor forms elements

	@FindBy(css = ".select2-selection.select2-selection--multiple")
	WebElement stateComboBox;

	@FindBy(id = "address_state")
	WebElement stateTextField;

	@FindBy(id = "npi_number")
	WebElement npiNumberTextField;

	@FindBy(id = "dea_number")
	WebElement deaNumberTextField;

	@FindBy(id = "dea_state")
	WebElement deaStateTextField;

	// Clinic Forms Elements

	@FindBy(id = "cname")
	WebElement clinicNameTextField;

	@FindBy(id = "username")
	WebElement userNameTextField;

	@FindBy(id = "logo")
	WebElement logoURLTextField;

	@FindBy(id = "clinic_type")
	WebElement clinicTypeDropdown;

	@FindBy(id = "allowed_resources")
	WebElement staffMembersTextField;

	// Patient form operational methods

	/**
	 * Enter Patient Details in Add Patient form with valid data
	 * 
	 * @param clinicName
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param ssn
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */

	public void createPatient(String clinicName, String firstname, String lastname, String phone, String dob,
			String email, String password, String feet, String inches, String gender, String weight, String ssn,
			String address, String city, String zipCode, String state) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, clinicDropdown);
		Select selectclinic = new Select(clinicDropdown);
		selectclinic.selectByVisibleText(clinicName);

		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.sendKeys(dob);

		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		Select selectFeet = new Select(feetDropdown);
		selectFeet.selectByVisibleText(feet);

		Select selectInches = new Select(inchesDropdown);
		selectInches.selectByVisibleText(inches);

		Select selectGender = new Select(genderDropdown);
		selectGender.selectByVisibleText(gender);

		weightTextField.sendKeys(weight);

		SSNcodeTextField.sendKeys(ssn);

		addressTextField.sendKeys(address);
		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(4000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		Thread.sleep(5000);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Patient Details in Add Patient form with invalid email
	 * 
	 * @param clinicName
	 * @param firstname  -
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param ssn
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */

	public void createPatientWithInvalidEmail(String clinicName, String firstname, String lastname, String phone,
			String dob, String email, String password, String feet, String inches, String gender, String weight,
			String ssn, String address, String city, String zipCode, String state) throws InterruptedException {

		waitForVisible(driver, clinicDropdown);
		Select selectclinic = new Select(clinicDropdown);
		selectclinic.selectByVisibleText(clinicName);

		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.sendKeys(dob);

		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		Select selectFeet = new Select(feetDropdown);
		selectFeet.selectByVisibleText(feet);

		Select selectInches = new Select(inchesDropdown);
		selectInches.selectByVisibleText(inches);

		Select selectGender = new Select(genderDropdown);
		selectGender.selectByVisibleText(gender);

		weightTextField.sendKeys(weight);

		SSNcodeTextField.sendKeys(ssn);

		addressTextField.sendKeys(address);
		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(4000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Patient Details in Add Patient form with invalid DateOfBirth date
	 * 
	 * @param clinicName
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param ssn
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */

	public void createPatientWithInvalidDateofBirth(String clinicName, String firstname, String lastname, String phone,
			String dob, String email, String password, String feet, String inches, String gender, String weight,
			String ssn, String address, String city, String zipCode, String state) throws InterruptedException {

		waitForVisible(driver, clinicDropdown);
		Select selectclinic = new Select(clinicDropdown);
		selectclinic.selectByVisibleText(clinicName);

		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.sendKeys(dob);

		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		Select selectFeet = new Select(feetDropdown);
		selectFeet.selectByVisibleText(feet);

		Select selectInches = new Select(inchesDropdown);
		selectInches.selectByVisibleText(inches);

		Select selectGender = new Select(genderDropdown);
		selectGender.selectByVisibleText(gender);

		weightTextField.sendKeys(weight);

		SSNcodeTextField.sendKeys(ssn);

		addressTextField.sendKeys(address);
		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(4000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Patient Details in Update Patient form with valid data
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param dob
	 * @param email
	 * @param password
	 * @param feet
	 * @param inches
	 * @param gender
	 * @param weight
	 * @param ssn
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param state
	 * @throws InterruptedException
	 */

	public void UpdatePatientDetails(String firstname, String lastname, String phone, String dob, String email,
			String password, String feet, String inches, String gender, String weight, String ssn, String address,
			String city, String zipCode, String state) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, firstNameTextField);
		firstNameTextField.clear();
		firstNameTextField.sendKeys(firstname);

		lastNameTextField.clear();
		lastNameTextField.sendKeys(lastname);

		phoneNumberTextField.clear();
		phoneNumberTextField.sendKeys(phone);
		dateOfBirthDatePicker.clear();
		dateOfBirthDatePicker.sendKeys(dob);
		passwordTextField.clear();
		passwordTextField.sendKeys(password);

		Select selectFeet = new Select(feetDropdown);
		selectFeet.selectByVisibleText(feet);

		Select selectInches = new Select(inchesDropdown);
		selectInches.selectByVisibleText(inches);

		Select selectGender = new Select(genderDropdown);
		selectGender.selectByVisibleText(gender);

		weightTextField.clear();
		weightTextField.sendKeys(weight);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateDropdown);
		selectState.selectByVisibleText(state);
		Thread.sleep(6000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipCode);

		Thread.sleep(5000);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	// Add Doctor form operational methods

	/**
	 * Enter Doctor Details in Add Doctor form with valid data
	 * 
	 * @param clinicName
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param nPINumber
	 * @param dEANumber
	 * @param dEAState
	 * @throws InterruptedException
	 */
	public void createNewDoctor(String clinicName, String firstname, String lastname, String phone, String fax,
			String email, String password, String dob, String state, String address, String city, String zipCode,
			String stateCode, String nPINumber, String dEANumber, String dEAState) throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, clinicDropdown);
		Select selectclinic = new Select(clinicDropdown);
		selectclinic.selectByVisibleText(clinicName);

		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		faxTextField.sendKeys(fax);
		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);
		dateOfBirthDatePicker.sendKeys(dob);
		waitForVisible(driver, stateComboBox);
		stateComboBox.click();
		selectDropdownValue(statesDropdownList, state);
		addressTextField.sendKeys(address);
		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(3000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		npiNumberTextField.sendKeys(nPINumber);
		deaNumberTextField.sendKeys(dEANumber);
		deaStateTextField.sendKeys(dEAState);

		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	/**
	 * Enter Doctor Details in Add Doctor form with invalid email
	 * 
	 * @param clinicName
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param password
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param nPINumber
	 * @param dEANumber
	 * @param dEAState
	 * @throws InterruptedException
	 */
	public void createNewDoctorwithInvalidEmail(String clinicName, String firstname, String lastname, String phone,
			String fax, String email, String password, String dob, String state, String address, String city,
			String zipCode, String stateCode, String NPINumber, String DEANumber, String DEAState)
			throws InterruptedException {

		waitForVisible(driver, clinicDropdown);
		Select selectclinic = new Select(clinicDropdown);
		selectclinic.selectByVisibleText(clinicName);

		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		faxTextField.sendKeys(fax);
		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);
		dateOfBirthDatePicker.sendKeys(dob);
		waitForVisible(driver, stateComboBox);
		stateComboBox.click();
		selectDropdownValue(statesDropdownList, state);
		addressTextField.sendKeys(address);
		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(3000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		npiNumberTextField.sendKeys(NPINumber);
		deaNumberTextField.sendKeys(DEANumber);
		deaStateTextField.sendKeys(DEAState);

		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Doctor Details in Add Doctor form with invalid DateOfBirth
	 * 
	 * @param clinicName
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param password
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param nPINumber
	 * @param dEANumber
	 * @param dEAState
	 * @throws InterruptedException
	 */

	public void createNewDoctorwithInvalidDob(String clinicName, String firstname, String lastname, String phone,
			String fax, String email, String password, String dob, String state, String address, String city,
			String zipCode, String stateCode, String NPINumber, String DEANumber, String DEAState)
			throws InterruptedException {

		email = randomEmail(email);
		waitForVisible(driver, clinicDropdown);
		Select selectclinic = new Select(clinicDropdown);
		selectclinic.selectByVisibleText(clinicName);

		firstNameTextField.sendKeys(firstname);
		lastNameTextField.sendKeys(lastname);
		phoneNumberTextField.sendKeys(phone);
		faxTextField.sendKeys(fax);
		emailTextField.sendKeys(email);
		passwordTextField.sendKeys(password);

		dateOfBirthDatePicker.sendKeys(dob);
		waitForVisible(driver, stateComboBox);
		stateComboBox.click();
		selectDropdownValue(statesDropdownList, state);
		addressTextField.sendKeys(address);
		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(3000);
		waitForVisible(driver, cityTextField);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);
		zipCodeTextField.sendKeys(zipCode);
		npiNumberTextField.sendKeys(NPINumber);
		deaNumberTextField.sendKeys(DEANumber);
		deaStateTextField.sendKeys(DEAState);

		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Doctor Details in Update Doctor form with valid data
	 * 
	 * @param firstname
	 * @param lastname
	 * @param phone
	 * @param fax
	 * @param email
	 * @param password
	 * @param dob
	 * @param state
	 * @param address
	 * @param city
	 * @param zipCode
	 * @param stateCode
	 * @param NPINumber
	 * @param DEANumber
	 * @param DEAState
	 * @throws Exception
	 */

	public void updateDoctorForm(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipCode, String stateCode,
			String NPINumber, String DEANumber, String DEAState) throws Exception {
		email = randomEmail(email);
		waitForVisible(driver, firstNameTextField);
		firstNameTextField.clear();
		firstNameTextField.sendKeys(firstname);

		lastNameTextField.clear();
		lastNameTextField.sendKeys(lastname);

		phoneNumberTextField.clear();
		phoneNumberTextField.sendKeys(phone);

		faxTextField.clear();
		faxTextField.sendKeys(fax);
		passwordTextField.clear();
		passwordTextField.sendKeys(password);

		dateOfBirthDatePicker.clear();

		dateOfBirthDatePicker.sendKeys(dob);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(3000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipCode);

		npiNumberTextField.clear();
		npiNumberTextField.sendKeys(NPINumber);

		deaNumberTextField.clear();
		deaNumberTextField.sendKeys(DEANumber);

		deaStateTextField.clear();
		deaStateTextField.sendKeys(DEAState);

		submitButton.click();
	}

	/**
	 * updateDoctorFrom method and this method same, but reason for write this
	 * method Password is not updating, if we ran continuously UpdateDoctorform
	 * method two times password is not updating so I have written this method
	 * without password field
	 * 
	 */

	public void updateDoctorFormWithDiffCity(String firstname, String lastname, String phone, String fax, String email,
			String password, String dob, String state, String address, String city, String zipCode, String stateCode,
			String NPINumber, String DEANumber, String DEAState) throws InterruptedException {
		waitForVisible(driver, firstNameTextField);
		firstNameTextField.clear();
		firstNameTextField.sendKeys(firstname);

		lastNameTextField.clear();
		lastNameTextField.sendKeys(lastname);

		phoneNumberTextField.clear();
		phoneNumberTextField.sendKeys(phone);

		faxTextField.clear();
		faxTextField.sendKeys(fax);

		dateOfBirthDatePicker.clear();

		dateOfBirthDatePicker.sendKeys(dob);

		addressTextField.clear();
		addressTextField.sendKeys(address);

		Select selectState = new Select(stateTextField);
		selectState.selectByVisibleText(stateCode);
		Thread.sleep(3000);
		Select selectCity = new Select(cityTextField);
		selectCity.selectByVisibleText(city);

		zipCodeTextField.clear();
		zipCodeTextField.sendKeys(zipCode);

		npiNumberTextField.clear();
		npiNumberTextField.sendKeys(NPINumber);

		deaNumberTextField.clear();
		deaNumberTextField.sendKeys(DEANumber);

		deaStateTextField.clear();
		deaStateTextField.sendKeys(DEAState);

		submitButton.click();
	}

	// Add Clinic Forms operational methods

	/**
	 * Enter Clinic Details in Add Clinic form
	 * 
	 * @param clinicName
	 * @param clinicEmail
	 * @param username
	 * @param password
	 * @param logoURL
	 * @param clinicType
	 * @param staffMembers
	 * @throws InterruptedException
	 */
	public void createNewClinic(String clinicName, String clinicEmail, String username, String password, String logoURL,
			String clinicType, String staffMembers) throws InterruptedException {

		username = randomClinicName(username);
		clinicEmail = randomEmail(clinicEmail);
		waitForVisible(driver, clinicNameTextField);
		clinicNameTextField.sendKeys(clinicName);
		emailTextField.sendKeys(clinicEmail);
		userNameTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
		logoURLTextField.sendKeys(logoURL);

		Select ctype = new Select(clinicTypeDropdown);
		ctype.selectByVisibleText(clinicType);

		staffMembersTextField.clear();
		staffMembersTextField.sendKeys(staffMembers);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	/**
	 * Enter Clinic Details in Add Clinic form with invalid email
	 * 
	 * @param clinicName
	 * @param clinicEmail
	 * @param username
	 * @param password
	 * @param logoURL
	 * @param clinicType
	 * @param staffMembers
	 * @throws InterruptedException
	 */

	public void createNewClinicWithInvalidEmail(String clinicName, String clinicEmail, String username, String password,
			String logoURL, String clinicType, String staffMembers) throws InterruptedException {

		username = randomClinicName(username);
		waitForVisible(driver, clinicNameTextField);
		clinicNameTextField.sendKeys(clinicName);
		emailTextField.sendKeys(clinicEmail);
		userNameTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
		logoURLTextField.sendKeys(logoURL);

		Select ctype = new Select(clinicTypeDropdown);
		ctype.selectByVisibleText(clinicType);

		staffMembersTextField.clear();
		staffMembersTextField.sendKeys(staffMembers);
		waitForVisible(driver, submitButton);
		submitButton.click();

	}

	/**
	 * Enter Clinic Details in Add Clinic form with invalid userName
	 * 
	 * @param clinicName
	 * @param clinicEmail
	 * @param username
	 * @param password
	 * @param logoURL
	 * @param clinicType
	 * @param staffMembers
	 * @throws InterruptedException
	 */

	public void createNewClinicWIthInvalidUsername(String clinicName, String clinicEmail, String username,
			String password, String logoURL, String clinicType, String staffMembers) throws InterruptedException {

		username = randomClinicName(username);
		waitForVisible(driver, clinicNameTextField);
		clinicNameTextField.sendKeys(clinicName);
		emailTextField.sendKeys(clinicEmail);
		userNameTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
		logoURLTextField.sendKeys(logoURL);

		Select ctype = new Select(clinicTypeDropdown);
		ctype.selectByVisibleText(clinicType);

		staffMembersTextField.clear();
		staffMembersTextField.sendKeys(staffMembers);
		waitForVisible(driver, submitButton);
		submitButton.click();
	}

	/**
	 * Enter Clinic Details in Update Clinic form with valid data
	 * 
	 * @param clinicName
	 * @param clinicEmail
	 * @param username
	 * @param password
	 * @param logoURL
	 * @param clinicType
	 * @param staffMembers
	 * @throws InterruptedException
	 */
	public void updateClinic(String clinicName, String clinicEmail, String username, String password, String logoURL,
			String clinicType, String staffMembers) throws InterruptedException {

		clinicEmail = randomEmail(clinicEmail);
		waitForVisible(driver, clinicNameTextField);
		clinicNameTextField.clear();
		clinicNameTextField.sendKeys(clinicName);
		passwordTextField.clear();
		passwordTextField.sendKeys(password);

		Select ctype = new Select(clinicTypeDropdown);
		ctype.selectByVisibleText(clinicType);

		staffMembersTextField.clear();
		staffMembersTextField.sendKeys(staffMembers);

		waitForVisible(driver, submitButton);
		submitButton.click();

	}

}
